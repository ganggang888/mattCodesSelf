<?php
$mess = array(
"1" => "Třídy a rozhraní",
"2" => "Možnosti a metody",
"3" => "Zdrojový soubor",
);
