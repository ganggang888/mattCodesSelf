(function(global){

    var MessagesConsumerMixin = AdminComponents.MessagesConsumerMixin;

    var AdminPeopleDashboard = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            dataModel:React.PropTypes.instanceOf(PydioDataModel).isRequired,
            rootNode:React.PropTypes.instanceOf(AjxpNode).isRequired,
            currentNode:React.PropTypes.instanceOf(AjxpNode).isRequired,
            openEditor:React.PropTypes.func.isRequired,
            openModal:React.PropTypes.func,
            dismissModal:React.PropTypes.func
        },

        getInitialState: function(){
            // find roles node
            var siblings = this.props.rootNode.getParent().getChildren();
            var roleNode;
            siblings.forEach(function(s){
                if(s.getPath() == '/data/roles'){
                    roleNode = s;
                }
            });
            if(!roleNode){
                roleNode = new AjxpNode('/data/roles');
            }
            return {
                searchResultData: false,
                currentNode:this.props.currentNode,
                dataModel:this.props.dataModel,
                roleNode:roleNode
            };
        },

        componentWillReceiveProps: function(newProps){
            if(!this.state.searchResultData){
                this.setState({
                    currentNode:newProps.currentNode,
                    dataModel:newProps.dataModel
                });
            }
        },

        _extractMergedRole: function(node) {
            if (!node.getMetadata().get('merged_role') && node.getMetadata().get('json_merged_role')) {
                node.getMetadata().set('merged_role', JSON.parse(node.getMetadata().get('json_merged_role')));
                node.getMetadata().delete('json_merged_role');
            }
            return node.getMetadata().get('merged_role');
        },

        renderListUserAvatar:function(node){
            if(node.getMetadata().get("shared_user")){
                return <div className="sub-entry-icon"></div>;
            }
            var role = this._extractMergedRole(node);
            if(role){
                try{
                    var avatar = role.PARAMETERS.AJXP_REPO_SCOPE_ALL['core.conf'].avatar;
                }catch(e){}
                if(avatar){
                    var imgSrc = global.pydio.Parameters.get("ajxpServerAccess") + "&get_action=get_binary_param&user_id="+ PathUtils.getBasename(node.getPath()) +"&binary_id=" + avatar;
                    return <img src={imgSrc} style={{borderRadius:30,width:33}}/>;
                }
            }
            var iconClass = node.getMetadata().get("icon_class")? node.getMetadata().get("icon_class") : (node.isLeaf()?"icon-file-alt":"icon-folder-close");
            return <ReactMUI.FontIcon className={iconClass}/>;
        },

        renderListEntryFirstLine:function(node){
            if(node.getMetadata().get("shared_user")) {
                return node.getLabel() + " ["+this.context.getMessage('user.13')+"]";
            }else if(node.getMetadata().get("isAdmin")== global.MessageHash['ajxp_conf.14']){
                return (
                    <span>{node.getLabel()} <span className="icon-lock" style={{display:'inline-block',marginRight:5}}></span></span>
                        );
            }else{
                return node.getLabel();
            }
        },

        renderListEntrySecondLine:function(node){
            if(node.isLeaf()){
                if(node.getPath() == '/data/users'){
                    // This is the Root Group
                    return this.context.getMessage('user.8');
                }
                var strings = [];
                if(node.getMetadata().get("last_connection_readable")){
                    strings.push( this.context.getMessage('user.9') + ' ' + node.getMetadata().get("last_connection_readable"));
                }
                var role = this._extractMergedRole(node);
                if(role) {
                    strings.push(this.context.getMessage('user.10').replace("%i", Object.keys(role.ACL).length));
                }
                var roles = node.getMetadata().get('ajxp_roles');
                if(roles && roles.split(',').length){
                    strings.push(this.context.getMessage('user.11').replace("%i", roles.split(',').length));
                }
                return strings.join(" - ");
            }else{
                return this.context.getMessage('user.12') + ': ' + node.getPath().replace('/data/users', '');
            }
        },

        renderListEntrySelector:function(node){
            if(node.getPath() == '/data/users') return false;
            return node.isLeaf();
        },

        displaySearchResults:function(searchTerm, searchDataModel){
            this.setState({
                searchResultTerm:searchTerm,
                searchResultData: {
                    term:searchTerm,
                    toggleState:this.hideSearchResults
                },
                currentNode:searchDataModel.getContextNode(),
                dataModel:searchDataModel
            })
        },

        hideSearchResults:function(){
            this.setState({
                searchResultData: false,
                currentNode:this.props.currentNode,
                dataModel:this.props.dataModel
            });
        },

        createUserAction: function(){
            this.props.openModal('AdminPeople','CreateUserForm', {});
        },

        createGroupAction: function(){
            this.props.openModal('AdminPeople','CreateRoleOrGroupForm', {type:'group'});
        },

        createRoleAction: function(){
            this.props.openModal('AdminPeople','CreateRoleOrGroupForm', {type:'role', roleNode:this.state.roleNode});
        },

        toggleStateShowRoles: function(){
            this.setState({showRolesActions:!this.state.showRolesActions});
        },

        render: function(){

            var emptyToolbar = <div></div>;
            return (
                <div className={"main-layout-nav-to-stack vertical-layout people-dashboard"}>
                    <div className="people-title horizontal-layout">
                        <h1>{this.context.getMessage('2', 'ajxp_conf')}
                            <div className="buttonContainer">
                                <ReactMUI.FlatButton primary={true} label={this.context.getMessage("user.1")} onClick={this.createUserAction}/>
                                <ReactMUI.FlatButton primary={true} label={this.context.getMessage("user.2")} onClick={this.createGroupAction}/>
                            </div>
                        </h1>
                        <ReactPydio.SearchBox
                            displayResults={this.displaySearchResults}
                            displayResultsState={this.state.searchResultData}
                            hideResults={this.hideSearchResults}
                            className="search-box layout-fill"
                            parameters={{get_action:'admin_search',dir:this.props.dataModel.getContextNode().getPath()}}
                            queryParameterName="query"
                            limit={50}
                            textLabel={this.context.getMessage('user.7')}
                        />
                    </div>
                    <div className="container horizontal-layout layout-fill">
                        <div className="hide-on-vertical-layout vertical-layout tab-vertical-layout people-tree" style={{flex:'none'}}>
                            <ReactMUI.Tabs initialSelectedIndex={0}>
                                <ReactMUI.Tab label={this.context.getMessage("user.3")}>
                                    <div style={{marginLeft:8}}>
                                        <ReactPydio.SimpleTree
                                            showRoot={true}
                                            rootLabel={this.context.getMessage("user.5")}
                                            node={this.props.rootNode}
                                            dataModel={this.props.dataModel}
                                            className="users-groups-tree"
                                        />
                                    </div>
                                </ReactMUI.Tab>
                                <ReactMUI.Tab label={this.context.getMessage("user.4")} style={{display:'flex',flexDirection:'column'}}>
                                    <ReactPydio.SimpleList
                                        style={{height:'100%'}}
                                        key={2}
                                        node={this.state.roleNode}
                                        observeNodeReload={true}
                                        dataModel={this.state.dataModel}
                                        className={"display-as-menu" + (this.state.showRolesActions ? '' : ' hideActions')}
                                        openEditor={this.props.openEditor}
                                        actionBarGroups={['get']}
                                        skipParentNavigation={true}
                                        customToolbar={emptyToolbar}
                                        entryRenderIcon={function(node){return null;}}
                                        elementHeight={ReactPydio.SimpleList.HEIGHT_ONE_LINE}
                                        />
                                    <div style={{height:48,padding:'8px 16px',backgroundColor:'rgb(247,247,247)',boxShadow:'0px 0px 1px rgba(0, 0, 0, 0.23)'}}>
                                        <ReactMUI.FlatButton secondary={true} label={this.context.getMessage("user.6")} onClick={this.createRoleAction}/>
                                        <ReactMUI.FlatButton secondary={true} onClick={this.toggleStateShowRoles} label={this.context.getMessage('93', 'ajxp_conf')}/>
                                    </div>
                                </ReactMUI.Tab>
                            </ReactMUI.Tabs>
                        </div>
                        <ReactMUI.Paper zDepth={0} className="layout-fill vertical-layout people-list">
                            <ReactPydio.SimpleList
                                node={this.state.currentNode}
                                dataModel={this.state.dataModel}
                                openEditor={this.props.openEditor}
                                entryRenderIcon={this.renderListUserAvatar}
                                entryRenderFirstLine={this.renderListEntryFirstLine}
                                entryRenderSecondLine={this.renderListEntrySecondLine}
                                entryEnableSelector={this.renderListEntrySelector}
                                searchResultData={this.state.searchResultData}
                                actionBarGroups={['get']}
                                elementHeight={ReactPydio.SimpleList.HEIGHT_TWO_LINES}
                            />
                        </ReactMUI.Paper>
                    </div>
                </div>
            );
        }

    });

    var CreateRoleOrGroupForm = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            modalData:React.PropTypes.object,
            dismiss:React.PropTypes.func
        },

        getTitle:function(){
            if(this.props.modalData.payload.type == 'group'){
                return this.context.getMessage('user.15');
            }else{
                return this.context.getMessage('user.14');
            }
        },

        getDialogClassName:function(){
            return "dialog-max-480";
        },

        getButtons:function(){
            return [
                { text: this.context.getMessage('49', '') }, // cancel
                { text: this.context.getMessage('48', ''), onClick: this.submit, ref: 'submit' } // ok
            ];
        },

        submit: function() {
            var type = this.props.modalData.payload.type;
            var parameters;
            var currentNode;
            if( type == "group"){
                var gId = this.refs.group_id.getValue();
                var gLabel = this.refs.group_label.getValue();
                if(!gId || !gLabel){
                    return;
                }
                if(global.pydio.getContextHolder().getSelectedNodes().length){
                    currentNode = global.pydio.getContextHolder().getSelectedNodes()[0];
                }else{
                    currentNode = global.pydio.getContextNode();
                }
                parameters = {get_action:'edit', sub_action:'create_group', dir:currentNode.getPath(), group_name:gId, group_label:gLabel};

            }else if (type == "role"){
                currentNode = this.props.modalData.payload.roleNode;
                parameters = {get_action:'edit', sub_action:'create_role', role_id:this.refs.role_id.getValue()};
            }

            PydioApi.getClient().request(parameters, function(){
                this.props.dismiss();
                if(currentNode) currentNode.reload();
            }.bind(this));
        },

        render: function(){
            if(this.props.modalData.payload.type == 'group'){
                return (
                    <div>
                        <ReactMUI.TextField
                            ref="group_id"
                            floatingLabelText={this.context.getMessage('user.16')}
                            /><br/>
                        <ReactMUI.TextField
                            ref="group_label"
                            floatingLabelText={this.context.getMessage('user.17')}
                            />
                    </div>
                );
            }else{
                return (
                    <div>
                        <ReactMUI.TextField
                            ref="role_id"
                            floatingLabelText={this.context.getMessage('user.18')}
                            /><br/>
                    </div>
                );
            }
        }

    });

    var CreateUserForm = React.createClass({

        mixins:[MessagesConsumerMixin],

        checkPassword:function(){
            var value1 = this.refs.pass.getValue();
            var value2 = this.refs.passconf.getValue();
            var minLength = parseInt(global.pydio.getPluginConfigs("core.auth").get("PASSWORD_MINLENGTH"));
            if(value1 && value1.length < minLength){
                this.refs.pass.setErrorText(this.context.getMessage('378', ''));
                return;
            }
            if(value1 && value2 && value2 != value1){
                this.refs.passconf.setErrorText(this.context.getMessage('238', ''));
                return;
            }
            this.refs.pass.setErrorText(null);
            this.refs.passconf.setErrorText(null);
        },

        getInitialState: function(){
            return {
                step:1
            }
        },

        getTitle:function(){
            return this.context.getMessage('user.19');
        },

        getDialogClassName:function(){
            return "dialog-max-480";
        },

        getButtons:function(){
            return [
                { text: this.context.getMessage('49', '') },
                { text: this.context.getMessage('48', ''), onClick: this.submit, ref: 'submit' }
            ];
        },

        submit: function(dialog){
            var parameters = {};
            var ctx = this.props.dataModel.getUniqueNode() || this.props.dataModel.getContextNode();
            parameters['get_action'] = 'create_user';
            parameters['new_user_login'] = this.refs.user_id.getValue();
            parameters['new_user_pwd'] = this.refs.pass.getValue();
            var currentPath = ctx.getPath();
            if(currentPath.startsWith("/data/users")){
                parameters['group_path'] = currentPath.substr("/data/users".length);
            }
            PydioApi.getClient().request(parameters, function(transport){
                var xml = transport.responseXML;
                var message = XMLUtils.XPathSelectSingleNode(xml, "//reload_instruction");
                if(message){
                    var node = new AjxpNode(currentPath + "/"+ parameters['new_user_login'], true);
                    node.getMetadata().set("ajxp_mime", "user");
                    global.pydio.UI.openCurrentSelectionInEditor(node);
                    var currentNode = global.pydio.getContextNode();
                    if(global.pydio.getContextHolder().getSelectedNodes().length){
                        currentNode = global.pydio.getContextHolder().getSelectedNodes()[0];
                    }
                    currentNode.reload();
                }
            }.bind(this));
            this.props.dismiss();
        },

        render: function(){
            var ctx = this.props.dataModel.getUniqueNode() || this.props.dataModel.getContextNode();
            var currentPath = ctx.getPath();
            var path;
            if(currentPath.startsWith("/data/users")){
                path = currentPath.substr("/data/users".length);
                if(path){
                    path = <div>{this.context.getMessage('user.20').replace('%s', path)}</div>;
                }
            }
            return (
                <div>
                    {path}
                    <div>
                        <ReactMUI.TextField
                            ref="user_id"
                            floatingLabelText={this.context.getMessage('user.21')}
                        />
                    </div>
                    <div>
                        <ReactMUI.TextField
                            ref="pass"
                            type="password"
                            floatingLabelText={this.context.getMessage('user.22')}
                            onChange={this.checkPassword}
                        />
                    </div>
                    <div>
                        <ReactMUI.TextField
                            ref="passconf"
                            type="password"
                            floatingLabelText={this.context.getMessage('user.23')}
                            onChange={this.checkPassword}
                        />
                    </div>
                </div>
            );
        }
    });

    global.AdminPeople = {
        Dashboard:AdminPeopleDashboard,
        CreateUserForm:CreateUserForm,
        CreateRoleOrGroupForm:CreateRoleOrGroupForm
    };

})(window);