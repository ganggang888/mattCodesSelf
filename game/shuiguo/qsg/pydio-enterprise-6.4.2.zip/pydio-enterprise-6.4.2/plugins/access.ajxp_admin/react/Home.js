(function(global){

    /**************************/
    /* DASHBOARD CARDS MIXINS */
    /**************************/
    var ReloadMixin = {
        propTypes:{
            interval:React.PropTypes.number
        },
        componentDidMount:function(){
            if(this.props.interval){
                this.interval = global.setInterval(this.triggerReload, this.props.interval * 1000);
            }
        },
        componentWillUnmount:function(){
            if(this.interval){
                global.clearInterval(this.interval);
            }
        }

    };

    var MessagesConsumerMixin = AdminComponents.MessagesConsumerMixin;
    // We need this for statics calls.
    var globalMessages = global.pydio.MessageHash;

    var GridItemMixin = {

        propTypes:{
            showCloseAction:React.PropTypes.bool,
            onCloseAction:React.PropTypes.func
        },

        focusItem:function(){
            this.setState({focus:true});
        },

        blurItem:function(){
            this.setState({focus:false});
        },

        mergeStyleWithFocus:function(){
            var style = this.props.style ? this.props.style : {};
            if(this.state.focus){
                style['zIndex'] = 1;
            }else{
                style['zIndex'] = null;
            }
            return style;
        },

        getInitialSate:function(){
            return {focus:false};
        },

        getCloseButton:function(){
            if(this.props.showCloseAction){
                var closeAction = function(){};
                if(this.props.onCloseAction) closeAction = this.props.onCloseAction;
                return(
                    <div className="card-close-overlay">
                        <ReactMUI.FlatButton
                            label={globalMessages['ajxp_admin.home.48']}
                            className="card-close-button"
                            onClick={closeAction}></ReactMUI.FlatButton>
                    </div>
                );
            }else{
                return null;
            }
        },

        statics:{
            getGridLayout:function(x, y){
                return {
                    x:x||0,
                    y:y||0,
                    w:this.gridWidth || 4,
                    h:this.gridHeight || 12,
                    isResizable:false
                };
            },
            hasBuilderFields:function(){
                return this.builderFields?true:false;
            },
            getBuilderFields:function(){
                return this.builderFields;
            }
        }

    };

    /*****************/
    /* GRAPHS UTILS  */
    /*****************/
    var GraphPaginator = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            start:React.PropTypes.number.isRequired,
            count:React.PropTypes.number.isRequired,
            onRangeChange:React.PropTypes.func.isRequired,
            links:React.PropTypes.array,
            pickerOnShow:React.PropTypes.func,
            pickerOnDismiss:React.PropTypes.func
        },

        getInitialState:function(){
            return {paginatorType:'pages'}
        },

        makeLink: function(type, links){
            var found, clickFunc = function(){};
            links.map(function(l){
                if(l.rel != type) return;
                found = true;
                clickFunc = function(){
                    this.props.onRangeChange(l.cursor, l.count);
                }.bind(this);
            }.bind(this));
            var icon;
            if(type == "last") icon = "double-angle-left";
            if(type == "next") icon = "angle-left";
            if(type == "previous") icon = "angle-right";
            if(type == "first") icon = "double-angle-right";
            return <ReactMUI.IconButton
                key={type}
                iconClassName={'icon-' + icon}
                onClick={clickFunc}
                disabled={!found}
            />

        },

        componentDidUpdate:function(){
            if(this.refs.startDate){
                var startDate = this.cursorToDate(this.props.start + this.props.count);
                this.refs.startDate.setDate(startDate);
            }
            if(this.refs.endDate){
                var endDate = this.cursorToDate(this.props.start);
                this.refs.endDate.setDate(endDate);
            }
        },

        togglePaginatorType:function(){
            this.setState({
                paginatorType:this.state.paginatorType=='dates'?'pages':'dates'
            });
        },

        recomputeStartCountFromDates:function(dateType, value){
            var today = new Date();
            var start = this.props.start, count = this.props.count;
            if(dateType == 'end'){
                start = this.compareDates(today, value);
                var currentStartCursor = this.props.start + this.props.count;
                if(start > currentStartCursor){
                    count = 7;
                }else{
                    count = currentStartCursor - start;
                }
            }else if(dateType == 'start'){
                var total = this.compareDates(today, value);
                count = total - start;
            }
            if(start != this.props.start || count != this.props.count){
                this.props.onRangeChange(start, count);
            }
        },

        compareDates:function(date1, date2){
            date1 = Date.UTC(date1.getFullYear(), date1.getMonth(), date1.getDate());
            date2 = Date.UTC(date2.getFullYear(), date2.getMonth(), date2.getDate());
            var ms = Math.abs(date1-date2);
            return Math.floor(ms/1000/60/60/24); //floor should be unnecessary, but just in case
        },

        cursorToDate:function(integer){
            var today = new Date();
            var newDate = new Date();
            newDate.setDate(today.getDate() - integer);
            return newDate;
        },

        render: function(){

            var links=[];
            links.push(
                <ReactMUI.IconButton
                    key="paginatorToggle"
                    onClick={this.togglePaginatorType}
                    iconClassName={"icon-" + (this.state.paginatorType == 'pages'?'calendar':'anchor')}
                    tooltip={(this.state.paginatorType == 'pages'?this.context.getMessage('home.2'):this.context.getMessage('home.3'))}
                />
            );
            if(this.props.links && this.state.paginatorType == 'pages'){
                //links.push(this.makeLink('last', this.state.links));
                links.push(this.makeLink('next', this.props.links));
                links.push(this.makeLink('previous', this.props.links));
                links.push(this.makeLink('first', this.props.links));

            }else if(this.state.paginatorType == 'dates'){
                var today = new Date();
                var startDate = this.cursorToDate(this.props.start + this.props.count);
                var endDate = this.cursorToDate(this.props.start);
                var recomputeStart = function(event, value){
                    this.recomputeStartCountFromDates('start', value)
                }.bind(this);
                var recomputeEnd = function(event, value){
                    this.recomputeStartCountFromDates('end', value)
                }.bind(this);
                links.push(
                    <div className="paginator-dates">
                        <ReactMUI.DatePicker
                            ref="startDate"
                            onChange={recomputeStart}
                            key="start"
                            hintText={this.context.getMessage('home.4')}
                            autoOk={true}
                            maxDate={endDate}
                            defaultDate={startDate}
                            showYearSelector={true}
                            onShow={this.props.pickerOnShow}
                            onDismiss={this.props.pickerOnDismiss}
                        />
                        <ReactMUI.DatePicker
                            ref="endDate"
                            onChange={recomputeEnd}
                            key="end"
                            hintText={this.context.getMessage('home.5')}
                            autoOk={true}
                            minDate={startDate}
                            maxDate={today}
                            defaultDate={endDate}
                            showYearSelector={true}
                            onShow={this.props.pickerOnShow}
                            onDismiss={this.props.pickerOnDismiss}
                        />
                    </div>
                );
            }

            return <div className="graphs-paginator">{links}</div>;
        }
    });

    var RemoteGraphLine = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            queryName:React.PropTypes.string,
            start:React.PropTypes.number,
            count:React.PropTypes.number,
            frequency:React.PropTypes.string,
            onDataLoaded:React.PropTypes.func,
            width:React.PropTypes.number,
            height:React.PropTypes.number,
            chartOptions:React.PropTypes.object,
            filters:React.PropTypes.object
        },

        triggerReload:function(){
            this.loadData();
        },

        getDefaultProps: function(){
            return {
                start:0,
                count:7,
                width:300,
                height:200,
                frequency:'auto',
                onDataLoaded:function(){},
                chartOptions:{
                    responsive:true,
                    useCSSTransforms:false,
                    maintainAspectRatio:false,
                    tooltipTemplate: "<%= value %> <%= datasetLabel %>",
                    multiTooltipTemplate: "<%= value %> <%= datasetLabel %>"
                }
            };
        },

        getInitialState:function(){
            return {
                loaded:false,
                chartData:{labels:[], datasets:[]}
            };
        },

        componentWillReceiveProps(nextProps){
            if(nextProps.start != this.props.start || nextProps.count != this.props.count){
                this.setState({newLoad:true});
            }
            if(nextProps.width && parseInt(nextProps.width) != this.props.width && this.refs.chart){
                //this.refs.chart.getChart().resize();
            }

        },

        componentDidMount:function(){
            this.firstLoad = global.setTimeout(this.loadData, 500);
            //this.loadData();
        },

        componentWillUnmount: function(){
            if(this.firstLoad){
                global.clearTimeout(this.firstLoad);
            }
        },

        componentDidUpdate(){
            if(this.state.newLoad){
                this.setState({newLoad:false}, this.loadData);
            }
        },

        loadData: function(){
            this.firstLoad = null;
            var parameters = {
                get_action:'analytic_query',
                query_name:this.props.queryName,
                start:this.props.start,
                count:this.props.count,
                frequency:this.props.frequency
            };
            if(this.props.filters){
                parameters = LangUtils.objectMerge(parameters, this.props.filters);
            }
            PydioApi.getClient().request(parameters, function(transport){
                if( !this.isMounted() ) return ;
                this.parseData(this.props.queryName, transport.responseJSON);
            }.bind(this));
        },

        parseData:function(queryName, jsonData){
            if(jsonData.data instanceof Array){
                jsonData.data = {unique:jsonData.data};
            }
            if(jsonData.meta instanceof Array){
                jsonData.meta = {unique:jsonData.meta};
            }
            var received = jsonData.data;
            // TO BE TAKEN FROM CONFIG
            var sortKey = 'Date_sortable';
            var labelKey = 'Date';
            var labels = [];
            var datasets = {};
            var datasetsLabels = {};

            // First compute all keys
            var presort = [];
            var presortLabels = {};
            var foundLabels = [];
            for(var k in received){
                if(!received.hasOwnProperty(k)) continue;
                datasets[k] = [];
                received[k].map(function(entry){
                    if(foundLabels.indexOf(entry[labelKey]) === -1){
                        presort.push(entry[sortKey]);
                        presortLabels[entry[sortKey]] = entry[labelKey];//.replace(' 2015', '');
                        foundLabels.push(entry[labelKey]);
                    }
                });
            }
            presort.sort();
            presort.map(function(sortedKey){
                for(var k in received) {
                    if (!received.hasOwnProperty(k)) continue;
                    var foundEntry = null;
                    received[k].map(function(entry){
                        if(entry[labelKey] == presortLabels[sortedKey]){
                            foundEntry = entry;
                        }
                    });
                    var value = 0;
                    if(foundEntry){
                        // find a value key here
                        for(var prop in foundEntry){
                            if(!foundEntry.hasOwnProperty(prop) || prop == sortKey || prop == labelKey) continue;
                            value = foundEntry[prop];
                            datasetsLabels[k] = prop;
                            break;
                        }
                    }
                    datasets[k].push(value);
                    if(!datasetsLabels[k] && jsonData.meta && jsonData.meta[k]){
                        var meta = jsonData.meta[k];
                        if(meta['AXIS'] && meta['AXIS']['y']) datasetsLabels[k] = meta['AXIS']['y'];
                        else datasetsLabels[k] = meta['LABEL'];
                    }
                }
                labels.push(presortLabels[sortedKey].replace(' 2015', ''));
            });
            var preparedDataSets = [];
            var index = 0;
            for(var qK in datasets){
                if(datasets.hasOwnProperty(qK)){
                    var dLabel = datasetsLabels[qK] || '';
                    preparedDataSets.push(this.makeDataSet(index, dLabel, datasets[qK]));
                    index ++;
                }
            }
            this.setState({
                chartData:{
                    labels:labels,
                    datasets:preparedDataSets
                },
                links:jsonData.links,
                loaded:true
            });
            this.props.onDataLoaded(jsonData, preparedDataSets);
        },

        makeDataSet:function(index, label, data){
            var colors = ['220,220,220', '151,187,205','70, 191, 189'];
            index = index % colors.length;
            return {
                label: label,
                fillColor: "rgba("+colors[index]+",0.2)",
                strokeColor: "rgba("+colors[index]+",1)",
                pointColor: "rgba("+colors[index]+",1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba("+colors[index]+",1)",
                data: data
            };
        },

        resizeChart:function(){
            if(this.refs['chart']){
                this.refs['chart'].getChart().resize();
            }
        },

        render: function() {
            var chart;
            if (this.state.loaded) {
                chart = <ReactChart.Line
                    ref="chart"
                    key="chart"
                    data={this.state.chartData}
                    options={this.props.chartOptions}
                    width={this.props.width}
                    height={this.props.height}
                />;
            } else {
                chart = <div className="graph-loading">{this.context.getMessage('home.6')}</div>;
            }
            return chart;
        }
    });

    /*******************/
    /* DASHBOARD CARDS */
    /*******************/
    var MostActiveBadge = React.createClass({

        mixins:[GridItemMixin],

        statics:{
            gridWidth:2,
            gridHeight:6,
            builderDisplayName:globalMessages['ajxp_admin.home.7'],
            builderFields:[
                {name:'legend',label:globalMessages['ajxp_admin.home.12'], type:'string', mandatory:true},
                {name:'range',label:globalMessages['ajxp_admin.home.13'],
                    type:'select',
                    choices:'' +
                    'last_day|'+globalMessages['ajxp_admin.home.14']+',' +
                    'last_week|'+globalMessages['ajxp_admin.home.15']+',' +
                    'last_month|'+globalMessages['ajxp_admin.home.16'],
                    mandatory:true,
                    default:'last_day'
                },
                {name:'type',
                    label:globalMessages['ajxp_admin.home.8'],
                    type:'select',
                    choices:'' +
                    'user|'+globalMessages['ajxp_admin.home.9']+',' +
                    'ip|'+globalMessages['ajxp_admin.home.10']+',' +
                    'action|'+globalMessages['ajxp_admin.home.11'],
                    default:'user',
                    mandatory:true
                },
                {name:'actionName',label:globalMessages['ajxp_admin.home.17'], type:'select', choices:'json_list:list_query_actions', description:globalMessages['ajxp_admin.home.73']},
                {name:'workspaceFilter', label:globalMessages['ajxp_admin.home.69'], type:'select', choices:'AJXP_AVAILABLE_REPOSITORIES', description:globalMessages['ajxp_admin.home.70']},
                {name:'filenameFilter', label:globalMessages['ajxp_admin.home.71'], description:globalMessages['ajxp_admin.home.72'], type:'string'},
                {name:'interval',label:globalMessages['ajxp_admin.home.18'], type:'integer', default:300}
            ]
        },

        propTypes:{
            type:React.PropTypes.oneOf(['user','ip','action']),
            figure:React.PropTypes.number,
            range:React.PropTypes.string,
            legend:React.PropTypes.string,
            style:React.PropTypes.object,
            className:React.PropTypes.string,
            actionName:React.PropTypes.string,
            workspaceFilter:React.PropTypes.string,
            filenameFilter:React.PropTypes.string
        },

        getInitialState:function(){
            // display initial figure
            return {figure:this.props.figure || '-'};
        },

        loadStatus:function(){
            this.firstLoad = null;
            var params = {
                get_action:'most_active_type',
                type:this.props.type||'user',
                date_range:this.props.range||'last_day'
            };
            if(this.props.type == "action" && this.props.actionName){
                params["action"] = this.props.actionName;
            }
            if(this.props.workspaceFilter && this.props.workspaceFilter != -1) {
                params["ws_id"] = this.props.workspaceFilter;
            }
            if(this.props.filenameFilter) {
                params["filename_filter"] = this.props.filenameFilter;
            }

            PydioApi.getClient().request(params, function(transport){
                if( !this.isMounted() ) return ;
                var data = transport.responseJSON;
                if(data.ERROR || !data.DATA || !data.DATA.length) return;
                var figure = data.DATA[0]['Object'];
                var additionalData;
                if(data.USERS && data.USERS['AJXP_USR_/'+figure]){
                    try{
                        additionalData = figure;
                        figure = data.USERS['AJXP_USR_/'+figure]['AJXP_REPO_SCOPE_ALL']['core.conf']['USER_DISPLAY_NAME'];
                    }catch(e){}
                }
                if(this.props.type == "action" && figure.indexOf("/") !== -1){
                    additionalData = figure;
                    figure = PathUtils.getBasename(figure);
                }
                this.setState({figure:figure, additionalData:additionalData});
            }.bind(this), null, {discrete:true});
        },

        componentDidMount: function(){
            this.firstLoad = global.setTimeout(this.loadStatus, 500);
            //this.loadStatus();
        },

        componentWillUnmount: function(){
            if(this.firstLoad){
                global.clearTimeout(this.firstLoad);
            }
        },

        render: function(){
            var className = (this.props.className?this.props.className + ' ':'') + 'graphs-badge most-active-badge';
            return (
                <ReactMUI.Paper
                    {...this.props}
                    zDepth={1}
                    className={className}
                    style={this.props.style}>
                    {this.getCloseButton()}
                    <div className="badge-content">
                        <h4 className="figure text">
                            <ReactPydio.LabelWithTip label={this.state.figure} tooltip={this.state.additionalData} />
                        </h4>
                        <div className="legend">{this.props.legend}</div>
                    </div>
                </ReactMUI.Paper>
            );
        }

    });

    var GraphBadge = React.createClass({

        mixins:[ReloadMixin, GridItemMixin],

        statics:{
            gridWidth:2,
            gridHeight:6,
            builderDisplayName:globalMessages['ajxp_admin.home.19'],
            builderFields:[
                {name:'legend',label:globalMessages['ajxp_admin.home.12'], type:'string', mandatory:true},
                {name:'queryName',
                    label:globalMessages['ajxp_admin.home.21'],
                    type:'select',
                    choices:'' +
                    'uploads_per_day|'+globalMessages['ajxp_admin.home.22']+',' +
                    'downloads_per_day|'+globalMessages['ajxp_admin.home.23']+',' +
                    'sharedfiles_per_day|'+globalMessages['ajxp_admin.home.24']+',' +
                    'connections_per_day|'+globalMessages['ajxp_admin.home.25']
                },
                {
                    name:'frequency',
                    label:globalMessages['ajxp_admin.home.29'],
                    type:'select',
                    choices:"" +
                    "day|"+globalMessages['ajxp_admin.home.26']+"," +
                    "week|"+globalMessages['ajxp_admin.home.27']+"," +
                    "month|"+globalMessages['ajxp_admin.home.28'],
                    default:'day',
                    mandatory:true
                },
                {name:'workspaceFilter', label:globalMessages['ajxp_admin.home.69'], type:'select', choices:'AJXP_AVAILABLE_REPOSITORIES', description:globalMessages['ajxp_admin.home.70']},
                {name:'filenameFilter', label:globalMessages['ajxp_admin.home.71'], description:globalMessages['ajxp_admin.home.72'], type:'string'},
                {name:'interval',label:globalMessages['ajxp_admin.home.18'], type:'integer', default:300}
            ]
        },

        propTypes:{
            queryName:React.PropTypes.string,
            defaultInterval:React.PropTypes.number,
            figure:React.PropTypes.number,
            frequency:React.PropTypes.string,
            legend:React.PropTypes.string,
            style:React.PropTypes.object,
            className:React.PropTypes.string
        },

        getInitialState:function(){
            // display initial figure
            return {figure:this.props.figure || '-'};
        },

        triggerReload:function(){
            this.refs['chart'].triggerReload();
        },

        onLoadedData:function(receivedData, preparedDataSet){
            // grab the today figure = the last value of the data set
            var figure = '-';
            try{
                var data = preparedDataSet[0].data;
                if(data.length){
                    figure = data[data.length-1];
                }
            }catch(e){}
            this.setState({figure:figure});
        },

        render: function(){

            var containerW = parseInt(this.props.style.width);
            var containerH = parseInt(this.props.style.height);

            var chartOptions = {
                showScale:false,
                showTooltip:false,
                showGridLines: false,
                pointDot: false,
                bezierCurveTension:0.3,
                datasetStrokeWidth:0,
                showTooltips:false,
                responsive:true,
                maintainAspectRatio:false
            };
            var className = (this.props.className?this.props.className + ' ':'') + 'graphs-badge';
            var count = 14;
            if(this.props.frequency == 'week'){
                count = 45;
            }else if(this.props.frequency == 'month'){
                count = 150;
            }
            var filters = {};
            if(this.props.workspaceFilter && this.props.workspaceFilter != -1) {
                filters["ws_id"] = this.props.workspaceFilter;
            }
            if(this.props.filenameFilter) {
                filters["filename_filter"] = this.props.filenameFilter;
            }

            return (
                <ReactMUI.Paper
                    {...this.props}
                    className={className}
                    zDepth={1}
                    style={this.props.style}>
                    {this.getCloseButton()}
                    <div className="badge-canvas-container">
                        <RemoteGraphLine
                            ref="chart"
                            queryName={this.props.queryName}
                            start={0}
                            count={count}
                            frequency={this.props.frequency}
                            width={containerW+10}
                            height={containerH+5}
                            chartOptions={chartOptions}
                            onDataLoaded={this.onLoadedData}
                            filters={filters}
                        />
                    </div>
                    <div className="badge-content">
                        <h4 className="figure">{this.state.figure}</h4>
                        <div className="legend">{this.props.legend}</div>
                    </div>
                </ReactMUI.Paper>
            );

        }

    });

    var GraphCard = React.createClass({

        mixins:[ReloadMixin, GridItemMixin],

        statics:{
            gridWidth:4,
            gridHeight:20,
            builderDisplayName:globalMessages['ajxp_admin.home.20'],
            builderFields:[
                {name:'title',label:globalMessages['ajxp_admin.home.30'], type:'string', mandatory:true},
                {name:'queryName',
                    label:globalMessages['ajxp_admin.home.21'],
                    type:'select',
                    choices:'' +
                    'uploads_per_day|'+globalMessages['ajxp_admin.home.22']+',' +
                    'downloads_per_day|'+globalMessages['ajxp_admin.home.23']+',' +
                    'sharedfiles_per_day|'+globalMessages['ajxp_admin.home.24']+',' +
                    'connections_per_day|'+globalMessages['ajxp_admin.home.25']
                },
                {name:'workspaceFilter', label:globalMessages['ajxp_admin.home.69'], type:'select', choices:'AJXP_AVAILABLE_REPOSITORIES', description:globalMessages['ajxp_admin.home.70']},
                {name:'filenameFilter', label:globalMessages['ajxp_admin.home.71'], description:globalMessages['ajxp_admin.home.72'], type:'string'},
                {name:'interval',label:globalMessages['ajxp_admin.home.18'], type:'integer', default:300}
            ]
        },

        propTypes:{
            queryName:React.PropTypes.string,
            title:React.PropTypes.string,
            defaultInterval:React.PropTypes.number,
            style:React.PropTypes.object,
            className:React.PropTypes.string,
            zDepth:React.PropTypes.number
        },

        getDefaultProps:function(){
            return {style:{width:540, height:350, zDepth:1}};
        },

        getInitialState:function(){
            return {
                start:0,
                count:this.props.defaultInterval || 7
            };
        },

        triggerReload:function(){
            if(this.state.start === 0){
                this.refs['chart'].triggerReload();
            }
        },

        onPaginatorChange: function(start, count){
            this.setState({start:start, count:count});
        },

        onGraphDataLoaded: function(data){
            this.setState({links:data.links});
        },

        render: function(){

            var containerW = parseInt(this.props.style.width);
            var containerH = parseInt(this.props.style.height);
            var className = (this.props.className?this.props.className + ' ':'') + 'graphs-card';

            var filters = this.props.filters || {};
            if(this.props.workspaceFilter && this.props.workspaceFilter != -1) {
                filters["ws_id"] = this.props.workspaceFilter;
            }
            if(this.props.filenameFilter) {
                filters["filename_filter"] = this.props.filenameFilter;
            }

            return (
                <ReactMUI.Paper
                    {...this.props}
                    className={className}
                    zDepth={this.props.zDepth}
                    style={this.mergeStyleWithFocus()}>
                    {this.getCloseButton()}
                    <GraphPaginator
                        ref="paginator"
                        start={this.state.start}
                        count={this.state.count}
                        links={this.state.links}
                        onRangeChange={this.onPaginatorChange}
                        pickerOnShow={this.focusItem}
                        pickerOnDismiss={this.blurItem}
                    />
                    <h4>
                        {this.props.title}
                    </h4>
                    <div style={{margin:16, maxHeight:210}}>
                        <RemoteGraphLine
                            ref="chart"
                            queryName={this.props.queryName}
                            filters={filters}
                            start={this.state.start}
                            count={this.state.count}
                            onDataLoaded={this.onGraphDataLoaded}
                            width={containerW-40}
                            height={containerH-90}
                        />
                    </div>
                </ReactMUI.Paper>
            );
        }

    });

    var RichLogsList = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            remoteFilter:React.PropTypes.object,
            localFilter:React.PropTypes.object,
            dateRange:React.PropTypes.string,
            limit:React.PropTypes.number
        },

        getDefaultProps: function(){
            return {
                dateRange:'last_day',
                limit:30
            };
        },

        getInitialState:function(){
            return {logs:[]}
        },

        parseLogs: function(jsonResponse){
            var logs = jsonResponse['LOGS'];
            var users = jsonResponse['USERS'];
            var workspaces = jsonResponse['WORKSPACES'];
            var data = logs.map(function(log){
                if(log['logdate'] instanceof Object){
                    log['date'] = log['logdate']['date'];
                }else{
                    log['date'] = log['logdate'];
                }
                try{
                    var u = users[log['user']];
                    var uLabel = u['AJXP_REPO_SCOPE_ALL']['core.conf']['USER_DISPLAY_NAME'];
                    if(uLabel){
                        log['user_label'] = uLabel;
                    }
                }catch(e){}
                if(log['repository_id'] && workspaces && workspaces[log['repository_id']]){
                    log['repository_label'] = workspaces[log['repository_id']];
                }
                return log;
            }.bind(this));
            if(!data.length){
                data.push({message:this.context.getMessage('home.31', 'ajxp_admin'), readable_date:'', severity:''});
            }
            this.setState({logs:data});
        },

        loadLogs:function(){
            this.firstLoad = null;
            var params = {
                get_action:'rich_logs_list',
                /*date_range:this.props.dateRange,*/
                limit:this.props.limit
            };
            if(this.props.remoteFilter){
                params = LangUtils.objectMerge(params, this.props.remoteFilter);
            }
            PydioApi.getClient().request(params, function(transport){
                if( !this.isMounted() ) return ;
                this.parseLogs(transport.responseJSON);
            }.bind(this));
        },

        componentDidMount:function(){
            this.firstLoad = global.setTimeout(this.loadLogs, 500);
        },

        componentWillUnmount: function(){
            if(this.firstLoad){
                global.clearTimeout(this.firstLoad);
            }
        },

        render: function(){

            var index = 0;
            var logs = this.state.logs.map(function(log){
                if(log.params == "context=API" ) return null;
                if(this.props.localFilter){
                    for(var key in log){
                        if(log.hasOwnProperty(key)){
                            if(this.props.localFilter[key]){
                                var testValues = this.props.localFilter[key].split('|');
                                if(testValues.indexOf(log[key]) === -1){
                                return null;
                            }
                        }
                    }
                }
                }
                index ++;
                var logIcon;
                if(log.severity == 'ERROR'){
                    logIcon = <span className="icon-warning-sign"></span>
                }
                var secondMeta = <span className="log-user">{log.user_label?log.user_label:log.user}</span>;
                if(this.props.remoteFilter && this.props.remoteFilter['user']){
                    if(log.repository_id){
                        secondMeta = <span className="log-user">{log.repository_label ? log.repository_label : (this.context.getMessage('79', 'ajxp_conf') + ' ' + log.repository_id)}</span>;
                    }else{
                        secondMeta = null;
                    }
                }
                return (
                    <div key={index} className={"log log-" + log.severity} title={log.params}>
                        <div className="log-title">
                            <span className="log-date">{logIcon} {log['readable_date']? log['readable_date'] : (this.props.dateRange == 'last_day' ?  log.date.split(' ').pop() : log.date)}</span>
                            <span className="log-action">{log.message}</span>
                        </div>
                        <div className="log-meta">
                            {secondMeta}
                        </div>
                        <div className="log-data">
                            <span className="log-params">{(log.params?log.params:'')}</span>
                        </div>
                    </div>
                );
            }.bind(this));

            return (
                <div className={(this.props.className?this.props.className:'') + ' recent-logs'}>
                    {logs}
                    <div style={{textAlign:'center', padding:16}}>
                        <ReactMUI.FlatButton
                            secondary={true}
                            onClick={function(){global.pydio.goTo('/admin/logs');}}
                            label={this.context.getMessage('home.74', 'ajxp_admin')}
                            />
                    </div>
                </div>
            );

        }

    });

    var RecentLogs = React.createClass({

        mixins:[ReloadMixin, GridItemMixin, MessagesConsumerMixin],

        statics:{
            gridWidth:3,
            gridHeight:26,
            builderDisplayName:globalMessages['ajxp_admin.home.32'],
            builderFields:[
                {name:'interval',label:globalMessages['ajxp_admin.home.18'], type:'integer', default:120}
            ]
        },

        getInitialState:function(){
            return {filter:{}}
        },

        changeFilter:function(ev, index, item){
            this.setState({filter:item.payload});
        },

        triggerReload:function(){
            this.refs['logList'].loadLogs();
        },

        render: function(){

            var iconMenuItems = [
                {payload:{}, text:this.context.getMessage('home.33')},
                {payload:{severity:'ERROR|WARNING'}, text:this.context.getMessage('home.34')}
            ];
            var taggedItems = iconMenuItems.map(function(item){
                if(JSON.stringify(item.payload) == JSON.stringify(this.state.filter)){
                    item.text = '[' + item.text + ']';
                }else{
                    item.text = ' ' + item.text;
                }
                return item;
            }.bind(this));

            var dropDown = (
                <div className="logs-filter">
                <ReactMUI.DropDownIcon
                    onChange={this.changeFilter}
                    autoWidth={false}
                    iconClassName="icon-angle-down"
                        menuItems={taggedItems}
                />
                </div>
            );

            return (
                <ReactMUI.Paper {...this.props} zDepth={1}>
                    {this.getCloseButton()}
                    {dropDown}
                    <h4>{this.context.getMessage('home.32')}</h4>
                    <RichLogsList ref="logList" localFilter={this.state.filter}/>
                </ReactMUI.Paper>
            );

        }

    });

    var ServerStatus = React.createClass({

        mixins:[ReloadMixin, GridItemMixin, MessagesConsumerMixin],

        statics:{
            gridWidth:5,
            gridHeight:26,
            builderDisplayName:globalMessages["ajxp_admin.home.35"],
            builderFields:[
                {name:'interval',label:globalMessages['ajxp_admin.home.18'], type:'integer', default:20},
            ]
        },

        getInitialState:function(){
            return {cpu:0,disk:{free:0,total:1}, load:['-','-','-']}
        },

        loadStatus:function(){
            this.firstLoad = null;
            PydioApi.getClient().request({
                get_action:'system_status'
            }, function(transport){
                if( !this.isMounted() ) return ;
                this.setState(transport.responseJSON);
            }.bind(this), null, {discrete:true});
        },

        componentDidMount:function(){
            this.firstLoad = global.setTimeout(this.loadStatus, 500);
        },

        componentWillUnmount: function(){
            if(this.firstLoad){
                global.clearTimeout(this.firstLoad);
            }
        },

        triggerReload:function(){
            this.loadStatus();
        },

        render: function(){
            var cpuData = [
                {
                    value: this.state.cpu,
                    color:"rgba(247, 70, 74, 0.51)",
                    highlight: "#FF5A5E",
                    label: this.context.getMessage("home.36")
                },
                {
                    value: 100 - this.state.cpu,
                    color: "rgba(70, 191, 189, 0.59)",
                    highlight: "#5AD3D1",
                    label: this.context.getMessage("home.37")
                }
            ];
            var freePercent = Math.round(this.state.disk.free / this.state.disk.total * 100);
            var diskData = [
                {
                    value: 100 - freePercent,
                    color:"rgba(247, 70, 74, 0.51)",
                    highlight: "#FF5A5E",
                    label: this.context.getMessage("home.38")
                },
                {
                    value: freePercent,
                    color: "rgba(70, 191, 189, 0.59)",
                    highlight: "#5AD3D1",
                    label: this.context.getMessage("home.39")
                }
            ];

            return (
                <ReactMUI.Paper
                    {...this.props}
                    zDepth={1}>
                    {this.getCloseButton()}
                    <h4>{this.context.getMessage('home.35')}</h4>
                    <div className="server-status">
                        <div className="doughnut-chart">
                            <h5>{this.context.getMessage('home.40')}</h5>
                            <ReactChart.Doughnut
                                data={cpuData}
                                options={{}}
                                width={200}
                            />
                            <span className="figure">{this.state.cpu}%</span>
                        </div>
                        <div className="doughnut-chart">
                            <h5>{this.context.getMessage('home.41')}</h5>
                            <ReactChart.Doughnut
                                data={diskData}
                                options={{}}
                                width={200}
                            />
                            <span className="figure">{100 - freePercent}%</span>
                        </div>
                    </div>
                    <div>
                        <h4>{this.context.getMessage('home.42')}</h4>
                        <div className="server-loads">
                            <span className="server-load legend">1mn</span>
                            <span className="server-load legend">5mn</span>
                            <span className="server-load legend">15mn</span>
                        </div>
                        <div className="server-loads">
                            <span className="server-load">{this.state.load[0]!='-'?Math.round(this.state.load[0]*100)/100:'-'}</span>
                            <span className="server-load">{this.state.load[1]!='-'?Math.round(this.state.load[1]*100)/100:'-'}</span>
                            <span className="server-load">{this.state.load[2]!='-'?Math.round(this.state.load[2]*100)/100:'-'}</span>
                        </div>
                    </div>
                </ReactMUI.Paper>
            );

        }

    });

    var QuickLinks = React.createClass({
        mixins:[GridItemMixin, MessagesConsumerMixin],
        statics:{
            gridWidth:8,
            gridHeight:4,
            builderDisplayName:globalMessages["ajxp_admin.home.1"],
            builderFields:[]
        },

        getInitialState:function(){
            if(this.props.preferencesProvider){
                var links = this.props.preferencesProvider.getUserPreference('QuickLinks');
                if(links && typeof links == "object"){
                    return {links:links, edit:false};
                }
            }
            return {
                edit:false,
                links:[
                    {
                        path:'/data/users',
                        iconClass:'icon-user',
                        label:this.context.getMessage('2', 'ajxp_conf'),
                        description:this.context.getMessage('139', 'ajxp_conf')
                    },
                    {
                        path:'/data/repositories',
                        iconClass:'icon-hdd',
                        label:this.context.getMessage('3', 'ajxp_conf'),
                        description:this.context.getMessage('138', 'ajxp_conf')
                    }
                ]
            };
        },

        menuClicked:function(event, index, item){

            if(index > 0 && item.payload){
                var node = item.payload;
                var newLinks = this.state.links;
                var already = false;
                newLinks.map(function(l){
                    if(l.path == node.getPath()) already = true;
                });
                if(already) return;
                newLinks.push({
                    path:node.getPath(),
                    label:node.getLabel().replace('---', ''),
                    description:node.getMetadata().get('description'),
                    iconClass:node.getMetadata().get('icon_class')
                });
                if(this.props.preferencesProvider){
                    this.props.preferencesProvider.saveUserPreference('QuickLinks', newLinks);
                }
                this.setState({links:newLinks});
            }

        },

        removeLink: function(payload, event){

            var links = this.state.links;
            var newLinks = [];
            links.map(function(l){
                if(l.path != payload) newLinks.push(l);
            });
            if(this.props.preferencesProvider){
                this.props.preferencesProvider.saveUserPreference('QuickLinks', newLinks);
            }
            this.setState({links:newLinks});

        },

        toggleEdit: function(){
            if(!this.state.edit){
                this.focusItem();
            }else{
                this.blurItem();
            }
            this.setState({edit:!this.state.edit});
        },

        render: function(){
            var links = this.state.links.map(function(l){
                var label;
                if(this.state.edit){
                    label = <span><span className={'icon-remove button-icon'}></span> {l.label}</span>
                    return(
                        <ReactMUI.FlatButton
                            key={l.path}
                            secondary={false}
                            onClick={this.removeLink.bind(this, l.path)}
                            label={label}
                        />
                    );
                }else{
                    label = <span><span className={l.iconClass + ' button-icon'}></span> {l.label}</span>
                    return(
                        <ReactMUI.FlatButton
                            key={l.path}
                            secondary={true}
                            onClick={function(){global.pydio.goTo(l.path);}}
                            label={label}
                        />
                    );
                }
            }.bind(this));
            var dropDown;
            if(this.state.edit){
                var menuItems = [{text:this.context.getMessage('home.43'), payload:-1}];
                var rootNode = global.pydio.getContextHolder().getRootNode();
                var contextNode = global.pydio.getContextHolder().getContextNode();
                AdminComponents.NavigationHelper.buildNavigationItems(rootNode, contextNode, menuItems);
                dropDown = (
                    <div>
                        <ReactMUI.DropDownMenu onChange={this.menuClicked} menuItems={menuItems} />
                    </div>
                );
            }else{
                dropDown = <h4>{this.context.getMessage('home.1')}</h4>;
            }
            return (
                <ReactMUI.Paper
                    {...this.props}
                    className="quick-links"
                    zDepth={1}
                    style={this.mergeStyleWithFocus()}
                >
                    {this.getCloseButton()}
                    {dropDown}
                    {links}
                    <ReactMUI.IconButton onClick={this.toggleEdit} iconClassName={'icon-' + (this.state.edit?'ok':'edit')} secondary={this.state.edit}/>
                </ReactMUI.Paper>
            );
        }
    });

    var ToDoList = React.createClass({
        mixins:[GridItemMixin, MessagesConsumerMixin],
        statics:{
            gridWidth:3,
            gridHeight:20,
            builderDisplayName:globalMessages['ajxp_admin.home.75'],
            builderFields:[
                {name:'title',label:globalMessages['ajxp_admin.home.30'], type:'string', mandatory:true, 'default':globalMessages['ajxp_admin.home.75']}
            ]
        },

        propTypes:{
            title:React.PropTypes.string
        },

        getInitialState:function(){
            if (this.props.preferencesProvider){
                var tasks = this.props.preferencesProvider.getUserPreference('ToDoList-' + this.props['widgetId']);
                if(tasks && typeof tasks == "object"){
                    return {tasks:tasks, edit:false};
                }
            }
            return {
                edit:false,
                tasks:[
                    {
                        label:this.context.getMessage("home.77", "ajxp_admin"),
                        isDone:false
                    },
                    {
                        label:this.context.getMessage("home.77", "ajxp_admin") +  " ("+this.context.getMessage("home.78", "ajxp_admin")+")",
                        isDone:true
                    }
                ]
            };
        },

        addTask: function(){
            if (this.refs.taskName.getValue().length == 0)
                return;
            var newTasks = this.state.tasks;
            newTasks.push({
                label:this.refs.taskName.getValue(),
                isDone:false
            });
            if(this.props.preferencesProvider){
                this.props.preferencesProvider.saveUserPreference('ToDoList-' + this.props['widgetId'], newTasks);
            }
            this.setState({tasks:newTasks});
            this.refs.taskName.setValue("");
        },
        handleNewTaskKeyDown: function(event) {
            if (event.keyCode == 13) {
                this.addTask();
            }
        },
        removeTask: function(index){
            var tasks = this.state.tasks;
            var newTasks = [];
            for(var i=0; i < tasks.length; i++)
                if(i != index)
                    newTasks.push(tasks[i]);
            if(this.props.preferencesProvider){
                this.props.preferencesProvider.saveUserPreference('ToDoList-' + this.props['widgetId'], newTasks);
            }
            this.setState({tasks:newTasks});
        },

        changeTaskState: function(index){
            var tasks = this.state.tasks;
            var newTasks = [];
            for(var i=0; i < tasks.length; i++)
                if(i == index)
                    newTasks.push({label: tasks[i].label, isDone: !(tasks[i].isDone)});
                else
                    newTasks.push(tasks[i]);
            if(this.props.preferencesProvider){
                this.props.preferencesProvider.saveUserPreference('ToDoList-' + this.props['widgetId'], newTasks);
            }
            this.setState({tasks:newTasks});
        },

        render: function(){
            var index = -1;
            var tasks = this.state.tasks.map(function(item){
                index++;
                var taskLabel;
                if (item.isDone)
                    taskLabel = (
                        <p className="task-done" title={item.label}>
                            {item.label}
                        </p>
                    );
                else
                    taskLabel = (
                        <p title={item.label}>
                            {item.label}
                        </p>
                    );

                return(
                    <div
                        className="todo-item" key={"task"+index}>
                        <ReactMUI.Checkbox
                            onClick={this.changeTaskState.bind(this, index)}

                            checked={item.isDone}
                        />
                        {taskLabel}
                        <span
                            onClick={this.removeTask.bind(this, index)}
                            className={'icon-remove button-icon delete-todo-item-button'}
                        />

                    </div>
                );
            }.bind(this));
            var addBar = (
                    <div className="todo-add-bar">
                        <ReactMUI.TextField onKeyDown={this.handleNewTaskKeyDown} hintText={globalMessages['ajxp_admin.home.76']} ref="taskName" />
                    </div>
                );
            return (
                <ReactMUI.Paper
                    {...this.props}
                    className="todo-list"
                    style={this.mergeStyleWithFocus()}
                    zDepth={1}>
                    {this.getCloseButton()}
                    {<h4>{this.props.title}</h4>}
                    {addBar}
                    <div className="tasks-list">
                        {tasks}
                    </div>
                </ReactMUI.Paper>
            );
        }
    });


    var WelcomePanel = React.createClass({

        mixins:[GridItemMixin, MessagesConsumerMixin],
        statics:{
            gridWidth:8,
            gridHeight:15,
            builderDisplayName:globalMessages["ajxp_admin.home.44"],
            builderFields:[]
        },

        render: function(){
            var context = this.context;
            var getContent = function(){
                return {__html:context.getMessage('home.getting_started')};
            };
            return (
                <ReactMUI.Paper
                    {...this.props}
                    className="welcome-panel"
                    zDepth={1}>
                    {this.getCloseButton()}
                    <div className="screencast">
                        <img src="plugins/access.ajxp_admin/images/screencast.gif"/>
                    </div>
                    <h4>{this.context.getMessage("home.44")}</h4>
                    <div className="getting-started-content" dangerouslySetInnerHTML={getContent()}></div>
                    <ReactMUI.FlatButton
                        className="remove-welcome"
                        primary={true}
                        iconClassName="mdi mdi-close"
                        label={this.context.getMessage('home.45')}
                        onClick={this.props.onCloseAction}
                    />
                </ReactMUI.Paper>
            );
        }

    });

    var DashboardBuilder = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            namespaces:React.PropTypes.array,
            onCreateCard:React.PropTypes.func,
            onEditStatusChange:React.PropTypes.func
        },

        getInitialState:function(){
            return {
                selectedIndex:0,
                availableWidgets:this.listAvailableWidgets()
            }
        },

        listAvailableWidgets:function(){
            var widgets = [];
            this.props.namespaces.map(function(ns){
                if(!global[ns]) return;
                for(var k in global[ns]){
                    if(global[ns].hasOwnProperty(k)){
                        var widgetClass = global[ns][k];
                        if(widgetClass.hasBuilderFields && widgetClass.hasBuilderFields()){
                            widgets.push({reactClass:widgetClass, fullName:ns+'.'+widgetClass.displayName});
                        }
                    }
                }
            });
            return widgets;
        },

        onDropDownChange:function(event, index, item){
            var defaultValues={};
            if(index != 0){
                item.payload['reactClass'].getBuilderFields().map(function(f){
                    if(f['default']) defaultValues[f.name] = f['default'];
                });
            }
            if(this.props.onEditStatusChange){
                this.props.onEditStatusChange((index != 0));
            }
            this.setState({
                selectedIndex:index,
                selectedWidget:item.payload,
                currentFormValues:defaultValues
            });
        },

        cancel:function(){
            if(this.props.onEditStatusChange){
                this.props.onEditStatusChange(false);
            }
            this.setState({selectedIndex:0});
        },

        onFormValueChange:function(newValues){
            this.setState({currentFormValues:newValues});
        },

        onFormSubmit:function(){
            var values = this.state.currentFormValues;
            var selectedWidget = this.state.selectedWidget;
            var title = (values.title?values.title:values.legend);
            if(!title) title = this.state.selectedWidget['reactClass'].builderDisplayName;
            this.props.onCreateCard({
                componentClass:selectedWidget.fullName,
                title:title,
                props:values
            });
            this.cancel();
        },

        resetLayout: function(){
            if(window.confirm(this.context.getMessage('home.51'))){
                this.props.onResetLayout();
            }
        },

        render:function(){

            var selectorItems = [{payload:0,text:this.context.getMessage('home.50')}].concat(
                this.state.availableWidgets.map(function(w, index){
                    return {payload:w, text:w['reactClass'].builderDisplayName};
                })
            );

            var selector = (
                <ReactMUI.DropDownMenu
                    menuItems={selectorItems}
                    onChange={this.onDropDownChange}
                    selectedIndex={this.state.selectedIndex}
                    autoWidth={false}
                    className="widget-type-selector"
                />
            );

            var form, add;
            if(this.state.selectedIndex != 0){
                var fields = this.state.selectedWidget['reactClass'].getBuilderFields();
                var defaultValues={};
                fields.map(function(f){
                    if(f['default']) defaultValues[f.name] = f['default'];
                });
                if(this.state.currentFormValues){
                    defaultValues = LangUtils.mergeObjectsRecursive(defaultValues, this.state.currentFormValues);
                }
                form =(
                    <PydioForm.FormPanel
                        parameters={fields}
                        depth={-1}
                        values={defaultValues}
                        onChange={this.onFormValueChange}
                    />
                );
                add = (
                    <div style={{textAlign:'center', paddingBottom:100}}>
                        <ReactMUI.RaisedButton label={this.context.getMessage('home.52')} onClick={this.onFormSubmit}/>
                        &nbsp;<ReactMUI.RaisedButton label={this.context.getMessage('54', '')} onClick={this.cancel}/>
                    </div>
                );
            }

            return (
                <ReactMUI.Paper
                    {...this.props}
                    zDepth={3}>
                    <h3>{this.context.getMessage('home.53')}</h3>
                    <div className="legend">
                        {this.context.getMessage('home.54')}
                        <br/>
                        {this.context.getMessage('home.55')}</div>
                    {selector}
                    {form}
                    {add}
                    <div style={{position:'absolute',bottom: 30,left: 10}}>
                        <ReactMUI.FlatButton disabled={(this.state.selectedIndex != 0)} label={this.context.getMessage('home.56')} secondary={true} onClick={this.resetLayout}/>
                    </div>
                </ReactMUI.Paper>
            );
        }

    });

    var GroupAdminDashboard = React.createClass({

        mixins:[MessagesConsumerMixin],

        renderLink: function(node){

            var label = <span><span className={node.iconClass + ' button-icon'}></span> {node.label}</span>
            return(
                <span style={{display:'inline-block', margin:'0 5px'}}>
                <ReactMUI.RaisedButton
                    key={node.path}
                    secondary={true}
                    onClick={function(){global.pydio.goTo(node.path);}}
                    label={label}
                />
                </span>
            );

        },

        render: function(){

            var baseNodes = [
                {
                    path:'/data/users',
                    label:this.context.getMessage('249', ''),
                    iconClass:'icon-user'
                },{
                    path:'/data/repositories',
                    label:this.context.getMessage('250', ''),
                    iconClass:'icon-hdd'
                }];
            return (
                <div style={{width:'100%', height:'100%'}}>
                    <ReactMUI.Paper zDepth={1} style={{margin:10}}>
                        <div style={{padding:10}}>{this.context.getMessage('home.67')}</div>
                        <div style={{padding:10, textAlign:'center'}}>
                            {baseNodes.map(function(n){return this.renderLink(n); }.bind(this))}
                            <br/>
                            <ReactMUI.FlatButton
                                label={this.context.getMessage('home.68')}
                                secondary={true}
                                onClick={function(){global.pydio.triggerRepositoryChange("ajxp_home");}}
                            />
                        </div>
                    </ReactMUI.Paper>
                </div>
            );
        }

    });

    var IssueDashboard = React.createClass({

        mixins:[MessagesConsumerMixin],

        render: function(){

            var issueMessage = global.pydio.getContextHolder().getRootNode().getMetadata().get("dashboard_issue");

            return (
                <div style={{width:'100%', height:'100%'}}>
                    <ReactMUI.Paper zDepth={1} style={{margin:10}}>
                        <div style={{padding:10}}><span className="icon-warning-sign"></span> {issueMessage}</div>
                    </ReactMUI.Paper>
                </div>
            );
        }

    });

    var Dashboard = React.createClass({

        mixins:[MessagesConsumerMixin],

        getUserPreference:function(prefName){
            var prefKey = 'AdminHome.Dashboard' + prefName;
            var guiPrefs = global.pydio.user.getPreference('gui_preferences', true);
            if(guiPrefs && guiPrefs[prefKey]){
                return guiPrefs[prefKey];
            }else{
                return null;
            }
        },

        saveUserPreference:function(prefName, prefValue){
            var prefKey = 'AdminHome.Dashboard' + prefName;
            var guiPrefs = global.pydio.user.getPreference('gui_preferences', true);
            if(!guiPrefs) guiPrefs = {};
            guiPrefs[prefKey] = prefValue;
            global.pydio.user.setPreference('gui_preferences', guiPrefs, true);
            global.pydio.user.savePreference('gui_preferences');
        },

        saveFullLayouts:function(allLayouts){
            var savedPref = this.getUserPreference('Layout');
            // Compare JSON versions to avoid saving unnecessary changes
            if(savedPref && this.previousLayout  && this.previousLayout == JSON.stringify(allLayouts)){
                return;
            }
            this.previousLayout = JSON.stringify(allLayouts);
            this.saveUserPreference('Layout', allLayouts);
        },

        saveCards:function(cards){
            this.saveUserPreference('Cards', cards);
        },

        onLayoutChange: function(currentLayout, allLayouts){
            this.saveFullLayouts(allLayouts);
        },

        removeCard:function(cardId){
            var index = -1;
            var currentCards = this.state.cards;
            currentCards.map(function(card, arrayIndex){
                if(card.id == cardId) index = arrayIndex;
            });
            if(index == -1){
                console.warn('Card ID not found, this is strange.', cardId);
                return;
            }
            var newCards;
            if(index == 0) newCards = currentCards.slice(1);
            else if(index == currentCards.length-1) newCards = currentCards.slice(0, -1);
            else newCards = currentCards.slice(0,index).concat(currentCards.slice(index+1));
            this.setState({cards:newCards}, function(){
                this.saveCards(this.state.cards);
            }.bind(this));
        },

        createCardId:function(cardDefinition, randomize=false){
            var id = LangUtils.computeStringSlug(cardDefinition['title']);
            if(randomize){
                id += '-' + Math.round(Math.random() * 100 + 10);
            }
            var alreadyExists = false;
            this.state.cards.map(function(card){
                if(card.id == id) alreadyExists = true;
            }.bind(this));
            if(alreadyExists){
                id = this.createCardId(cardDefinition, true);
            }
            return id;
        },

        addCard:function(cardDefinition){
            cardDefinition['id'] = this.createCardId(cardDefinition);
            this.setState({cards:this.state.cards.concat([cardDefinition])}, function(){
                this.saveCards(this.state.cards);
            }.bind(this));
        },

        resetCardsAndLayout:function(){
            this.saveUserPreference('Cards', null);
            this.saveUserPreference('Layout', null);
            this.setState(this.getInitialState());
        },

        getInitialState:function(){
            var cards = [
                {
                    id:'welcome_panel',
                    componentClass:'AdminHome.WelcomePanel',
                    props:{},
                    defaultPosition:{
                        x:0, y:0
                    }
                },
                {
                    id:'quick_links',
                    componentClass:'AdminHome.QuickLinks',
                    props:{},
                    defaultPosition:{
                        x:0, y:0
                    }
                },
                {
                    id:'connections_today',
                    componentClass:'AdminHome.GraphBadge',
                    props:{
                        queryName:"connections_per_day",
                        legend:this.context.getMessage('home.57'),
                        interval:60
                    },
                    defaultPosition:{
                        x:0, y:1
                    }
                },
                {
                    id:'downloads_today',
                    componentClass:'AdminHome.GraphBadge',
                    props:{
                        queryName:"downloads_per_day",
                        legend:this.context.getMessage('home.58'),
                        interval:60
                    },
                    defaultPosition:{
                        x:2, y:1
                    }
                },
                {
                    id:'uploads_this_week',
                    componentClass:'AdminHome.GraphBadge',
                    props:{
                        queryName:"uploads_per_day",
                        legend:this.context.getMessage('home.59'),
                        frequency:"week",
                        interval:60
                    },
                    defaultPosition:{
                        x:4, y:1
                    }
                },
                {
                    id:'sharedfiles_per_today',
                    componentClass:'AdminHome.GraphBadge',
                    props:{
                        queryName:"sharedfiles_per_day",
                        legend:this.context.getMessage('home.60'),
                        interval:60
                    },
                    defaultPosition:{
                        x:6, y:1
                    }
                },
                {
                    id:'most_active_user_today',
                    componentClass:'AdminHome.MostActiveBadge',
                    props:{
                        type:"user",
                        legend:this.context.getMessage('home.61'),
                        range:"last_day"
                    },
                    defaultPosition:{
                        x:0, y:6
                    }
                },
                {
                    id:'most_active_ip_last_week',
                    componentClass:'AdminHome.MostActiveBadge',
                    props:{
                        type:"ip",
                        legend:this.context.getMessage('home.62'),
                        range:"last_week"
                    },
                    defaultPosition:{
                        x:2, y:6
                    }
                },
                {
                    id:'most_downloaded_last_week',
                    componentClass:'AdminHome.MostActiveBadge',
                    props:{
                        type:"action",
                        legend:this.context.getMessage('home.63'),
                        range:"last_week",
                        actionName:"download"
                    },
                    defaultPosition:{
                        x:4, y:6
                    }
                },
                {
                    id:'most_previewed_last_week',
                    componentClass:'AdminHome.MostActiveBadge',
                    props:{
                        type:"action",
                        legend:this.context.getMessage('home.64'),
                        range:"last_week",
                        actionName:"preview"
                    },
                    defaultPosition:{
                        x:6, y:6
                    }
                },
                {
                    id:'files_activity',
                    componentClass:'AdminHome.GraphCard',
                    props:{
                        title:this.context.getMessage('home.65'),
                        queryName:"uploads_per_day,downloads_per_day,sharedfiles_per_day",
                        interval:60
                    },
                    defaultPosition:{
                        x:0, y:12
                    },
                    gridHandle:"h4"
                },
                {
                    id:'webconnections_graph',
                    componentClass:'AdminHome.GraphCard',
                    props:{
                        title:this.context.getMessage('home.66'),
                        queryName:"connections_per_day",
                        interval:60
                    },
                    defaultPosition:{
                        x:4, y:12
                    },
                    gridHandle:"h4"
                },
                {
                    id:'recent_logs',
                    componentClass:'AdminHome.RecentLogs',
                    props:{
                        interval:20
                    },
                    defaultPosition:{
                        x:0, y:26
                    },
                    gridHandle:"h4"
                },
                {
                    id:'server_status',
                    componentClass:'AdminHome.ServerStatus',
                    props:{
                        interval:10
                    },
                    defaultPosition:{
                        x:3, y:26
                    },
                    gridHandle:"h4"
                }
            ];

            var savedCards = this.getUserPreference('Cards');
            if(savedCards){
                cards = savedCards;
            }
            return {
                cards: cards,
                editMode:false
            }
        },

        toggleEditMode:function(){
            this.setState({editMode:!this.state.editMode});
        },

        render: function(){

            var index = 0;
            var lgLayout = [];
            var savedLayouts = this.getUserPreference('Layout');
            var layouts = {lg:[], md:[], sm:[], xs:[], xxs:[]};

            var items = this.state.cards.map(function(item){

                var props = LangUtils.deepCopy(item.props);
                var parts = item.componentClass.split(".");
                var classNS = parts[0];
                var className = parts[1];
                var classObject;
                if(global[classNS] && global[classNS][className]){
                    classObject = global[classNS][className];
                }else{
                    return null;
                }
                var itemKey = props['key'] = item['id'] || 'item_' + index;
                props.showCloseAction = this.state.editMode;
                props.onCloseAction = function(){
                    this.removeCard(itemKey);
                }.bind(this);
                props.preferencesProvider = this;
                var defaultX = 0, defaultY = 0;
                if(item.defaultPosition){
                    defaultX = item.defaultPosition.x;
                    defaultY = item.defaultPosition.y;
                }
                var defaultLayout = classObject.getGridLayout(defaultX, defaultY);
                if(item['gridHandle']){
                    defaultLayout['handle'] = item['gridHandle'];
                }
                defaultLayout['i'] = itemKey;

                for(var breakpoint in layouts){
                    if(!layouts.hasOwnProperty(breakpoint))continue;
                    var breakLayout = layouts[breakpoint];
                    // Find corresponding element in preference
                    var existing;
                    if(savedLayouts && savedLayouts[breakpoint]){
                        savedLayouts[breakpoint].map(function(gridData){
                            if(gridData['i'] == itemKey && gridData['h'] == defaultLayout['h']){
                                existing = gridData;
                            }
                        });
                    }
                    if(existing){
                        breakLayout.push(existing);
                    }else{
                        breakLayout.push(defaultLayout);
                    }
                }
                index++;
                return React.createElement(classObject, props);

            }.bind(this));

            var monitorWidgetEditing = function(status){
                this.setState({widgetEditing:status});
            }.bind(this);

            var builder;
            if(this.state.editMode){
                builder = <DashboardBuilder
                    className="admin-helper-panel"
                    namespaces={['AdminHome']}
                    onCreateCard={this.addCard}
                    onResetLayout={this.resetCardsAndLayout}
                    onEditStatusChange={monitorWidgetEditing}
                />;
            }

            return (
                <div style={{width:'100%', height:'100%'}} className={this.state.editMode?"builder-open":""}>
                    <div style={{position:'absolute',bottom:30,right:18, zIndex:11}}>
                        <ReactMUI.FloatingActionButton
                            tooltip={this.context.getMessage('home.49')}
                            onClick={this.toggleEditMode}
                            iconClassName={this.state.editMode?"icon-ok":"icon-edit"}
                            mini={this.state.editMode}
                            disabled={this.state.editMode && this.state.widgetEditing}
                        />
                    </div>
                    {builder}
                    <div className="home-dashboard">
                        <ReactGridLayout.Responsive
                            className="dashboard-layout"
                            cols={{lg: 10, md: 8, sm: 8, xs: 4, xxs: 2}}
                            layouts={layouts}
                            rowHeight={15}
                            onLayoutChange={this.onLayoutChange}
                        >
                            {items}
                        </ReactGridLayout.Responsive>
                    </div>
                </div>
            );
        }

    });

    /*************/
    /*  EXPORTS  */
    /*************/
    global.AdminHome = {
        Dashboard: Dashboard,
        GroupAdminDashboard:GroupAdminDashboard,
        IssueDashboard:IssueDashboard,
        GraphBadge:GraphBadge,
        GraphCard:GraphCard,
        MostActiveBadge:MostActiveBadge,
        RecentLogs:RecentLogs,
        RichLogsList:RichLogsList,
        ServerStatus:ServerStatus,
        GridItemMixin:GridItemMixin,
        ReloadMixin:ReloadMixin,
        QuickLinks:QuickLinks,
        ToDoList:ToDoList,
        WelcomePanel:WelcomePanel
    };

})(window);