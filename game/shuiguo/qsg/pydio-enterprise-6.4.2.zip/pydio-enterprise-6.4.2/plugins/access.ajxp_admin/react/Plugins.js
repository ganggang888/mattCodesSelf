(function(global){

    var MessagesConsumerMixin = AdminComponents.MessagesConsumerMixin;

    var PluginsList = React.createClass({

        mixins:[MessagesConsumerMixin],

        togglePluginEnable:function(node, toggled) {
            var nodeId = PathUtils.getBasename(node.getPath());
            var params = {
                get_action: "edit",
                sub_action: "edit_plugin_options",
                plugin_id: nodeId,
                DRIVER_OPTION_AJXP_PLUGIN_ENABLED: toggled ? "true" : "false",
                DRIVER_OPTION_AJXP_PLUGIN_ENABLED_ajxptype: "boolean"
            };
            PydioApi.getClient().request(params, function (transport) {
                node.getMetadata().set("enabled", this.context.getMessage(toggled?'440':'441', ''));
                this.forceUpdate();
            }.bind(this));
            return true;
        },

        renderListIcon:function(node){
            if(!node.isLeaf()){
                return (
                    <div>
                        <div className="icon-folder-open" style={{fontSize: 24,color: 'rgba(0,0,0,0.63)', padding: '20px 25px', display: 'block'}}></div>
                    </div>
                );
            }
            var onToggle = function(e, toggled){
                var res = this.togglePluginEnable(node, toggled);
                if(!res){

                }
            }.bind(this);

            return (
                <div style={{margin:'24px 16px'}}>
                    <ReactMUI.Toggle
                        ref="toggle"
                        className="plugin-enable-toggle"
                        name="plugin_toggle"
                        value="plugin_enabled"
                        defaultToggled={node.getMetadata().get("enabled") == this.context.getMessage('440', '')}
                        toggled={node.getMetadata().get("enabled") == this.context.getMessage('440', '')}
                        onToggle={onToggle}
                    />
                </div>
            );
        },

        renderSecondLine:function(node){
            return node.getMetadata().get('plugin_description');
        },

        renderActions:function(node){
            if(!node.isLeaf()){
                return null;
            }
            var edit = function(){
                if(this.props.openRightPane){
                    this.props.openRightPane({
                        COMPONENT:PluginEditor,
                        PROPS:{
                            rootNode:node,
                            docAsAdditionalPane:true,
                            className:"vertical edit-plugin-inpane",
                            closeEditor:this.props.closeRightPane
                        },
                        CHILDREN:null
                    });
                }
            }.bind(this);
            return (
                <div className="plugins-list-actions">
                    <ReactMUI.IconButton className="plugin-edit" iconClassName="icon-edit" onClick={edit}/>
                </div>
            );
        },

        render:function(){

            return (
                <ReactPydio.SimpleList
                    node={this.props.currentNode || this.props.rootNode}
                    dataModel={this.props.dataModel}
                    className="plugins-list"
                    actionBarGroups={[]}
                    entryRenderIcon={this.renderListIcon}
                    entryRenderActions={this.renderActions}
                    entryRenderSecondLine={this.renderSecondLine}
                    openEditor={this.props.openSelection}
                    infineSliceCount={1000}
                    filterNodes={null}
                    listTitle={this.props.title}
                    elementHeight={ReactPydio.SimpleList.HEIGHT_TWO_LINES}
                />
            );
        }

    });

    var CoreAndPluginsDashboard = React.createClass({

        render:function(){
            var coreId = PathUtils.getBasename(this.props.rootNode.getPath());
            if(coreId.indexOf("core.") !== 0) coreId = "core." + coreId ;
            var fakeNode = new AjxpNode('/' + coreId);
            var pluginsList = <PluginsList {...this.props} title={this.props.rootNode.getLabel()}/>;
            return (
                <PluginEditor
                    rootNode={fakeNode}
                    additionalPanes={{top:[], bottom:[pluginsList]}}
                />
            );
        }

    });

    var AuthenticationPluginsDashboard = React.createClass({

        mixins:[MessagesConsumerMixin],

        openSelection: function(node){
            this.props.openRightPane({
                COMPONENT:PluginEditor,
                PROPS:{
                    rootNode:node,
                    docAsAdditionalPane:true,
                    className:"vertical edit-plugin-inpane",
                    closeEditor:this.props.closeRightPane
                },
                CHILDREN:null
            });
        },

        render:function(){
            var fakeNode = new AjxpNode('/plugins/manager/authfront');
            var pluginsList = <PluginsList
                title={this.context.getMessage('plugtype.title.authfront', '')}
                dataModel={this.props.dataModel}
                node={fakeNode}
                rootNode={fakeNode}
                openSelection={this.openSelection}
            />;
            return (
                <PluginEditor
                    {...this.props}
                    additionalPanes={{top:[pluginsList], bottom:[]}}
                    tabs={[
                        {label:this.context.getMessage('plugins.1'), groups:[0,1,2,6]}, // general
                        {label:this.context.getMessage('plugins.2'), groups:[3]}, // master driver
                        {label:this.context.getMessage('plugins.3'), groups:[4,5]} // secondary driver
                    ]}
                />
            );
        }

    });

    var UpdaterDashboard = React.createClass({

        mixins:[MessagesConsumerMixin],

        componentDidMount:function(){
            this.checkForUpgrade();
        },

        checkForUpgrade: function(){
            this.setState({loading:true});
            PydioApi.getClient().request({get_action:'get_upgrade_path'}, function(transp){
                this.setState({loading:false});
                if(!this.isMounted()) return;
                var response = transp.responseJSON;
                var length = 0;
                if(response && response.packages.length){
                    length = response.packages.length;
                    this.setState({packages:response.packages});
                    if(response.latest_note){
                        let latest = response.latest_note;
                        latest = global.pydioBootstrap.parameters.get('ajxpServerAccess')+"&get_action=display_upgrade_note&url=" + encodeURIComponent(latest);
                        this.setState({src:latest});
                    }
                }else{
                    this.setState({no_upgrade:true});
                }

                var node = global.pydio.getContextNode();
                node.getMetadata().set('flag', length);
                AdminComponents.MenuItemListener.getInstance().notify("item_changed");

            }.bind(this));
        },

        performUpgrade: function(){
            if(global.confirm(this.context.getMessage('15', 'updater'))){
                var client = PydioApi.getClient();
                this.setState({src:''}, function(){
                    this.setState({src: client._baseUrl + '?secure_token=' + client._secureToken  + '&get_action=perform_upgrade'});
                }.bind(this));

            }
        },

        render:function(){

            var list = null;
            if(this.state && this.state.packages){
                list = (
                    <div style={{paddingBottom:30,paddingRight:5}}>
                        <span style={{float:'right'}}>
                            <ReactMUI.RaisedButton primary={true} label={this.context.getMessage('4', 'updater')} onClick={this.performUpgrade}/>
                        </span>
                        {this.context.getMessage('16', 'updater')}
                        <ul style={{paddingLeft:30}}>{this.state.packages.map(function(p){return <li style={{listStyle:'inherit'}} key={p}>{PathUtils.getBasename(p)}</li>;})}</ul>
                        <br/>{this.context.getMessage('3', 'updater')}
                    </div>
                );
            }else if(this.state && this.state.loading){
                list = (
                    <div>{this.context.getMessage('17', 'updater')}</div>
                );
            }else{
                list = (
                    <div>
                        <span style={{float:'right'}}>
                            <ReactMUI.RaisedButton secondary={true} label={this.context.getMessage('20', 'updater')} onClick={this.checkForUpgrade}/>
                        </span>
                            { (this.state && this.state.no_upgrade) ? this.context.getMessage('18', 'updater') : this.context.getMessage('19', 'updater') }
                    </div>
                );
            }

            var updateCheckPane = (
                <div style={{padding:'0 20px'}}>
                    <h3>{this.context.getMessage('2', 'updater')}</h3>
                    <div style={{paddingBottom:20,paddingRight:5}}>{list}</div>
                    <iframe
                        ref="iframe"
                        style={{width:'100%',height:400, border:'1px solid #ccc'}}
                        src={this.state?this.state.src:''}
                    ></iframe>
                </div>
            );

            return (
                <div className="update-checker" style={{height:'100%'}}>
                    <PluginEditor
                        {...this.props}
                        additionalPanes={{top:[updateCheckPane], bottom:[]}}
                    />
                </div>
            );
        }

    });

    var CacheServerDashboard = React.createClass({

        mixins:[MessagesConsumerMixin],

        getInitialState:function(){
            return {cacheStatuses:[], loading:false};
        },

        componentDidMount:function(){
            this.checkCacheStats();
        },

        clearCache: function(namespace){
            PydioApi.getClient().request({get_action:'cache_service_clear_cache', namespace:namespace}, function(transp) {
                this.checkCacheStats();
            }.bind(this));
        },

        checkCacheStats: function(){
            this.setState({loading:true});
            PydioApi.getClient().request({get_action:'cache_service_expose_stats'}, function(transp) {
                this.setState({loading: false});
                if (!this.isMounted()) return;
                var response = transp.responseJSON;
                this.setState({cacheStatuses:response});
                global.setTimeout(this.checkCacheStats.bind(this), 4000);
            }.bind(this));
        },

        renderCachePane: function(cacheData){
            let healthPercent = parseInt( 100 * cacheData.misses / cacheData.hits);
            let health;
            if(healthPercent < 5) {
                health = '< 5%';
            }else if(healthPercent < 20){
                health = '< 20%';
            }else if(healthPercent < 40){
                health = '< 40%';
            }else if(healthPercent < 60){
                health = '> 40%';
            }else{
                health = '> 60%';
            }
            
            return (
                <div>
                    <h4>Namespace '{cacheData.namespace}'</h4>
                    <div>
                        <div style={{width:'50%', float:'left'}}>
                            <div className="doughnut-chart">
                                <h5>Memory Usage</h5>
                                <ReactChart.Doughnut
                                    data={[{
                                        value: cacheData.memory_usage,
                                        color:"rgba(247, 70, 74, 0.51)",
                                        highlight: "#FF5A5E",
                                        label: "Memory Used"
                                    },{
                                        value: cacheData.memory_available - cacheData.memory_usage,
                                        color: "rgba(70, 191, 189, 0.59)",
                                        highlight: "#5AD3D1",
                                        label: "Memory Available"
                                    }]}
                                    options={{}}
                                    width={150}
                                />
                                <span className="figure">{parseInt( 100 * cacheData.memory_usage / cacheData.memory_available) }%</span>
                            </div>
                        </div>
                        <div style={{width:'50%', float:'left'}}>
                            <div className="doughnut-chart">
                                <h5>Cache Health</h5>
                                <ReactChart.Doughnut
                                    data={[{
                                        value: cacheData.misses,
                                        color:"rgba(247, 70, 74, 0.51)",
                                        highlight: "#FF5A5E",
                                        label: "Missed"
                                    },{
                                        value: cacheData.hits,
                                        color: "rgba(70, 191, 189, 0.59)",
                                        highlight: "#5AD3D1",
                                        label: "Hits"
                                    }]}
                                    options={{}}
                                    width={150}
                                />
                                <span className="figure">{health}</span>
                            </div>
                        </div>
                    </div>
                    <div>Uptime: {cacheData.uptime}</div>
                </div>
            );
        },

        renderClearButton:function(cacheData){
            return (
                <div style={{paddingBottom: 10}}>
                    <ReactMUI.RaisedButton
                        label={"Clear " + cacheData.namespace + " cache"}
                        onClick={this.clearCache.bind(this, cacheData.namespace)}
                    />
                </div>
            );
        },

        renderStatusPane: function(){
            var overall = (this.state.cacheStatuses.length?this.renderCachePane(this.state.cacheStatuses[0]):null);
            return (
                <div style={{padding:'0 20px'}}>
                    <h3>Status</h3>
                    <div>
                        {overall}
                    </div>
                    <h3>Cache Control</h3>
                    <div>
                        {this.state.cacheStatuses.map(this.renderClearButton.bind(this))}
                    </div>
                </div>
            );
        },

        render: function(){
            var pane = this.renderStatusPane();
            return (
                <div className="cache-server-panel" style={{height:'100%'}}>
                    <PluginEditor
                        {...this.props}
                        additionalPanes={{top:[], bottom:[pane]}}
                    />
                </div>
            );
        }

    });

    var EditorsDashboard = React.createClass({

        mixins:[MessagesConsumerMixin],

        render:function(){
            return(
                <div className="main-layout-nav-to-stack vertical-layout" style={this.props.style}>
                    <ReactMUI.Paper className="left-nav vertical-layout" zDepth={0}>
                        <h1>{this.context.getMessage('plugtype.title.editor', '')}</h1>
                        <div style={{padding:'0 20px'}} className="layout-fill-scroll-y">
                            {this.context.getMessage('plugins.4')}
                        </div>
                    </ReactMUI.Paper>
                    <PluginsList {...this.props}/>
                </div>
            );
        }

    });

    /**
     * Editor for a given plugin. By default, displays documentation in a left column panel,
     * and plugin parameters as form cards on the right.
     * May take additionalPanes to be appended to the form cards.
     */
    var PluginEditor = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            rootNode:React.PropTypes.instanceOf(AjxpNode).isRequired,
            close:React.PropTypes.func,
            style:React.PropTypes.string,
            className:React.PropTypes.string,
            additionalPanes:React.PropTypes.shape({
                top:React.PropTypes.array,
                bottom:React.PropTypes.array
            }),
            docAsAdditionalPane:React.PropTypes.bool,
            registerCloseCallback:React.PropTypes.func,
            onBeforeSave:React.PropTypes.func,
            onAfterSave:React.PropTypes.func
        },


        loadPluginData:function(plugId){

            PydioApi.getClient().request({
                get_action:'get_plugin_manifest',
                plugin_id:plugId
            }, function(transport){

                var xmlData = transport.responseXML;
                var params = PydioForm.Manager.parseParameters(xmlData, "//global_param");
                var xmlValues = XMLUtils.XPathSelectNodes(xmlData, "//plugin_settings_values/param");
                var documentation = XMLUtils.XPathSelectSingleNode(xmlData, "//plugin_doc");
                var enabledAlways = false;
                var rootNode = XMLUtils.XPathSelectSingleNode(xmlData, "admin_data");
                var label = rootNode.firstChild.attributes.getNamedItem("label").value;
                var description = rootNode.firstChild.attributes.getNamedItem("description").value;
                try{enabledAlways = rootNode.firstChild.attributes.getNamedItem("enabled").value === 'always';}catch (e){}

                var paramsValues = {};
                xmlValues.forEach(function(child){
                    if(child.nodeName != 'param') return;
                    var valueParamName = child.getAttribute("name");
                    if(child.getAttribute("cdatavalue")){
                        paramsValues[valueParamName] = child.firstChild.nodeValue;
                    }else{
                        paramsValues[valueParamName] = child.getAttribute('value');
                    }
                    var cType = null;
                    params.map(function(def){
                        if(def.name == valueParamName) cType = def.type;
                    });
                    if(cType == 'boolean') paramsValues[valueParamName] = (paramsValues[valueParamName] == "true");
                    else if(cType == 'integer') paramsValues[valueParamName] = parseInt(paramsValues[valueParamName]);
                });

                this.setState({
                    loaded: true,
                    parameters:params,
                    values:paramsValues,
                    originalValues:LangUtils.deepCopy(paramsValues),
                    documentation:documentation,
                    enabledAlways:enabledAlways,
                    dirty:false,
                    label:label,
                    description:description,
                    pluginId:plugId
                });

                if(this.props.registerCloseCallback){
                    this.props.registerCloseCallback(function(){
                        if(this.state && this.state.dirty && !global.confirm(this.context.getMessage('19','ajxp_role_editor'))){
                            return false;
                        }
                    }.bind(this));
                }

            }.bind(this));

        },

        componentWillReceiveProps:function(nextProps){
            if(nextProps.rootNode.getPath()!= this.props.rootNode.getPath()){
                this.loadPluginData(PathUtils.getBasename(nextProps.rootNode.getPath()));
                this.setState({values:{}});
            }
        },

        getInitialState:function(){

            var plugId = PathUtils.getBasename(this.props.rootNode.getPath());
            this.loadPluginData(plugId);

            return {
                loaded:false,
                parameters:[],
                values:{},
                documentation:'',
                dirty:false,
                label:'',
                docOpen:false
            };
        },

        onChange:function(formValues, dirty){
            this.setState({dirty:dirty, values:formValues});
        },

        save:function(){
            var clientParams = {
                get_action:"edit",
                sub_action:"edit_plugin_options",
                plugin_id:this.state.pluginId
            };
            var postParams = this.refs['formPanel'].getValuesForPOST(this.state.values);
            if(postParams['DRIVER_OPTION_AJXP_PLUGIN_ENABLED']){
                postParams['DRIVER_OPTION_AJXP_PLUGIN_ENABLED_ajxptype'] = "boolean";
            }
            clientParams = LangUtils.mergeObjectsRecursive(clientParams, postParams);
            if(this.props.onBeforeSave){
                this.props.onBeforeSave(clientParams);
            }
            PydioApi.getClient().request(clientParams, function(transport){
                this.setState({dirty:false});
                if(this.props.onAfterSave){
                    this.props.onAfterSave(transport);
                }
            }.bind(this));
        },

        revert:function(){
            this.setState({dirty:false, values:this.state.originalValues});
        },

        parameterHasHelper:function(paramName, testPluginId){
            paramName = paramName.split('/').pop();
            var h = PydioForm.Manager.hasHelper(PathUtils.getBasename(this.props.rootNode.getPath()), paramName);
            if(!h && testPluginId){
                h = PydioForm.Manager.hasHelper(testPluginId, paramName);
            }
            return h;
        },

        showHelper:function(helperData, testPluginId){
            if(helperData){
                var plugId = PathUtils.getBasename(this.props.rootNode.getPath());
                if(testPluginId && !PydioForm.Manager.hasHelper(plugId, helperData['name'])){
                    helperData['pluginId'] = testPluginId;
                }else{
                    helperData['pluginId'] = plugId;
                }
                helperData['updateCallback'] = this.helperUpdateValues.bind(this);
            }
            this.setState({helperData:helperData});
        },

        closeHelper:function(){
            this.setState({helperData:null});
        },

        /**
         * External helper can pass a full set of values and update them
         * @param newValues
         */
        helperUpdateValues:function(newValues){
            this.onChange(newValues, true);
        },

        toggleDocPane: function(){
            this.setState({docOpen:!this.state.docOpen});
        },

        monitorMainPaneScrolling:function(event){
            if(event.target.className.indexOf('pydio-form-panel') === -1){
                return;
            }
            var scroll = event.target.scrollTop;
            var newState = (scroll > 5);
            var currentScrolledState = (this.state && this.state.mainPaneScrolled);
            if(newState != currentScrolledState){
                this.setState({mainPaneScrolled:newState});
            }
        },

        render: function(){

            var addPanes = {top:[], bottom:[]};
            if(this.props.additionalPanes){
                addPanes.top = this.props.additionalPanes.top.slice();
                addPanes.bottom = this.props.additionalPanes.bottom.slice();
            }
            var closeButton;
            if(this.props.closeEditor){
                closeButton = <ReactMUI.RaisedButton label={this.context.getMessage('86','')} onClick={this.props.closeEditor} secondary={true}></ReactMUI.RaisedButton>
            }

            var doc = this.state.documentation;
            if(doc && this.props.docAsAdditionalPane){
                doc = doc.firstChild.nodeValue.replace('<p><ul', '<ul').replace('</ul></p>', '</ul>').replace('<p></p>', '');
                doc = doc.replace('<img src="', '<img style="width:90%;" src="plugins/' + this.state.pluginId + '/');
                var readDoc = function(){
                    return {__html:doc};
                };
                var docPane = (
                    <div className={"plugin-doc" + (this.state.docOpen?' plugin-doc-open':'')}>
                        <h3>Documentation</h3>
                        <div className="plugin-doc-pane" dangerouslySetInnerHTML={readDoc()}></div>
                    </div>
                );
                addPanes.top.push(docPane);
            }

            var scrollingClassName = '';
            if(this.state && this.state.mainPaneScrolled){
                scrollingClassName = ' main-pane-scrolled';
            }
            // Building  a form
            return (
                <div className={(this.props.className?this.props.className+" ":"") + "main-layout-nav-to-stack vertical-layout plugin-board" + scrollingClassName} style={this.props.style}>
                    <ReactMUI.Paper className="left-nav" zDepth={0}>
                        <h1>{this.state.label}</h1>
                        <div className="buttons-cont" style={{padding:16}}>
                            <ReactMUI.RaisedButton primary={true} disabled={!this.state.dirty} label={this.context.getMessage('plugins.5')} onClick={this.save}></ReactMUI.RaisedButton>
                            &nbsp;&nbsp;
                            <ReactMUI.RaisedButton disabled={!this.state.dirty} label={this.context.getMessage('plugins.6')} onClick={this.revert}></ReactMUI.RaisedButton>
                            &nbsp;&nbsp;&nbsp;
                            {closeButton}
                        </div>
                        <div className={"plugin-doc-pane"}>{this.state.description}.</div>
                    </ReactMUI.Paper>
                    <PydioForm.FormPanel
                        ref="formPanel"
                        className="row-flex"
                        parameters={this.state.parameters}
                        values={this.state.values}
                        onChange={this.onChange}
                        disabled={false}
                        additionalPanes={addPanes}
                        tabs={this.props.tabs}
                        setHelperData={this.showHelper}
                        checkHasHelper={this.parameterHasHelper}
                        onScrollCallback={this.monitorMainPaneScrolling}
                    />
                    <PydioForm.PydioHelper
                        helperData={this.state?this.state.helperData:null}
                        close={this.closeHelper}
                    />
                </div>
            );


        }
    });

    var PluginsManager = React.createClass({

        mixins:[MessagesConsumerMixin],

        clearCache: function(){
            PydioApi.getClient().request({
                get_action:'clear_plugins_cache'
            }, function(transp){
                this.refs.list.reload();
            }.bind(this));
        },

        render: function(){
            return (
                <div style={{height:'100%'}} className="vertical-layout">
                    <span style={{position:'absolute', marginTop:10, marginLeft:10}}>
                        <ReactMUI.RaisedButton
                            label={this.context.getMessage('129', 'ajxp_conf')}
                            onClick={this.clearCache}
                            />
                    </span>
                    <PluginsList {...this.props} ref="list"/>
                </div>
            );
        }

    });

    global.AdminPlugins = {
        PluginsManager:PluginsManager,
        PluginEditor:PluginEditor,
        PluginsList:PluginsList,
        CoreAndPluginsDashboard:CoreAndPluginsDashboard,
        AuthenticationPluginsDashboard:AuthenticationPluginsDashboard,
        EditorsDashboard:EditorsDashboard,
        UpdaterDashboard:UpdaterDashboard,
        CacheServerDashboard:CacheServerDashboard
    };

})(window);