(function(global){

    var MessagesConsumerMixin = AdminComponents.MessagesConsumerMixin;

    var WorkspaceModel = global.ReactModel.Workspace;

    var MetaSourceForm = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            modalData:React.PropTypes.object
        },

        getInitialState:function(){
            return {step:'chooser'};
        },

        getTitle:function(){
            return this.context.getMessage('ws.46');
        },

        getButtons:function(){
            return [
                { text: this.context.getMessage('54', ''), ref: 'cancel' },
                { text: this.context.getMessage('53', ''), ref: 'submit', onClick:this.submit }
            ];
        },

        setModal:function(pydioModal){
            this.setState({modal:pydioModal});
        },

        submit:function(){
            if(this.state.pluginId && this.state.pluginId !== -1){
                if(this.state.modal) this.state.modal.hide();
                this.props.modalData.payload.editor.addMetaSource(this.state.pluginId);
            }
        },

        render:function(){
            var model = this.props.modalData['payload']['model'];
            var currentMetas = model.getOption("META_SOURCES", true);
            var allMetas = model.getAllMetaSources();

            // Step is Chooser: build a DropDownMenu
            var menuItems = [{payload:-1, text:this.context.getMessage('ws.47')}];
            allMetas.map(function(metaSource){
                var id = metaSource['id'];
                var type = id.split('.').shift();
                if(type == 'metastore' || type == 'index'){
                    var already = false;
                    Object.keys(currentMetas).map(function(metaKey){
                        if(metaKey.indexOf(type) === 0) already = true;
                    });
                    if(already) return;
                }else{
                    if(currentMetas[metaSource['id']]) return;
                }
                menuItems.push({payload:metaSource['id'], text:metaSource['label']});
            });
            var change = function(event, index, item){
                this.setState({pluginId:item.payload});
            }.bind(this);
            return (
                <ReactMUI.DropDownMenu
                    menuItems={menuItems} onChange={change}
                />
            );
        }

    });

    var FoldersList = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            model:React.PropTypes.instanceOf(WorkspaceModel).isRequired,
            currentMask:React.PropTypes.object,
            onMaskChange:React.PropTypes.func,

            globalPermissions:React.PropTypes.object
        },

        render: function(){

            if(this.props.model.supportsFoldersBrowsing()){
                return (
                    <div>
                        <h1 style={{margin: 16}}>
                            {this.context.getMessage('ws.42')}
                            <div className="section-legend">
                                {this.context.getMessage('ws.43')}
                                <br/>
                                {this.context.getMessage('ws.44')}
                            </div>
                        </h1>
                        <AdminComponents.PermissionMaskEditor
                            mask={this.props.currentMask || this.props.model.getPermissionMask()}
                            workspaceId={this.props.model.wsId}
                            onMaskChange={this.props.onMaskChange}
                            globalWorkspacePermissions={this.props.globalPermissions}
                            />
                    </div>
                );
            }else{
                return (
                    <div>
                        <h1 style={{margin: 16}}>
                            {this.context.getMessage('ws.42')}
                            <div className="section-legend">
                                {this.context.getMessage('ws.45')}
                                <br/>
                                {this.context.getMessage('ws.44')}
                            </div>
                        </h1>
                        <AdminComponents.PermissionMaskEditorFree
                            mask={this.props.currentMask || this.props.model.getPermissionMask()}
                            workspaceId={this.props.model.wsId}
                            onMaskChange={this.props.onMaskChange}
                            globalWorkspacePermissions={this.props.globalPermissions}
                            />
                    </div>
                );
            }
        }

    });

    var SharesList = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            model:React.PropTypes.instanceOf(WorkspaceModel).isRequired
        },

        render: function(){
            return (
                <div className="layout-fill vertical-layout">
                    <h1  className="workspace-general-h1">{this.context.getMessage('ws.38')}</h1>
                    <ReactMUI.Paper zDepth={1} className="workspace-activity-block layout-fill vertical-layout">
                        <ReactPydio.NodeListCustomProvider
                            title={this.context.getMessage('ws.25')}
                            nodeProviderProperties={{
                                get_action:"sharelist-load",
                                parent_repository_id:this.props.model.wsId,
                                user_context:"global"
                            }}
                            tableKeys={{
                                owner:{label:this.context.getMessage('ws.39'), width:'20%'},
                                share_type_readable:{label:this.context.getMessage('ws.40'), width:'15%'},
                                original_path:{label:this.context.getMessage('ws.41'), width:'80%'}
                            }}
                            actionBarGroups={['share_list_toolbar-selection', 'share_list_toolbar']}
                            groupByFields={['owner','share_type_readable']}
                            defaultGroupBy="share_type_readable"
                            elementHeight={ReactPydio.SimpleList.HEIGHT_ONE_LINE}
                        />
                    </ReactMUI.Paper>
                </div>
            );
        }
    });

    var TplChildrenList = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            node:React.PropTypes.instanceOf(AjxpNode).isRequired,
            model:React.PropTypes.instanceOf(WorkspaceModel).isRequired
        },

        render: function(){
            return (
                <div>
                    <h1  className="workspace-general-h1">{this.context.getMessage('ws.37')}</h1>
                    <ReactMUI.Paper zDepth={1} className="workspace-activity-block layout-fill vertical-layout">
                        <ReactPydio.NodeListCustomProvider
                        title={this.context.getMessage('ws.37')}
                        nodeProviderProperties={{
                            get_action:"ls",
                            dir: PathUtils.getDirname(this.props.node.getPath()),
                            template_children_id:this.props.model.wsId
                        }}
                        actionBarGroups={[]}
                        elementHeight={ReactPydio.SimpleList.HEIGHT_ONE_LINE}
                        />
                    </ReactMUI.Paper>
                </div>
            );
        }
    });

    var WorkspaceSummaryCard = React.createClass({

        render:function(){
            return <ReactMUI.Paper className="workspace-card" zDepth={1}>
                <div className={this.props.icon + ' icon-card'}></div>
                <div className='card-content'>{this.props.children}</div>
            </ReactMUI.Paper>;
        }

    });

    var WorkspaceSummary = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            model:React.PropTypes.instanceOf(WorkspaceModel).isRequired
        },

        getInitialState:function(){
            return {optionsLoaded:false, workspaceInfo:null};
        },

        loadInfo: function(model){
            var optionsLoadedFunc = function(){
                this.setState({optionsLoaded:true});
            }.bind(this);
            if(model.loaded) optionsLoadedFunc();
            else model.observe('loaded', optionsLoadedFunc);
        },

        componentDidMount:function(){
            this.loadInfo(this.props.model);
        },

        componentWillReceiveProps:function(newProps){
            this.loadInfo(newProps.model);
        },

        render:function(){
            var driverIcon = 'icon-hdd', driverName, driverDescription;
            var aclsTitle, aclsDescriptions;
            if(this.state.optionsLoaded){
                driverIcon = this.props.model.getDriverIconClass();
                driverName = this.props.model.getDriverLabel();
                driverDescription = this.props.model.getDescriptionFromDriverTemplate();

                var totalUsers = this.props.model.getSingleNodeTextFromXML("admin_data/additional_info/users/@total");
                var sharedFolders = this.props.model.getSingleNodeTextFromXML("admin_data/additional_info/shares/@total");
                aclsTitle = <span>{this.context.getMessage('ws.35').replace('%i', totalUsers)}</span>;
                aclsDescriptions = <span>{this.context.getMessage('ws.36').replace('%i', sharedFolders)}</span>
            }

            return (
                <div className="workspace-cards-container">
                    <WorkspaceSummaryCard icon={driverIcon}>
                        <h4>{driverName}</h4>
                        <h5>{driverDescription?driverDescription:" "}</h5>
                    </WorkspaceSummaryCard>
                    <WorkspaceSummaryCard icon="icon-group">
                        <h4>{aclsTitle}</h4>
                        <h5>{aclsDescriptions}</h5>
                    </WorkspaceSummaryCard>
                    <span style={{clear:'left'}}/>
                </div>
            );
        }

    });

    var WorkspaceActivity = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            model:React.PropTypes.instanceOf(WorkspaceModel).isRequired
        },

        render:function(){
            return (
                <div className="layout-fill" style={{overflowY:'auto'}}>
                    <WorkspaceSummary model={this.props.model}/>
                    <ReactMUI.Paper zDepth={1} className="workspace-activity-block">
                        <h3>{this.context.getMessage('ws.33')}</h3>
                        <div>
                            <AdminHome.GraphCard
                                queryName="downloads_per_day,uploads_per_day,sharedfiles_per_day"
                                title={this.context.getMessage('home.65')}
                                filters={{ws_id:this.props.model.wsId}}
                                style={{height:300, width:'100%'}}
                                zDepth={0}
                                />
                        </div>

                    </ReactMUI.Paper>
                    <ReactMUI.Paper zDepth={1} className="workspace-activity-block">

                        <h3>{this.context.getMessage('ws.34')}</h3>
                        <AdminHome.RichLogsList
                            remoteFilter={{
                                workspace:this.props.model.wsId,
                                operations:'files'
                            }}
                            dateRange={null}
                            />

                    </ReactMUI.Paper>
                </div>
            );
        }

    });

    var MetaList = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes: {
            currentMetas: React.PropTypes.object,
            edit:React.PropTypes.string,
            metaSourceProvider:React.PropTypes.object,
            closeCurrent: React.PropTypes.func,
            setEditState: React.PropTypes.func,
            featuresEditable:React.PropTypes.bool
        },

        render: function(){
            var features = [];
            var metas = Object.keys(this.props.currentMetas);
            metas.sort(function(k1, k2){
                var type1 = k1.split('.').shift();
                var type2 = k2.split('.').shift();
                if(type1 == 'metastore' || type2 == 'index') return -1;
                if(type1 == 'index' || type2 == 'metastore') return 1;
                return (k1 > k2 ? 1:-1);
            });
            if(metas){
                features = metas.map(function(k){
                    var removeButton, description;
                    if(this.props.edit == k && this.props.featuresEditable){
                        var remove = function(event){
                            event.stopPropagation();
                            this.props.metaSourceProvider.removeMetaSource(k);
                        }.bind(this);
                        removeButton = (
                            <div style={{textAlign:'right'}}>
                                <ReactMUI.FlatButton label={this.context.getMessage('ws.31')} primary={true} onClick={remove}/>
                            </div>
                        );
                    }
                    description = <div className="legend">{this.props.metaSourceProvider.getMetaSourceDescription(k)}</div>;
                    return (
                        <ReactPydio.PaperEditorNavEntry key={k} keyName={k} selectedKey={this.props.edit} onClick={this.props.setEditState}>
                            {this.props.metaSourceProvider.getMetaSourceLabel(k)}
                            {description}
                            {removeButton}
                        </ReactPydio.PaperEditorNavEntry>
                    );
                }.bind(this));
            }
            if(this.props.featuresEditable){
                features.push(
                    <div className="menu-entry" key="add-feature" onClick={this.props.metaSourceProvider.showMetaSourceForm}>+ {this.context.getMessage('ws.32')}</div>
                );
            }

            return (
                <div>{features}</div>
            );
        }

    });

    var FeaturesList = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            onSelectionChange:React.PropTypes.func.isRequired,
            metaSourceProvider:React.PropTypes.object.isRequired,
            driverLabel:React.PropTypes.string,
            driverDescription:React.PropTypes.string,
            currentSelection:React.PropTypes.string,
            model:React.PropTypes.instanceOf(WorkspaceModel),
            tplFieldsComponent:React.PropTypes.object
        },

        setEditState:function(key){
            this.props.onSelectionChange(key);
        },

        closeCurrent:function(event){
            event.stopPropagation();
            this.setEditState('activity');
        },

        render: function(){

            var firstSections = [], folders;
            if(this.props.model.isTemplate()){
                firstSections.push(<ReactPydio.PaperEditorNavEntry keyName='tpl_children' key='tpl_children' selectedKey={this.props.currentSelection} label={this.context.getMessage('ws.24')} onClick={this.setEditState}/>);
            }else{
                firstSections.push(<ReactPydio.PaperEditorNavEntry keyName='activity' key='activity' selectedKey={this.props.currentSelection} label={this.context.getMessage('menu.1')} onClick={this.setEditState}/>);
                firstSections.push(<ReactPydio.PaperEditorNavEntry keyName='shares' key='shares' selectedKey={this.props.currentSelection} label={this.context.getMessage('ws.25')} onClick={this.setEditState}/>);
                folders = <ReactPydio.PaperEditorNavEntry keyName='folders' key='folders' selectedKey={this.props.currentSelection} onClick={this.setEditState}>{this.context.getMessage('ws.26')}</ReactPydio.PaperEditorNavEntry>;
            }
            var driverTabLabel = this.context.getMessage('ws.9') + ": " + this.props.driverLabel;
            var additionalFeatures;
            if(this.props.model.isTemplateChild()){
                driverTabLabel = this.context.getMessage('ws.13');
            }else{
                var plusButton;
                if(this.props.model.isEditable()){
                    plusButton = <span className="metasource-add" onClick={this.props.metaSourceProvider.showMetaSourceForm} >+</span>;
                }
                additionalFeatures = (
                    <div key="additional-k">
                        <ReactPydio.PaperEditorNavHeader label={this.context.getMessage('ws.27')}>
                        {plusButton}
                        </ReactPydio.PaperEditorNavHeader>
                        <MetaList
                            metaSourceProvider={this.props.metaSourceProvider}
                            currentMetas={this.props.model.getOption('META_SOURCES')}
                            edit={this.props.currentSelection}
                            closeCurrent={this.closeCurrent}
                            setEditState={this.setEditState}
                            featuresEditable={this.props.model.isEditable()}
                            />
                    </div>
                );
            }

            return (
                <div>
                    <ReactPydio.PaperEditorNavHeader key="summary-k" label={this.context.getMessage('ws.28')}/>
                    {firstSections}
                    <ReactPydio.PaperEditorNavHeader key="parameters-k" label={this.context.getMessage('ws.29')}/>
                    <ReactPydio.PaperEditorNavEntry keyName='general' key='general' selectedKey={this.props.currentSelection} label={this.context.getMessage('ws.30')} onClick={this.setEditState}/>
                    <ReactPydio.PaperEditorNavEntry keyName='driver' key='driver' selectedKey={this.props.currentSelection} onClick={this.setEditState}>{driverTabLabel}</ReactPydio.PaperEditorNavEntry>
                    {this.props.tplFieldsComponent}
                    {folders}
                    {additionalFeatures}
                </div>
            );
        }

    });

    var WorkspaceEditor = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            node:React.PropTypes.instanceOf(AjxpNode).isRequired,
            closeEditor:React.PropTypes.func.isRequired,
            metaSourceProvider:React.PropTypes.object,
            initialEditSection:React.PropTypes.string,
            saveWorkspace:React.PropTypes.func,
            deleteWorkspace:React.PropTypes.func,
            registerCloseCallback:React.PropTypes.func
        },

        getWsId:function(){
            return PathUtils.getBasename(this.props.node.getPath());
        },

        getMetaSourceLabel:function(metaKey){
            return this.state.model.getMetaSourceLabel(metaKey);
        },

        getMetaSourceDescription:function(metaKey){
            return this.state.model.getMetaSourceDescription(metaKey);
        },

        clearMetaSourceDiff:function(){
            this.setState({saveMetaSourceData:{"delete":{},"add":{},"edit":{}}});
        },

        getInitialState:function(){
            // Init from Props
            return {
                dirty:false,
                model:new WorkspaceModel(this.getWsId(), this.props.node.getAjxpMime() == "repository_editable"),
                edit:this.props.initialEditSection || 'activity',
                saveData:{},
                saveMetaSourceData:{"delete":{},"add":{},"edit":{}}
            };
        },

        componentDidMount: function(){
            if(!this.state.model.loaded) this.loadModel();
        },

        componentDidUpdate: function(){
            if(!this.state.model.loaded) this.loadModel();
        },

        componentWillReceiveProps:function(newProps){
            if(this.props.node.getPath() != newProps.node.getPath()){
                var initState = this.getInitialState();
                initState.model = new WorkspaceModel(PathUtils.getBasename(newProps.node.getPath()), newProps.node.getAjxpMime() == "repository_editable");
                this.setState(initState);
            }
        },

        showMetaSourceForm:function(){
            if(this.props.openModal){
                this.props.openModal('AdminWorkspaces', 'MetaSourceForm', {
                    model:this.state.model,
                    editor:this
                });
            }
        },

        addMetaSource:function(metaKey){
            this.state.model.addMetaSource(metaKey);
            var newMetas = this.state.model.getOption("META_SOURCES", true);
            var saveData = this.state.saveData || {};
            saveData[metaKey] = newMetas[metaKey];
            var saveMS = this.state.saveMetaSourceData;
            saveMS['add'][metaKey] = newMetas[metaKey];
            this.setState({
                saveData:saveData,
                saveMetaSourceData:saveMS,
                edit:metaKey,
                dirty:true
            });
        },

        removeMetaSource:function(metaKey){

            this.state.model.removeMetaSource(metaKey);
            // Do something with this?
            var saveData = this.state.saveData || {};
            if(saveData[metaKey]) delete saveData[metaKey];
            var saveMS = this.state.saveMetaSourceData;
            saveMS['delete'][metaKey] = metaKey;
            if(saveMS['add'][metaKey]) delete saveMS['add'][metaKey];
            if(saveMS['edit'][metaKey]) delete saveMS['edit'][metaKey];
            var currentValid = this.state.valid || {};
            if(currentValid[metaKey]) delete currentValid[metaKey];
            this.setState({
                saveData:saveData,
                saveMetaSourceData:saveMS,
                dirty:true,
                edit:'activity',
                valid:currentValid
            });

        },

        isDirty:function(){
            return this.state.dirty;
        },

        loadModel:function(){
            this.state.model.load(function(model){
                if(model.isTemplate() && this.state.edit == 'activity'){
                    this.setState({edit:'tpl_children'});
                }
                this.setState({
                    model:model
                });
                if(this.props.registerCloseCallback){
                    this.props.registerCloseCallback(function(){
                        if(this.isDirty() && !global.confirm(global.pydio.MessageHash["ajxp_role_editor.19"])){
                            return false;
                        }
                    }.bind(this));
                }
            }.bind(this));
        },


        editMeta:function(metaKey){
            this.setState({edit:metaKey});
        },

        onFormChange:function(values){
            var saveData = this.state.saveData || {};
            var saveMS = this.state.saveMetaSourceData;
            var metaKey = this.state.edit;
            if(this.refs.form){
                if(metaKey == 'driver' || metaKey == 'general'){
                    saveData[metaKey + '_POST'] = this.refs.form.getValuesForPOST(values);
                }else{
                    saveMS['edit'][metaKey] = values;
                    if(saveMS['delete'][metaKey]) delete saveMS['delete'][metaKey];
                }
            }
            saveData[metaKey] = values;
            this.setState({
                dirty:true,
                saveData:saveData
            });
        },

        updateValidStatus: function(newStatus){
            var validRecord = this.state.valid || {};
            validRecord[this.state.edit] = newStatus;
            this.setState({valid:validRecord});
        },

        onMaskChange: function(maskValues){
            var saveData = this.state.saveData || {};
            saveData['permission-mask'] = maskValues;
            this.setState({saveData:saveData, dirty:true});
        },

        saveWorkspace:function(){
            var dPost = this.state.saveData['driver_POST'] || {};
            var gPost = this.state.saveData['general_POST'] || {};
            this.props.saveWorkspace(
                this.state.model,
                LangUtils.mergeObjectsRecursive(gPost, dPost),
                LangUtils.mergeObjectsRecursive(this.state.saveData, {META_SOURCES:this.state.saveMetaSourceData})
            );
            this.setState({dirty:false, valid:{}});
        },

        deleteWorkspace:function(){
            this.props.deleteWorkspace(this.getWsId());
        },

        reset:function(){
            this.state.model.resetFromXml();
            this.setState({
                dirty:false,
                saveData:null,
                edit:'activity',
                valid:{}
            });
        },

        toggleTemplateField: function(name, value, oldSelectedFields){
            var values = this.state.saveData ? ( this.state.saveData[this.state.edit] ? this.state.saveData[this.state.edit] : null ) : null;
            if(!values){
                values = this.refs.form.getValues();
            }
            var selectedFields = {};
            oldSelectedFields.map(function(f){selectedFields[f] = ''});
            values = LangUtils.mergeObjectsRecursive(selectedFields, values);
            if(value){
                this.state.model.options.set(name, '');
                values[name] = '';
            }else if(this.state.model.options.has(name)){
                this.state.model.options.delete(name);
                if(values[name] !== undefined){
                    delete values[name];
                }
            }
            this.onFormChange(values);
            this.setState({
                model:this.state.model
            });
        },

        render:function(){

            var editor, rightFill, tplFieldsComponent, h1, readonlyPanel;
            var workspaceLabel = this.context.getMessage('home.6'), driverLabel, driverDescription, featuresList = <div className="workspace-editor-left"></div>;
            if(this.state.model.loaded) {

                if(this.state.edit && this.state.model.loaded && this.state.edit != 'shares' && this.state.edit != 'activity' && this.state.edit != 'folders' && this.state.edit != 'tpl_children'){

                    var formDefs=[], formValues={}, templateAllFormDefs = [];
                    editor = this.state.model.buildEditor(this.state.edit, formDefs, formValues, this.state.saveData, templateAllFormDefs);
                    if(!formDefs.length){
                        editor = (
                            <div>{this.context.getMessage('19', 'ajxp_repository_editor')}</div>
                        );
                    }else{
                        editor = (
                            <PydioForm.FormPanel
                                ref="form"
                                parameters={formDefs}
                                values={formValues}
                                className="full-width"
                                onChange={this.onFormChange}
                                onValidStatusChange={this.updateValidStatus}
                                depth={-2}
                                disabled={!this.state.model.isEditable()}
                            />
                        );

                        if(!this.state.model.isEditable()){
                            readonlyPanel = <div className="workspace-readonly-label">{this.context.getMessage('ws.48')}</div>;
                        }

                        if(this.state.edit == 'driver' && this.state.model.isTemplate()){
                            var selectedFields = formDefs.map(function(p){return p.name});
                            tplFieldsComponent = <TplFieldsChooser
                                driverName={this.state.model.getDriverLabel()}
                                driverFields={templateAllFormDefs}
                                selectedFields={selectedFields}
                                onToggleField={this.toggleTemplateField}
                            />;
                        }else if(this.state.edit == 'general'){
                            if(this.state.model.isTemplate()) {
                                h1 = <h1 className="workspace-general-h1">{this.context.getMessage('ws.21')}</h1>;
                            } else {
                                h1 = <h1 className="workspace-general-h1">{this.context.getMessage('ws.22')}</h1>;
                            }
                        }

                    }
                }else if(this.state.edit == 'shares'){
                    // Display Shares
                    rightFill = true;
                    editor = <SharesList model={this.state.model}/>;
                }else if(this.state.edit == 'folders'){
                    // Display Shares
                    var globalPermissionsObject, globalPermissions;
                    if(this.state.saveData["general"] && this.state.saveData["general"]["DEFAULT_RIGHTS"]){
                        globalPermissions = this.state.saveData["general"]["DEFAULT_RIGHTS"];
                    }else{
                        globalPermissions = this.state.model.getOption('DEFAULT_RIGHTS');
                    }
                    if(globalPermissions && globalPermissions !== -1){
                        globalPermissionsObject = {};
                        globalPermissionsObject["read"] = (globalPermissions.indexOf('r') !== -1);
                        globalPermissionsObject["write"] = (globalPermissions.indexOf('w') !== -1);
                    }

                    rightFill = true;
                    editor = <FoldersList
                        model={this.state.model}
                        onMaskChange={this.onMaskChange}
                        currentMask={this.state.saveData?this.state.saveData["permission-mask"]:{}}
                        globalPermissions={globalPermissionsObject}
                    />;
                }else if(this.state.edit == 'activity' && this.state.model){
                    // Display Shares
                    rightFill = true;
                    editor = <WorkspaceActivity model={this.state.model}/>;
                }else if(this.state.edit == 'tpl_children'){
                    rightFill = true;
                    editor = <TplChildrenList model={this.state.model} node={this.props.node}/>;
                }



                driverLabel = this.state.model.getDriverLabel();
                driverDescription = this.state.model.getDriverDescription();
                workspaceLabel = this.state.model.getOption('display');

                featuresList =(
                    <FeaturesList
                        onSelectionChange={this.editMeta}
                        currentSelection={this.state.edit}
                        model={this.state.model}
                        driverLabel={driverLabel}
                        driverDescription={driverDescription}
                        metaSourceProvider={this}
                        tplFieldsComponent={tplFieldsComponent}
                    />
                );
            }

            var currentValid = true;
            if(this.state.valid){
                LangUtils.objectValues(this.state.valid).map(function(v){currentValid = currentValid && v;})
            }

            var titleActionBarButtons = [];
            if(this.state.model && this.state.model.isEditable()){
                titleActionBarButtons.push(<ReactMUI.FlatButton key="delete" label={this.context.getMessage('ws.23')} primary={true} onClick={this.deleteWorkspace}/>);
                titleActionBarButtons.push(<div className="separator" key="separator"></div>);
            }
            titleActionBarButtons.push(<ReactMUI.FlatButton key="reset" label={this.context.getMessage('plugins.6')} onClick={this.reset} secondary={true} disabled={!this.state.dirty}/>);
            titleActionBarButtons.push(<ReactMUI.FlatButton key="save" label={this.context.getMessage('53', '')} onClick={this.saveWorkspace} secondary={true} disabled={!this.state.dirty || !currentValid}/>);
            titleActionBarButtons.push(<ReactMUI.FlatButton key="close" label={this.context.getMessage('86', '')} onClick={this.props.closeEditor} secondary={true}/>);

            return (
                <ReactPydio.PaperEditorLayout
                    title={workspaceLabel}
                    titleActionBar={titleActionBarButtons}
                    leftNav={featuresList}
                    className="workspace-editor"
                    contentFill={rightFill}
                    >
                    {readonlyPanel}
                    {h1}
                    {editor}
                </ReactPydio.PaperEditorLayout>
            );
        }

    });

    var FeaturesListWizard = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            onSelectionChange:React.PropTypes.func.isRequired,
            driverLabel:React.PropTypes.string,
            driverDescription:React.PropTypes.string,
            currentSelection:React.PropTypes.string,
            wizardType:React.PropTypes.string,
            driversLoaded:React.PropTypes.bool,
            additionalComponents:React.PropTypes.object,
            disableCreateButton:React.PropTypes.bool
        },

        getInitialState:function(){
            return {
                edit:this.props.wizardType == 'workspace'?'template':'general',
                step:1,
                subStep1:'template'
            };
        },

        componentWillReceiveProps:function(newProps){
            if(newProps.currentSelection){
                this.setState({edit:newProps.currentSelection});
            }
        },

        setEditState:function(key){
            this.props.onSelectionChange(key);
            this.setState({edit:key});
        },

        closeCurrent:function(event){
            event.stopPropagation();
        },

        dropDownChange: function(item){
            if(item.payload.name){
                this.setState({step:3});
            }
            this.setState({edit:'driver', selectedDriver:item.payload.name});
            this.props.onSelectionChange('driver', item.payload.name);
        },

        dropChangeDriverOrTemplate:function(event, item){
            if(item == 'template'){
                this.setState({step:1,subStep1:item});
            }else{
                this.setState({step:2, subStep1:'driver'});
                this.setEditState('general');
            }
        },

        dropDownChangeTpl: function(item){
            if(item.payload != -1){
                var tpl = item.payload == "0" ? "0" : item.payload.name;
                this.setState({
                    edit:'general',
                    selectedTemplate:tpl == "0"? null: tpl,
                    step:2
                });
                this.props.onSelectionChange('general', null, tpl);
            }
        },

        render: function(){

            var step1, step2, step3;

            if(this.props.wizardType == 'workspace'){

                // TEMPLATES SELECTOR
                var driverOrTemplate = (
                    <div>
                        <ReactMUI.RadioButtonGroup name="driv_or_tpl" onChange={this.dropChangeDriverOrTemplate} defaultSelected={this.state.subStep1}>
                            <ReactMUI.RadioButton value="template" label={this.context.getMessage('ws.8')} />
                            <ReactMUI.RadioButton value="driver" label={this.context.getMessage('ws.9')}/>
                        </ReactMUI.RadioButtonGroup>
                    </div>
                );

                var templateSelector = null;
                if(this.state.step == 1 && this.state.subStep1 == "template"){
                    templateSelector = (
                        <ReactPydio.PaperEditorNavEntry
                            label={this.context.getMessage('ws.10')}
                            selectedKey={this.state.edit}
                            keyName="template"
                            onClick={this.setEditState}
                            dropDown={true}
                            dropDownData={this.props.driversLoaded?WorkspaceModel.TEMPLATES:null}
                            dropDownChange={this.dropDownChangeTpl}
                            dropDownDefaultItems={[]}
                            />
                    );
                }

                step1 = (
                    <div>
                        <ReactPydio.PaperEditorNavHeader key="tpl-k" label={"1 - " + this.context.getMessage('ws.11')}/>
                        {driverOrTemplate}
                        {templateSelector}
                    </div>
                );

            }

            // DRIVER SELECTOR STEP
            if(this.state.step > 1 || this.props.wizardType == 'template'){

                if(this.props.wizardType == 'workspace' && this.state.selectedTemplate){

                    // Display remaining template options instead of generic + driver
                    var tplLabel = WorkspaceModel.TEMPLATES.get(this.state.selectedTemplate).label;
                    step2 = (
                        <div>
                            <ReactPydio.PaperEditorNavHeader key="parameters-k" label={"2 - " + this.context.getMessage('ws.12').replace('%s', tplLabel)}/>
                            <ReactPydio.PaperEditorNavEntry keyName='general' key='general' selectedKey={this.state.edit} label={this.context.getMessage('ws.13')} onClick={this.setEditState} />
                        </div>
                    );

                }else{

                    step2 = <div>
                        <ReactPydio.PaperEditorNavHeader key="parameters-k" label={"2 - " + this.context.getMessage('ws.14')}/>
                        <ReactPydio.PaperEditorNavEntry keyName='general' key='general' selectedKey={this.state.edit} label={this.context.getMessage('ws.15')} onClick={this.setEditState} />
                        <ReactPydio.PaperEditorNavHeader key="driver-k" label={"3 - " + this.context.getMessage('ws.16')}/>
                        <ReactPydio.PaperEditorNavEntry
                            label={this.context.getMessage(this.props.driversLoaded?'ws.17':'ws.18')}
                            selectedKey={this.state.edit}
                            keyName="driver"
                            onClick={this.setEditState}
                            dropDown={true}
                            dropDownData={this.props.driversLoaded?WorkspaceModel.DRIVERS:null}
                            dropDownChange={this.dropDownChange}
                            />
                    </div>;

                }


            }


            // SAVE / CANCEL BUTTONS
            if(this.state.step > 2 || (this.state.step > 1 && this.props.wizardType == 'workspace' && this.state.selectedTemplate) ){
                var stepNumber = 4;
                if(this.state.selectedTemplate) stepNumber = 3;
                step3 = <div>
                    <ReactPydio.PaperEditorNavHeader key="save-k" label={stepNumber + " - " + this.context.getMessage('ws.19')}/>
                    <div style={{textAlign:'center'}}>
                        <ReactMUI.RaisedButton primary={false} label={this.context.getMessage('54', '')} onClick={this.props.close} />
                        &nbsp;&nbsp;&nbsp;
                        <ReactMUI.RaisedButton primary={true} label={this.context.getMessage('ws.20')} onClick={this.props.save} disabled={this.props.disableCreateButton}/>
                    </div>
                </div>;

            }else{

                step3 = <div style={{textAlign:'center', marginTop: 50}}>
                        <ReactMUI.RaisedButton primary={false} label={this.context.getMessage('54', '')} onClick={this.props.close} />
                    </div>;

            }

            return (
                <div>
                    {step1}
                    {step2}
                    {this.props.additionalComponents}
                    {step3}
                </div>
            );
        }

    });

    var TplFieldsChooser = React.createClass({

        propTypes:{
            driverName:React.PropTypes.string,
            driverFields:React.PropTypes.array,
            selectedFields:React.PropTypes.array,
            onToggleField:React.PropTypes.func
        },

        toggleField: function(name, e){
            this.props.onToggleField(name, e.currentTarget.checked, this.props.selectedFields);
        },

        render: function(){
            var fields = this.props.driverFields.map(function(f){
                return (
                    <div className="menu-entry-toggleable" key={this.props.driverName + '-' + f.name}>
                        <ReactMUI.Checkbox
                            label={f.label}
                            checked={this.props.selectedFields.indexOf(f.name) !== -1}
                            onCheck={this.toggleField.bind(this, f.name)}
                        />
                    </div>
                );
            }.bind(this));
            return (
                <div>
                    <ReactPydio.PaperEditorNavHeader key="save-k" label="3 - Add / Remove parameters"/>
                    {fields}
                </div>
            );
        }

    });

    var WorkspaceCreator = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            type:React.PropTypes.oneOf(['template', 'workspace']),
            save:React.PropTypes.func,
            closeEditor:React.PropTypes.func,
            className:React.PropTypes.string
        },

        getInitialState: function(){
            return {
                newName: this.context.getMessage(this.props.type=='workspace'?'ws.6':'ws.7'),
                edit:this.props.type == 'workspace'?'template':'general',
                driversLoaded:false,
                values:{template:{}, general:{}, driver:{}},
                templateSelectedFields:[]
            };
        },

        isDirty:function(){
            return false;
        },

        componentDidMount: function(){
            if(!WorkspaceModel.DRIVERS){
                WorkspaceModel.loadAvailableDrivers(function(){
                    this.setState({driversLoaded:true});
                }.bind(this));
            }else{
                this.setState({driversLoaded:true});
            }
        },

        selectionChange: function(editMeta, driver, template){
            if( driver || template == '0' ){
                if(driver && this.state.selectedDriver && this.state.selectedDriver != driver){
                    this.setState({templateSelectedFields:[]});
                }
                this.setState({
                    edit:editMeta,
                    selectedDriver:driver,
                    selectedTemplate: null
                });
            }else if (template){
                this.setState({
                    edit:editMeta,
                    selectedDriver: null,
                    selectedTemplate: template
                });
            }else{
                this.setState({
                    edit:editMeta
                });
            }
        },

        onFormChange: function(newValues){
            if(newValues['DISPLAY']) this.setState({newName:newValues['DISPLAY']});
            else if(newValues['DISPLAY']) this.setState({newName:newValues['DISPLAY']});
            var allValues = this.state.values;
            allValues[this.state.edit] = newValues;
            this.setState({values:allValues});
        },

        save:function(){
            this.props.save(this.props.type, this.state);
        },

        toggleTemplateSelectedField:function(name, value){
            var selected = this.state.templateSelectedFields;
            if(value && selected.indexOf(name) == -1){
                selected.push(name);
            }else if(!value && selected.indexOf(name) !== -1){
                selected = LangUtils.arrayWithout(selected, selected.indexOf(name));
            }
            this.setState({templateSelectedFields: selected});
        },

        updateValidStatus: function(newStatus){
            var validRecord = this.state.valid || {};
            validRecord[this.state.edit] = newStatus;
            this.setState({valid:validRecord});
        },

        render: function(){

            var editor, rightFill = false, additionalFeatureComponents;
            if(this.state.edit && this.state.driversLoaded){
                var formDefs=[], formValues=this.state.values[this.state.edit];
                var params;
                if(this.state.edit == 'general'){
                    if(this.state.selectedTemplate) {
                        var tplDef = WorkspaceModel.TEMPLATES.get(this.state.selectedTemplate);
                        var tplOptions = tplDef.options;
                        var driverDefs = WorkspaceModel.DRIVERS.get(tplDef.type).params;
                        params = [];
                        driverDefs.map(function(p){
                            if(tplOptions.indexOf(p.name) === -1){
                                params.push(p);
                            }
                        });
                    }else{
                        params = WorkspaceModel.DRIVERS.get('fs').params;
                    }
                }else if (this.state.selectedDriver){
                    params = WorkspaceModel.DRIVERS.get(this.state.selectedDriver).params;
                    if(this.props.type == 'template'){
                        // Filter parameters and build the left-column parameter list.
                        var filteredParams = [], selectedParams = [];
                        WorkspaceModel.buildEditorStatic(params, filteredParams, {}, 'driver', true);
                        additionalFeatureComponents = <TplFieldsChooser
                            driverName={this.state.selectedDriver}
                            driverFields={filteredParams}
                            selectedFields={this.state.templateSelectedFields}
                            onToggleField={this.toggleTemplateSelectedField}
                        />;
                        var selected = this.state.templateSelectedFields;
                        filteredParams.map(function(p){
                            if(p['group'] != 'Template Options' && selected.indexOf(p.name) !== -1) selectedParams.push(p);
                        });
                        params = selectedParams;
                    }

                }
                if(params){
                    editor = WorkspaceModel.buildEditorStatic(params, formDefs, formValues, (this.state.selectedTemplate && this.state.edit == 'general'?'mixed':this.state.edit), this.props.type=='template');
                    if(!formDefs.length){
                        editor = (
                            <div>{global.pydio.MessageHash['ajxp_repository_editor.19']}</div>
                        );
                    }else{
                        editor = (
                            <PydioForm.FormPanel
                                parameters={formDefs}
                                values={formValues}
                                className="full-width"
                                onChange={this.onFormChange}
                                onValidStatusChange={this.updateValidStatus}
                                depth={-2}
                            />
                        );
                    }
                }
            }

            var currentValid = true;
            if(this.state.valid){
                LangUtils.objectValues(this.state.valid).map(function(v){currentValid = currentValid && v;})
            }

            var leftNav = (
                <FeaturesListWizard
                    onSelectionChange={this.selectionChange}
                    driversLoaded={this.state.driversLoaded}
                    save={this.save}
                    close={this.props.closeEditor}
                    wizardType={this.props.type}
                    additionalComponents={additionalFeatureComponents}
                    disableCreateButton={!currentValid}
                    />
            );

            return (
                <ReactPydio.PaperEditorLayout
                    title={this.state.newName}
                    leftNav={leftNav}
                    contentFill={rightFill}
                >
                    {editor}
                </ReactPydio.PaperEditorLayout>
            );


        }

    });

    var WorkspaceList = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            dataModel:React.PropTypes.instanceOf(PydioDataModel).isRequired,
            rootNode:React.PropTypes.instanceOf(AjxpNode).isRequired,
            currentNode:React.PropTypes.instanceOf(AjxpNode).isRequired,
            openSelection:React.PropTypes.func,
            filter:React.PropTypes.string
        },

        reload:function(){
            this.refs.list.reload();
        },

        renderListIcon:function(node){
            var letters = node.getLabel().split(" ").map(function(word){return word.substr(0,1)}).join("");
            return <span className="letter_badge">{letters}</span>;
        },

        renderSecondLine: function(node){
            if(!node.getMetadata().get("template_name")){
                return this.context.getMessage('ws.5') + ": " + node.getMetadata().get("slug") + " / " + node.getMetadata().get("accessLabel");
            }else{
                return this.context.getMessage('ws.5') + ": " + node.getMetadata().get("slug") + " / Template " + node.getMetadata().get("template_name");
            }
        },

        filterNodes:function(node){
            if(! this.props.filter ) return true;
            if(['ajxp_conf','ajxp_home','admin','ajxp_user'].indexOf(node.getMetadata().get('accessType')) !== -1){
                return false;
            }
            if( this.props.filter == 'workspaces'){
                return !(node.getMetadata().get('is_template') == 'true');
            }else if(this.props.filter == 'templates'){
                return node.getMetadata().get('is_template') == 'true';
            }
            return true;
        },

        render:function(){
            return (
                <ReactPydio.SimpleList
                    ref="list"
                    node={this.props.currentNode}
                    dataModel={this.props.dataModel}
                    className="workspaces-list"
                    actionBarGroups={[]}
                    entryRenderIcon={this.renderListIcon}
                    entryRenderSecondLine={this.renderSecondLine}
                    openEditor={this.props.openSelection}
                    infineSliceCount={1000}
                    filterNodes={this.filterNodes}
                    elementHeight={ReactPydio.SimpleList.HEIGHT_TWO_LINES}
                />
            );
        }

    });

    var Dashboard = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            dataModel:React.PropTypes.instanceOf(PydioDataModel).isRequired,
            rootNode:React.PropTypes.instanceOf(AjxpNode).isRequired,
            currentNode:React.PropTypes.instanceOf(AjxpNode).isRequired,
            openEditor:React.PropTypes.func.isRequired,
            openRightPane:React.PropTypes.func.isRequired,
            closeRightPane:React.PropTypes.func.isRequired
        },

        getInitialState:function(){
            return {selectedNode:null, filter:'workspaces'}
        },

        openWorkspace:function(node, initialSection = 'activity'){
            if(this.refs.editor && this.refs.editor.isDirty()){
                if(!window.confirm(global.pydio.MessageHash["ajxp_role_editor.19"])) {
                    return false;
                }
            }
            //this.setState({selectedNode:node});

            var editorData = {
                COMPONENT:WorkspaceEditor,
                PROPS:{
                    ref:"editor",
                    node:node,
                    initialEditSection:initialSection,
                    openModal:this.props.openModal,
                    dismissModal:this.props.dismissModal,
                    closeEditor:this.closeWorkspace,
                    deleteWorkspace:this.deleteWorkspace,
                    saveWorkspace:this.updateWorkspace
                }
            };
            this.props.openRightPane(editorData);

        },

        closeWorkspace:function(){
            if(this.refs.editor && this.refs.editor.isDirty()){
                if(!window.confirm(global.pydio.MessageHash["ajxp_role_editor.19"])) {
                    return false;
                }
            }
            //this.setState({selectedNode:null, showCreator:null});
            this.props.closeRightPane();
        },

        toggleWorkspacesFilter:function(){
            this.setState({filter:this.state.filter=='workspaces'?'templates':'workspaces'});
        },

        showWorkspaceCreator: function(type){
            if(typeof(type) != "string") type = "workspace";
            var editorData = {
                COMPONENT:WorkspaceCreator,
                PROPS:{
                    ref:"editor",
                    type:type,
                    save:this.createWorkspace,
                    closeEditor:this.closeWorkspace
                }
            };
            this.props.openRightPane(editorData);

        },

        showTplCreator: function(){
            this.showWorkspaceCreator('template');
        },

        createWorkspace: function(type, creatorState){
            var driver;
            if(!creatorState.selectedDriver && creatorState.selectedTemplate){
                driver = "ajxp_template_" + creatorState.selectedTemplate;
                // Move drivers options inside the values['driver'] instead of values['general']
                var tplDef = WorkspaceModel.TEMPLATES.get(creatorState.selectedTemplate);
                var driverDefs = WorkspaceModel.DRIVERS.get(tplDef.type).params;
                var newDriversValues = {};
                Object.keys(creatorState.values['general']).map(function(k){
                    driverDefs.map(function(param){
                        if(param['name'] === k){
                            newDriversValues[k] = creatorState.values['general'][k];
                            delete creatorState.values['general'][k];
                        }
                    });
                });
                creatorState.values['driver'] = newDriversValues;

            }else{
                driver = creatorState.selectedDriver;
            }
            if(creatorState.values['general']['DISPLAY']){
                var displayValues = {DISPLAY:creatorState.values['general']['DISPLAY']};
                delete creatorState.values['general']['DISPLAY'];
            }
            var generalValues = creatorState.values['general'];

            var saveData = LangUtils.objectMerge({
                DRIVER:driver,
                DRIVER_OPTIONS:LangUtils.objectMerge(creatorState.values['general'], creatorState.values['driver'])
            }, displayValues);

            var parameters = {
                get_action:'create_repository',
                json_data:JSON.stringify(saveData)
            };
            if(type == 'template'){
                parameters['sf_checkboxes_active'] = 'true';
            }
            PydioApi.getClient().request(parameters, function(transport){
                // Reload list & Open Editor
                this.refs.workspacesList.reload();
                var newId = XMLUtils.XPathGetSingleNodeText(transport.responseXML, "tree/reload_instruction/@file");
                var fakeNode = new AjxpNode('/fake/path/' + newId);
                fakeNode.getMetadata().set("ajxp_mime", "repository_editable");
                this.openWorkspace(fakeNode, 'driver');
            }.bind(this));
        },

        deleteWorkspace:function(workspaceId){
            if(window.confirm(this.context.getMessage('35', 'ajxp_conf'))){
                this.closeWorkspace();
                PydioApi.getClient().request({
                    get_action:'delete',
                    data_type:'repository',
                    data_id:workspaceId
                }, function(transport){
                    this.refs.workspacesList.reload();
                }.bind(this));
            }
        },

        /**
         *
         * @param workspaceModel WorkspaceModel
         * @param postData Object
         * @param editorData Object
         */
        updateWorkspace:function(workspaceModel, postData, editorData){
            var workspaceId = workspaceModel.wsId;
            if(workspaceModel.isTemplate()){
                var formDefs=[], formValues={}, templateAllFormDefs = [];
                if(!editorData["general"]){
                    workspaceModel.buildEditor("general", formDefs, formValues, {}, templateAllFormDefs);
                    var generalPostValues = PydioForm.Manager.getValuesForPOST(formDefs, formValues);
                    postData = LangUtils.objectMerge(postData, generalPostValues);
                }
                if(!editorData["driver"]){
                    workspaceModel.buildEditor("driver", formDefs, formValues, {}, templateAllFormDefs);
                    var driverPostValues = PydioForm.Manager.getValuesForPOST(formDefs, formValues);
                    postData = LangUtils.objectMerge(postData, driverPostValues);
                }
            }

            if(editorData['permission-mask']){
                postData['permission_mask'] = JSON.stringify(editorData['permission-mask']);
            }
            var mainSave = function(){
                PydioApi.getClient().request(LangUtils.objectMerge({
                    get_action:'edit',
                    sub_action:'edit_repository_data',
                    repository_id:workspaceId
                }, postData), function(transport){
                    this.refs['workspacesList'].reload();
                }.bind(this));
            }.bind(this);

            var metaSources = editorData['META_SOURCES'];
            if(Object.keys(metaSources["delete"]).length || Object.keys(metaSources["add"]).length || Object.keys(metaSources["edit"]).length){
                PydioApi.getClient().request(LangUtils.objectMerge({
                    get_action:'edit',
                    sub_action:'meta_source_edit',
                    repository_id:workspaceId,
                    bulk_data:JSON.stringify(metaSources)
                }), function(transport){
                    this.refs['editor'].clearMetaSourceDiff();
                    mainSave();
                }.bind(this));
            }else{
                mainSave();
            }
        },

        reloadWorkspaceList:function(){
            this.refs.workspacesList.reload();
        },

        render:function(){
            var buttonContainer;
            if(this.state.filter == 'workspaces'){
                buttonContainer = (
                    <div className="button-container">
                        <ReactMUI.FlatButton primary={true} label={this.context.getMessage('ws.3')} onClick={this.showWorkspaceCreator}/>
                        <ReactMUI.FlatButton onClick={this.toggleWorkspacesFilter} secondary={true} label={this.context.getMessage('ws.1')}/>
                    </div>
                );
            }else{
                buttonContainer = (
                    <div className="button-container">
                        <ReactMUI.FlatButton primary={true} label={this.context.getMessage('ws.4')} onClick={this.showTplCreator}/>
                        <ReactMUI.FlatButton onClick={this.toggleWorkspacesFilter} secondary={true} label={this.context.getMessage('ws.2')}/>
                    </div>
                );
            }
            buttonContainer = (
                <div style={{marginRight:20}}>
                    <div style={{float:'left'}}>{buttonContainer}</div>
                    <div style={{float:'right'}}>
                        <ReactMUI.IconButton className="small-icon-button" iconClassName="icon-refresh" onClick={this.reloadWorkspaceList}/>
                    </div>
                </div>
            );
            return (
                <div className="main-layout-nav-to-stack workspaces-board">
                    <div className="left-nav vertical-layout" style={{width:'100%'}}>
                        <ReactMUI.Paper zDepth={0} className="vertical-layout layout-fill">
                            <div className="vertical-layout workspaces-list layout-fill">
                                <h1 className="hide-on-vertical-layout">{this.context.getMessage('3', 'ajxp_conf')}</h1>
                                {buttonContainer}
                                <WorkspaceList
                                    ref="workspacesList"
                                    dataModel={this.props.dataModel}
                                    rootNode={this.props.rootNode}
                                    currentNode={this.props.rootNode}
                                    openSelection={this.openWorkspace}
                                    filter={this.state.filter}
                                />
                            </div>
                        </ReactMUI.Paper>
                    </div>
                </div>
            );
        }

    });

    global.AdminWorkspaces = {};
    global.AdminWorkspaces.Dashboard = Dashboard;
    global.AdminWorkspaces.MetaSourceForm = MetaSourceForm;

})(window);