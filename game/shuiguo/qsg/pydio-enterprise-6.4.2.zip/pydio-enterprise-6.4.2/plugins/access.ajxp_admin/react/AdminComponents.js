(function(global){

    class MenuItemListener extends Observable{

        static getInstance(){
            if(!MenuItemListener.INSTANCE){
                MenuItemListener.INSTANCE = new MenuItemListener();
            }
            return MenuItemListener.INSTANCE;
        }

    }

    class NavigationHelper{

        static buildNavigationItems(rootNode, contextNode, items){

            items.push({
                text:global.pydio.MessageHash['ajxp_admin.menu.0'],
                payload:rootNode,
                iconClassName:"icon-dashboard"
            });
            var index = 0;
            var selectedIndex = 0;
            if(contextNode == rootNode) selectedIndex = 0;
            rootNode.getChildren().forEach(function(header){
                if(!header.getChildren().size && header.getMetadata().get('component')) {
                    items.push({
                        text: header.getLabel(),
                        payload: header,
                        iconClassName: header.getMetadata().get('icon_class')
                    });
                    index++;
                    if (contextNode == header) {
                        selectedIndex = index;
                    }
                }else{
                    if(header.getLabel()){
                        items.push({
                            type: ReactMUI.MenuItem.Types.SUBHEADER,
                            text:header.getLabel()
                        });
                        index++;
                    }
                    header.getChildren().forEach(function(child){
                        if(!child.getLabel()) return;
                        var label = child.getLabel();
                        if(child.getMetadata().get('flag')){
                            label = <span>{child.getLabel()} <span className="menu-flag">{child.getMetadata().get('flag')}</span> </span>;
                        }
                        items.push({
                            text:label,
                            payload:child,
                            iconClassName:child.getMetadata().get('icon_class')
                        });
                        index++;
                        if(contextNode == child){
                            selectedIndex = index;
                        }
                    });
                }
            });
            return selectedIndex;

        }

    }

    class DNDActionsManager{

        /**
         * Check if a source can be dropped on a target.
         * Throws an exception if not allowed
         *
         * @param source AjxpNode
         * @param target AjxpNode
         */
        static canDropNodeOnNode(source, target){
            var sourceMime = source.getAjxpMime();
            var targetMime = target.getAjxpMime();
            if(sourceMime == "role" && source.getMetadata().get("role_id") == "AJXP_GRP_/"){
                throw new Error('Cannot drop this!');
            }
            var result;
            if(sourceMime == "role" && targetMime == "user_editable") {
                result = true;
            }
            if(sourceMime == "user_editable" && (targetMime == "group" || targetMime == "users_zone")){
                result = true;
            }
            if(!result){
                throw new Error('Cannot drop this!');
            }
        }

        /**
         * Apply a successful drop of Source on Target
         * @param source AjxpNode
         * @param target AjxpNode
         */
        static dropNodeOnNode(source, target){
            //global.alert('Dropped ' + source.getPath() + ' on ' + target.getPath());
            var sourceMime = source.getAjxpMime();
            var targetMime = target.getAjxpMime();
            if(sourceMime == "user_editable" && ( targetMime == "group" || targetMime == "users_zone" )){
                if(PathUtils.getDirname(source.getPath()) == target.getPath()){
                    global.alert('Please drop user in a different group!');
                    return;
                }
                // update_user_group

                PydioApi.getClient().request({
                    get_action:'user_update_group',
                    file:source.getPath().substr("/data/users".length),
                    group_path: (targetMime == "users_zone" ? "/" : target.getPath().substr("/data/users".length))
                }, function(){
                    if(source.getParent()){
                        source.getParent().reload();
                    }
                    target.reload();
                });
            }else if(sourceMime == "role" && targetMime == "user_editable"){
                PydioApi.getClient().request({
                    get_action:'edit',
                    sub_action:'user_add_role',
                    user_id:PathUtils.getBasename(target.getPath()),
                    role_id:PathUtils.getBasename(source.getPath())
                }, function(){
                    if (target.getParent()) {
                        target.getParent().reload();
                    }
                });
            }
        }

    }

    /*******************************/
    /* GLOBAL CONTEXT PROPAGATORS
    /******************************/
    var MessagesConsumerMixin = {
        contextTypes: {
            messages:React.PropTypes.object,
            getMessage:React.PropTypes.func
        }
    };

    var MessagesProviderMixin = {

        childContextTypes: {
            messages:React.PropTypes.object,
            getMessage:React.PropTypes.func
        },

        getChildContext: function() {
            var messages = this.props.pydio.MessageHash;
            return {
                messages: messages,
                getMessage: function(messageId, namespace='ajxp_admin'){
                    try{
                        return messages[namespace + (namespace?".":"") + messageId] || messageId;
                    }catch(e){
                        return messageId;
                    }
                }
            };
        }

    };

    var PydioConsumerMixin = {
        contextTypes:{
            pydio:React.PropTypes.instanceOf(Pydio)
        }
    };

    var PydioProviderMixin = {
        childContextTypes:{
            pydio:React.PropTypes.instanceOf(Pydio)
        },

        getChildContext: function(){
            return {
                pydio: this.props.pydio
            };
        }
    };

    var DeleteDialog = React.createClass({

        propTypes:{
            modalData:React.PropTypes.object,
            dismiss:React.PropTypes.func
        },

        getInitialState:function(){

            var node = this.props.modalData.payload.node;
            var meta = node.getMetadata();
            var deleteMessage, fieldName, fieldValue;
            var MessageHash = global.MessageHash;
            if(meta.get("ajxp_mime") == "user_editable"){
                deleteMessage = MessageHash['ajxp_conf.34'];
                fieldName = "user_id";
                fieldValue = PathUtils.getBasename(meta.get("filename"));
            }else if(meta.get("ajxp_mime") == "role"){
                deleteMessage = MessageHash['ajxp_conf.126'];
                fieldName = "role_id";
                fieldValue = PathUtils.getBasename(meta.get("filename"));
            }else if(meta.get("ajxp_mime") == "group"){
                deleteMessage = MessageHash['ajxp_conf.126'];
                fieldName = "group";
                fieldValue = meta.get("filename");
            }else{
                deleteMessage = MessageHash['ajxp_conf.35'];
                fieldName = "repository_id";
                fieldValue = meta.get("repository_id");
            }

            return {
                node:this.props.modalData.payload.node,
                mime:this.props.modalData.payload.node.getMetadata().get('ajxp_mime'),
                deleteMessage:deleteMessage,
                fieldName:fieldName,
                fieldValue:fieldValue
            };
        },

        getTitle:function(){
            return this.state.deleteMessage;
        },

        getDialogClassName:function(){
            return "dialog-max-480";
        },

        getButtons:function(){
            return [
                { text: 'Cancel' },
                { text: 'Delete', onClick: this.submit, ref: 'submit' }
            ];
        },

        submit: function(dialog) {
            var parameters = {
                get_action:'delete'
            };
            parameters[this.state.fieldName] = this.state.fieldValue;
            PydioApi.getClient().request(parameters, function(transport){
                this.props.dismiss();
                if(this.state.node.getParent()) {
                    this.state.node.getParent().reload();
                }
            }.bind(this));
        },

        render: function(){
            return <div></div>;
        }

    });

    var FreeMaskLine = React.createClass({

        propTypes: {
            path:React.PropTypes.string,
            mask: React.PropTypes.object
        },

        onCbChecked:function(type, event, newValue){
            var newMask = LangUtils.deepCopy(this.props.mask);
            var perm = newMask[this.props.path] || {};
            perm[type] = newValue;
            newMask[this.props.path] = perm;
            this.props.onMaskChange(newMask);
        },

        onPathChanged: function(event){
            var newPath = event.target.getValue();
            bufferCallback('path-changed', 750, function(){
                this.propagatePathChange(newPath);
            }.bind(this));
        },

        propagatePathChange: function(newPath){
            var newMask = {};
            Object.keys(this.props.mask).map(function(k){
                if(k == this.props.path) newMask[newPath] = this.props.mask[k];
                else newMask[k] = this.props.mask[k];
            }.bind(this));
            this.props.onMaskChange(newMask);
        },

        onRemove: function(){
            var newMask = LangUtils.deepCopy(this.props.mask);
            if(newMask[this.props.path]){
                delete newMask[this.props.path];
            }
            this.props.onMaskChange(newMask);
        },

        render: function(){
            var perm = this.props.parentMask ? this.props.parentMask[this.props.path] : this.props.mask[this.props.path];
            return (
                <div className={"mui-menu-item tree-item has-checkboxes"} style={{paddingLeft:'4px', width:'100%'}}>
                    <ReactMUI.IconButton iconClassName="icon-minus" onClick={this.onRemove} className="smaller-button"/>
                    <ReactMUI.TextField defaultValue={this.props.path} className="tree-item-label" onChange={this.onPathChanged}/>
                    <div className={"tree-checkboxes" + (this.props.className?' '+this.props.className:'')}>
                        <ReactMUI.Checkbox className="cbox-read" checked={perm['read']} onCheck={this.onCbChecked.bind(this, "read")} />
                        <ReactMUI.Checkbox className="cbox-write" checked={perm['write']}  onCheck={this.onCbChecked.bind(this, "write")} />
                        <ReactMUI.Checkbox className="cbox-deny" checked={perm['deny']}  onCheck={this.onCbChecked.bind(this, "deny")} />
                        <ReactMUI.Checkbox className="cbox-children" checked={perm['children']}  onCheck={this.onCbChecked.bind(this, "children")} />
                    </div>
                </div>
            );

        }

    });

    var PermissionMaskEditorFree = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            workspaceId:React.PropTypes.string,

            /* Global permissions may override the folders rights */
            globalWorkspacePermissions:React.PropTypes.object,
            showGlobalPermissions:React.PropTypes.bool,
            onGlobalPermissionsChange:React.PropTypes.func,

            /* Folders mask and parentMask */
            mask:React.PropTypes.object,
            parentMask:React.PropTypes.object,
            onMaskChange:React.PropTypes.func,

            /* Maybe used to alert about inconsistencies */
            showModal:React.PropTypes.func,
            hideModal:React.PropTypes.func
        },

        onClickAdd: function(){
            var test = '/new-path', testBase = '/new-path', index = 1;
            while(this.props.mask[test]){
                test = testBase + '-' + index;
                index ++;
            }
            this.props.mask[test] = {};
            this.onMaskChange(this.props.mask);
        },

        onMaskChange: function(newMask){
            this.props.onMaskChange(newMask);
        },

        render: function(){

            var parentMask = this.props.parentMask || {};
            var mask = this.props.mask;
            var lines = [];

            var mainClassNames = global.classNames(
                "permission-mask-editor",
                {"permission-mask-global-noread":(this.props.globalWorkspacePermissions && !this.props.globalWorkspacePermissions.read)},
                {"permission-mask-global-nowrite":(this.props.globalWorkspacePermissions && !this.props.globalWorkspacePermissions.write)}
            );

            Object.keys(parentMask).map(function(path){
                if(!mask[path]){
                    lines.push(<FreeMaskLine
                        key={path}
                        path={path}
                        parentMask={parentMask}
                        mask={mask}
                        onMaskChange={this.onMaskChange}
                        className="parent-inherited"
                        />);
                }
            }.bind(this));

            Object.keys(mask).map(function(path){
                lines.push(<FreeMaskLine
                    key={path}
                    path={path}
                    mask={mask}
                    onMaskChange={this.onMaskChange}
                    />);
            }.bind(this));

            return (
                <div className={mainClassNames}>
                    <div className="read-write-header">
                        <span className="header-read">{this.context.getMessage('react.5a','ajxp_admin')}</span>
                        <span className="header-write">{this.context.getMessage('react.5b','ajxp_admin')}</span>
                        <span className="header-deny">{this.context.getMessage('react.5','ajxp_admin')}</span>
                        <span  className="header-children">{this.context.getMessage('react.6','ajxp_admin')}</span>
                    </div>
                    <div>{lines}</div>
                    <div style={{clear:'both', textAlign:'center', padding: '10px'}}>
                        <ReactMUI.FlatButton onClick={this.onClickAdd} className="smaller-button">
                            <ReactMUI.FontIcon className="icon-plus"/> {this.context.getMessage('react.7','ajxp_admin')}
                        </ReactMUI.FlatButton>
                    </div>
                </div>
            );
        }
    });

    var PermissionMaskEditor = React.createClass({

        mixins:[MessagesConsumerMixin],

        propTypes:{
            workspaceId:React.PropTypes.string,

            /* Global permissions may override the folders rights */
            globalWorkspacePermissions:React.PropTypes.object,
            showGlobalPermissions:React.PropTypes.bool,
            onGlobalPermissionsChange:React.PropTypes.func,

            /* Folders mask and parentMask */
            mask:React.PropTypes.object,
            parentMask:React.PropTypes.object,
            onMaskChange:React.PropTypes.func,

            /* Maybe used to alert about inconsistencies */
            showModal:React.PropTypes.func,
            hideModal:React.PropTypes.func
        },

        dmObserver:function(){
            var dataModel = this.state.dataModel;
            var sel = dataModel.getSelectedNodes();
            if(!sel.length) return;
            var selNode = sel[0];
            if(!selNode.isLoaded()) {
                selNode.observeOnce("loaded", function(){
                    this.forceUpdate();
                }.bind(this));
                selNode.load();
            }else{
                this.forceUpdate();
            }
        },

        componentDidMount:function(){
            this.state.dataModel.setSelectedNodes([this.state.node]);
        },

        componentWillReceiveProps:function(newProps){
            if(newProps.mask !== this.state.mask || newProps.parentMask !== this.state.parentMask){
                this.setState({
                    mask: newProps.mask,
                    parentMask : newProps.parentMask || {}
                });
            }
        },

        getInitialState:function(){
            var nodeProviderProperties = {
                get_action:"ls",
                tmp_repository_id:this.props.workspaceId
            };
            var dataModel = new PydioDataModel(true);
            var rNodeProvider = new RemoteNodeProvider();
            dataModel.setAjxpNodeProvider(rNodeProvider);
            rNodeProvider.initProvider(nodeProviderProperties);
            var rootNode = new AjxpNode("/", false, "Whole workspace", "folder.png", rNodeProvider);
            dataModel.setRootNode(rootNode);
            dataModel.observe("selection_changed", this.dmObserver);

            var mask = this.props.mask;
            var parentMask = this.props.parentMask || {};

            return {
                node:rootNode,
                dataModel:dataModel,
                mask:mask,
                parentMask:parentMask,
                showResultingTree:false
            };
        },

        updateRow: function(currentValues, checkboxName, value){
            if(checkboxName == "read" || checkboxName == "write" || checkboxName == "children"){
                if(value) currentValues[checkboxName] = value;
                else if (currentValues[checkboxName]) delete currentValues[checkboxName];

                if(value && (checkboxName == "read" || checkboxName == "write") && currentValues["deny"]){
                    delete currentValues["deny"];
                }
            }else if(checkboxName == "deny"){
                if(value) {
                    currentValues[checkboxName] = value;
                    if(currentValues["read"]) delete currentValues["read"];
                    if(currentValues["write"]) delete currentValues["write"];
                }else{
                    if(currentValues["deny"]) delete currentValues["deny"];
                }
            }
            if(!Object.keys(currentValues).length){
                return "delete";
            }else{
                return "update";
            }
        },

        updateColumn: function(values, node, checkboxName, value, copy){
            // If we change the "children" status, remove children values
            if(checkboxName == "children"){
                if(copy){
                    var currentValues = LangUtils.simpleCopy(values[node.getPath()]) || {};
                    currentValues["children"] = false;
                    node.getChildren().forEach(function(c){
                        if(!c.isLeaf()) values[c.getPath()] = LangUtils.simpleCopy(currentValues);
                    });
                }else{
                    var currentPath = node.getPath();
                    if( currentPath == '/') currentPath = '';
                    var keys = Object.keys(values);
                    keys.map(function(k){
                        if(k.startsWith(currentPath+'/')){
                            delete values[k];
                        }
                    });
                }
            }
        },

        applyConfirm:function(value, event){
            this.refs.dialog.dismiss();
            switch(value){
                case "cancel":
                    break;
                case "confirm-remove":
                case "confirm-set-clear":
                    this.onCheckboxCheck(...Object.values(this.state.confirmPending), true);
                    break;
                case "confirm-set-copy":
                    this.onCheckboxCheck(this.state.confirmPending["node"], "children", "copy", true);
                    break;
            }
            this.setState({confirm: null, confirmPending:null});
        },

        onCheckboxCheck:function(node, checkboxName, value, skipConfirm){
            //console.log(node, checkboxName, value);
            var values = this.state.mask;
            var nodeValues = values[node.getPath()] || {};
            if(checkboxName == "children" && !skipConfirm){
                if(value && !node.isLoaded()){
                    var tree = this.refs.tree;
                    node.observeOnce("loaded", function(){
                        global.setTimeout(function(){
                            tree.forceUpdate();
                        }, 200);
                    });
                    node.load();
                }
                var confirmationText, buttons;
                if(value){
                    confirmationText = this.context.getMessage('react.8','ajxp_admin');
                    buttons = [
                        {text:this.context.getMessage('react.10','ajxp_admin'), onClick:this.applyConfirm.bind(this, 'confirm-set-copy')},
                        {text:this.context.getMessage('react.11','ajxp_admin'), onClick:this.applyConfirm.bind(this, 'confirm-set-clear')},
                        {text:this.context.getMessage('54', ''), onClick:this.applyConfirm.bind(this, 'cancel')}
                    ];
                }else{
                    confirmationText = this.context.getMessage('react.9','ajxp_admin');
                    buttons = [
                        {text:this.context.getMessage('react.12','ajxp_admin'), onClick:this.applyConfirm.bind(this, 'confirm-remove')},
                        {text:this.context.getMessage('54', ''), onTouchTap:this.applyConfirm.bind(this, 'cancel')}];
                }
                this.setState({
                    confirm:{
                        text:confirmationText,
                        buttons:buttons
                    },
                    confirmPending:{
                        node:node,
                        checkboxName:checkboxName,
                        value:value
                    }
                }, function(){this.refs.dialog.show();}.bind(this));
                return;
            }
            var copy;
            if(checkboxName == "children" && value == "copy"){
                copy = value = true;
                this.updateColumn(values, node, checkboxName, value, true);
            }
            var result = this.updateRow(nodeValues, checkboxName, value);
            if(!copy){
                this.updateColumn(values, node, checkboxName, value);
            }

            if(result == "delete" && values[node.getPath()]){
                delete values[node.getPath()];
            }else{
                values[node.getPath()] = nodeValues;
            }
            if(this.props.onMaskChange){
                this.props.onMaskChange(values);
            }
            this.setState({mask:values});
        },

        checkboxesComputeStatus:function(node, useParentMask=false){

            var values = {}, disabled = {};
            var inherited = false, foundParent = false, foundParentChecksChildren = false;
            var mask = this.state.mask;
            if(useParentMask){
                mask = this.state.parentMask;
            }
            var firstParent = node.getParent();
            if(firstParent && firstParent.getPath() != '/' && mask[firstParent.getPath()] && mask[firstParent.getPath()['children']]){
                foundParentChecksChildren = true;
            }
            if(mask[node.getPath()]){
                values = mask[node.getPath()];
            }else{
                var bNode = node, parent;
                // IF direct parent has not values at all, it will always be inherited
                if(firstParent && !mask[firstParent.getPath()]){
                    inherited = true;
                }
                while(parent = bNode.getParent()){
                    if(mask[parent.getPath()]){
                        var parentValues = mask[parent.getPath()];
                        foundParent = true;
                        if(!parentValues['children']){
                            inherited = true;
                            values = LangUtils.deepCopy(parentValues);
                            values['children'] = false;
                        }
                        break;
                    }
                    bNode = parent;
                }
            }
            if(!Object.keys(values).length) {
                if(node.getPath() != '/' && !foundParent){
                    inherited = true;
                }
                // if any children defined, add the children value;
                Object.keys(mask).map(function(path){
                    var testPath = node.getPath() + '/';
                    if(testPath == '//') testPath = '/';
                    if(path.startsWith(testPath)){
                        values['children'] = true;
                        // This is bad, we update the state object directly...
                        mask[node.getPath()] = {children:true};
                    }
                }.bind(this));
            }
            // Update disabled state
            if(inherited) {
                disabled = {read: true, write:true, deny:true, children:true};
            } else{
                if(values['children']) {
                    disabled = {read: true, write:true, deny:true};
                    values['write'] = false;
                    values['deny'] = false;
                    values['read'] = true;
                } else if(values['deny']) {
                    disabled = {read: true, write:true};
                }
            }
            var additionalClass;
            if(!values['read'] && !values['write'] && !values['deny']
                && Object.keys(this.state.parentMask).length
                    && !foundParentChecksChildren
                && !useParentMask){
                // Still no values, compute from parent
                additionalClass = 'parent-inherited';
                var data = this.checkboxesComputeStatus(node, true);
                values = data.VALUES;
                disabled = {read: false, write:false, deny:false, children:false};
                inherited = data.INHERITED;
            }
            return {
                VALUES:values,
                INHERITED:inherited,
                DISABLED:disabled,
                CLASSNAME:additionalClass
            };
        },

        render: function(){
            var mainClassNames = global.classNames(
                "permission-mask-editor",
                {"tree-show-accessible-nodes":(this.state && this.state.showResultingTree)},
                {"permission-mask-global-noread":(this.props.globalWorkspacePermissions && !this.props.globalWorkspacePermissions.read)},
                {"permission-mask-global-nowrite":(this.props.globalWorkspacePermissions && !this.props.globalWorkspacePermissions.write)}
            );
            return (
                <div className={mainClassNames}>
                    <ReactMUI.Dialog
                        ref="dialog"
                        title="Warning"
                        actions={this.state && this.state.confirm ? this.state.confirm.buttons : []}
                        contentClassName="dialog-max-480"
                        >
                        {this.state && this.state.confirm  ? this.state.confirm.text: ''}
                    </ReactMUI.Dialog>
                    <div style={{margin:'0 16px', position:'relative'}}>
                        <div style={{position: 'absolute'}}>
                            <ReactMUI.IconButton
                                iconClassName="icon-filter" className="smaller-button"
                                tooltip={this.context.getMessage(this.state.showResultingTree?'react.13': 'react.14', 'ajxp_admin')}
                                onClick={function(){this.setState({showResultingTree:!this.state.showResultingTree});}.bind(this)}
                                />
                        </div>
                        <div className="read-write-header">
                            <span className="header-read">{this.context.getMessage('react.5a','ajxp_admin')}</span>
                            <span className="header-write">{this.context.getMessage('react.5b','ajxp_admin')}</span>
                            <span className="header-deny">{this.context.getMessage('react.5','ajxp_admin')}</span>
                            <span  className="header-children">{this.context.getMessage('react.6','ajxp_admin')}</span>
                        </div>
                        <br  style={{clear: 'both'}}/>
                        <ReactPydio.SimpleTree
                            ref="tree"
                            dataModel={this.state.dataModel}
                            node={this.state.node}
                            showRoot={true}
                            checkboxes={["read", "write", "deny", "children"]}
                            checkboxesValues={this.state.mask}
                            checkboxesComputeStatus={this.checkboxesComputeStatus}
                            onCheckboxCheck={this.onCheckboxCheck}
                            forceExpand={true}
                            />
                    </div>
                </div>
            );
        }

    });


    var AdminLeftNav = React.createClass({

        propTypes:{
            rootNode:React.PropTypes.instanceOf(AjxpNode),
            contextNode:React.PropTypes.instanceOf(AjxpNode),
            dataModel:React.PropTypes.instanceOf(PydioDataModel)
        },

        componentDidMount: function(){
            this.refs.leftNav.close();
            MenuItemListener.getInstance().observe("item_changed", function(){
                this.forceUpdate();
            }.bind(this));
            global.setTimeout(this.checkForUpdates, 5000);
        },

        componentWillUnmount: function(){
            MenuItemListener.getInstance().stopObserving("item_changed");
        },

        checkForUpdates: function(){
            if(this.props.pydio.Controller.getActionByName("get_upgrade_path")){
                PydioApi.getClient().request({get_action:'get_upgrade_path'}, function(transp){
                    var response = transp.responseJSON;
                    var fakeNode = new AjxpNode("/admin/action.updater");
                    var child = fakeNode.findInArbo(this.props.rootNode);
                    if(child){
                        var length = 0;
                        if(response && response.packages.length) {
                            length = response.packages.length;
                        }
                        child.getMetadata().set('flag', length);
                        MenuItemListener.getInstance().notify("item_changed");
                    }
                }.bind(this));
            }
        },

        openMenu: function(){
            if(this.refs.leftNav.state.open){
                this.cancelCloseBuffer();
            }
            this.refs.leftNav.toggle();
        },
        menuClicked:function(event, index, menuItem){
            if(menuItem.payload){
                this.props.dataModel.setSelectedNodes([]);
                this.props.dataModel.setContextNode(menuItem.payload);
            }
        },
        leftNavMouseOver:function(){
            this.cancelCloseBuffer();
            if(!this.refs.leftNav.state.open){
                this.refs.leftNav.toggle();
            }
        },
        leftNavMouseOut:function(){
            this.bufferClose();
        },

        leftNavScroll:function(){
            this.cancelCloseBuffer();
        },

        cancelCloseBuffer: function(){
            if(this.__closeTimer){
                global.clearTimeout(this.__closeTimer);
            }
        },

        bufferClose:function(time, callback){
            this.cancelCloseBuffer();
            this.__closeTimer = global.setTimeout(function(){
                if(this.isMounted() && this.refs.leftNav) this.refs.leftNav.close();
            }.bind(this), 500);
        },


        render: function(){
            var menuItems = [];
            var selectedIndex = NavigationHelper.buildNavigationItems(this.props.rootNode, this.props.contextNode, menuItems);

            var menuHeader = (
                <div onMouseOver={this.leftNavMouseOver} onMouseOut={this.leftNavMouseOut} onScroll={this.leftNavScroll} className="left-nav-menu-scroller">
                    <ReactMUI.Menu onItemClick={this.menuClicked} zDepth={0} menuItems={menuItems} selectedIndex={selectedIndex}/>
                </div>
            );
            return <ReactMUI.LeftNav className="admin-main-nav" docked={true} isInitiallyOpen={false} menuItems={[]} ref="leftNav" header={menuHeader}/>
        }

    });

    var AdminDashboard = React.createClass({

        mixins:[MessagesProviderMixin, PydioProviderMixin],

        propTypes:{
            pydio: React.PropTypes.instanceOf(Pydio).isRequired
        },

        getInitialState: function(){
            var dm = this.props.pydio.getContextHolder();
            return {
                contextNode:dm.getContextNode(),
                selectedNodes:dm.getSelectedNodes(),
                contextStatus:dm.getContextNode().isLoaded(),
                modalData:null
            };
        },

        dmChangesToState: function(){
            var dm = this.props.pydio.getContextHolder();
            this.setState({
                contextNode:dm.getContextNode(),
                selectedNodes:dm.getSelectedNodes(),
                contextStatus:dm.getContextNode().isLoaded()
            });
            dm.getContextNode().observe("loaded", this.dmChangesToState);
            if(dm.getUniqueNode()){
                dm.getUniqueNode().observe("loaded", this.dmChangesToState);
            }
        },

        openEditor: function(node){
            this.openRightPane({
                COMPONENT:ReactPydio.ReactEditorOpener,
                PROPS:{
                    node:node,
                    registry:this.props.pydio.Registry,
                    closeEditorContainer:this.closeRightPane,
                    registerCloseCallback:this.registerRightPaneCloseCallback
                },
                CHILDREN:null
            });
        },

        openRightPane: function(serializedComponent){
            serializedComponent['PROPS']['registerCloseCallback'] = this.registerRightPaneCloseCallback;
            serializedComponent['PROPS']['closeEditorContainer'] = this.closeRightPane;
            // Do not open on another already opened
            if(this.state && this.state.rightPanel && this.state.rightPanelCloseCallback){
                if(this.state.rightPanelCloseCallback() === false){
                    return;
                }
            }
            this.setState({ rightPanel:serializedComponent });
        },

        registerRightPaneCloseCallback: function(callback){
            this.setState({rightPanelCloseCallback:callback});
        },

        closeRightPane:function(){
            if(this.state.rightPanelCloseCallback && this.state.rightPanelCloseCallback() === false){
                return false;
            }
            this.setState({rightPanel:null, rightPanelCloseCallback:null});
            return true;
        },

        openModal:function(namespaceOrElement, compName, payload={}){
            if(typeof(namespaceOrElement) == "string" && compName){
                this.setState({
                    modalData: {
                        namespace:namespaceOrElement,
                        compName:compName,
                        payload:payload
                    }
                });
            }else{
                this.setState({
                    modalData:namespaceOrElement,
                    payload:payload
                });
            }
            if(this.refs.modal) {
                this.refs.modal.show()
            }
        },

        emptyModal:function(){
            this.setState({modalData: null});
        },

        openLeftNav:function(){
            this.refs.leftNav.openMenu();
        },

        componentDidMount: function(){
            this.props.pydio.UI.disableAllKeyBindings();
            if(this.props.pydio.UI.__proto__){
                this.__originalEnableShortcuts = this.props.pydio.UI.__proto__.enableShortcuts;
                this.props.pydio.UI.__proto__.enableShortcuts = function(){};
            }else{
                this.__originalEnableShortcuts = global['PydioUI'].prototype.enableShortcuts;
                global['PydioUI'].prototype.enableShortcuts = function(){};
            }
            var dm = this.props.pydio.getContextHolder();
            dm.observe("context_changed", this.dmChangesToState);
            dm.observe("selection_changed", this.dmChangesToState);
            // Monkey Patch Open Current Selection In Editor
            var monkeyObject = this.props.pydio.UI;
            if(this.props.pydio.UI.__proto__){
                monkeyObject = this.props.pydio.UI.__proto__;
            }
            monkeyObject.__originalOpenCurrentSelectionInEditor = monkeyObject.openCurrentSelectionInEditor;
            monkeyObject.openCurrentSelectionInEditor = function(dataModelOrNode){
                if(dataModelOrNode instanceof PydioDataModel){
                    this.openEditor(dataModelOrNode.getUniqueNode());
                }else{
                    this.openEditor(dataModelOrNode);
                }
            }.bind(this);
            this.props.pydio.observe("actions_loaded", function(){
                this.props.pydio.Controller.actions.delete("bookmark");
            }.bind(this));
        },

        componentWillUnmount: function(){
            if(this.props.pydio.UI.__proto__){
                this.props.pydio.UI.__proto__.enableShortcuts = this.__originalEnableShortcuts;
            }else{
                global['PydioUI'].prototype.enableShortcuts = this.__originalEnableShortcuts;
            }
            this.props.pydio.UI.enableAllKeyBindings();
            var dm = this.props.pydio.getContextHolder();
            dm.stopObserving("context_changed", this.dmChangesToState);
            dm.stopObserving("selection_changed", this.dmChangesToState);
            // Restore Monkey Patch
            var monkeyObject = this.props.pydio.UI;
            if(this.props.pydio.UI.__proto__){
                monkeyObject = this.props.pydio.UI.__proto__;
            }
            monkeyObject.openCurrentSelectionInEditor = monkeyObject.__originalOpenCurrentSelectionInEditor;
        },

        routeMasterPanel: function(node, selectedNode){
            var path = node.getPath();
            if(!selectedNode) selectedNode = node;

            var dynamicComponent;
            if(path == '/'){
                if(node.isRoot() && node.getMetadata().get('dashboard_issue')){
                    dynamicComponent = 'AdminHome.IssueDashboard';
                }else if(node.isRoot() && node.getMetadata().get('group_admin') && node.getMetadata().get('group_admin') == "1"){
                    dynamicComponent = 'AdminHome.GroupAdminDashboard';
                }else{
                    dynamicComponent = 'AdminHome.Dashboard';
                }
            }else if(node.getMetadata().get('component')){
                dynamicComponent = node.getMetadata().get('component');
            }else{
                return <div>No Component Found</div>;
            }
            var parts = dynamicComponent.split('.');
            return (
                <ReactPydio.AsyncComponent
                    namespace={parts[0]}
                    componentName={parts[1]}
                    dataModel={this.props.pydio.getContextHolder()}
                    rootNode={node}
                    currentNode={selectedNode}
                    openEditor={this.openEditor}
                    openRightPane={this.openRightPane}
                    closeRightPane={this.closeRightPane}
                    openModal={this.openModal}
                    dismissModal={this.emptyModal}
                />);
        },

        backToHome: function(){
            this.props.pydio.triggerRepositoryChange("ajxp_home");
        },

        render: function(){
            var dm = this.props.pydio.getContextHolder();
            var title = (
                <div style={{paddingLeft:50}}>
                    <img
                        className="custom_logo_image linked"
                        src="plugins/gui.ajax/res/themes/vision/images/white_logo.png"
                        title="Back to Home"
                        width=""
                        height=""
                        style={{height: 39, width: 'auto', marginTop: 12, marginLeft: -17}}
                        onClick={this.backToHome}
                    />
                </div>
            );
            var rPanelContent;
            if(this.state.rightPanel){
                rPanelContent = React.createElement(this.state.rightPanel.COMPONENT, this.state.rightPanel.PROPS, this.state.rightPanel.CHILDREN);
            }
            var rightPanel = (
                <ReactMUI.Paper zDepth={2} className={"paper-editor layout-fill vertical-layout" + (this.state.rightPanel?' visible':'')}>
                    {rPanelContent}
                </ReactMUI.Paper>
            );

            var appBarRight = (
                <ReactPydio.LegacyUIWrapper
                    componentName="UserWidget"
                    componentOptions={{iconClass:"icon-angle-down"}}
                    id="logging_string"
                    style={{position: 'absolute',right: 20, top: 7}}
                    onLoadCallback={function(instance){instance.updateGui();instance.updateActions();}}
                />
            );

            return (
                <ReactMUI.AppCanvas predefinedLayout={1}>
                    <ReactPydio.AsyncModal
                        ref="modal"
                        componentData={this.state.modalData}
                        onDismiss={this.emptyModal}
                        dataModel={this.props.pydio.getContextHolder()}
                    />
                    <AdminLeftNav
                        pydio={this.props.pydio}
                        dataModel={dm}
                        rootNode={dm.getRootNode()}
                        contextNode={dm.getContextNode()}
                        ref="leftNav"/>
                    <ReactMUI.AppBar
                        className="mui-dark-theme"
                        title={title}
                        zDepth={1}
                        showMenuIconButton={true}
                        onMenuIconButtonTouchTap={this.openLeftNav}
                        iconElementRight={appBarRight}
                    />
                    <div className="viewport-height main-panel">
                    {this.routeMasterPanel(dm.getContextNode(), dm.getUniqueNode())}
                    </div>
                    {rightPanel}
                </ReactMUI.AppCanvas>
            )
        }
    });

    var AdminComponents = global.AdminComponents || {};
    AdminComponents.MessagesConsumerMixin = MessagesConsumerMixin;
    AdminComponents.MenuItemListener = MenuItemListener;
    AdminComponents.PydioConsumerMixin = PydioConsumerMixin;
    if(global.ReactDND){
        AdminComponents.AdminDashboard = ReactDND.DragDropContext(ReactDND.HTML5Backend)(AdminDashboard);
    }else{
        AdminComponents.AdminDashboard = AdminDashboard;
    }
    AdminComponents.NavigationHelper = NavigationHelper;
    AdminComponents.DNDActionsManager = DNDActionsManager;
    AdminComponents.DeleteDialog = DeleteDialog;
    AdminComponents.PermissionMaskEditor = PermissionMaskEditor;
    AdminComponents.PermissionMaskEditorFree = PermissionMaskEditorFree;
    global.AdminComponents = AdminComponents;

})(window);