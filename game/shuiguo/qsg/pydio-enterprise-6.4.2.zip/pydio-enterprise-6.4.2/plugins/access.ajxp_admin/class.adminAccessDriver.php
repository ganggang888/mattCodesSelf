<?php
/*
 * Copyright 2007-2015 Abstrium SAS <team (at) pyd.io>
 * This file is part of the Pydio Enterprise Distribution.
 * It is subject to the End User License Agreement that you should have
 * received and accepted along with this distribution.
 */
defined('AJXP_EXEC') or die( 'Access not allowed');

require_once(AJXP_INSTALL_PATH.DIRECTORY_SEPARATOR.AJXP_PLUGINS_FOLDER.DIRECTORY_SEPARATOR."access.ajxp_conf".DIRECTORY_SEPARATOR."class.ajxp_confAccessDriver.php");
/**
 * @package AjaXplorer_Plugins
 * @subpackage Access
 * @class ajxp_confAccessDriver
 * AJXP_Plugin to access the configurations data
 */
class adminAccessDriver extends ajxp_confAccessDriver
{

    protected $rootNodes = array(
        "admin" => array(
            "LABEL" => "",
            "ICON" => "",
            "DESCRIPTION" => "",
            "CHILDREN" => array(
                "logs" => array(
                    "AJXP_MIME" => "users_zone",
                    "LABEL" => "ajxp_admin.menu.1",
                    "DESCRIPTION" => "ajxp_admin.menu.2",
                    "ICON" => "users-folder.png",
                    "LIST" => "listLogFiles",
                    "METADATA" => array(
                        "icon_class" => "icon-flag-alt",
                        "component"  => "LoggerTools.Dashboard"
                    )
                ),
            )
        ),
        "data" => array(
            "LABEL" => "ajxp_conf.110",
            "ICON" => "user.png",
            "DESCRIPTION" => "ajxp_conf.137",
            "CHILDREN" => array(
                "users" => array(
                    "AJXP_MIME" => "users_zone",
                    "LABEL" => "ajxp_conf.2",
                    "DESCRIPTION" => "ajxp_conf.139",
                    "ICON" => "users-folder.png",
                    "LIST" => "listUsers",
                    "METADATA" => array(
                        "icon_class" => "icon-user",
                        "component"  => "AdminPeople.Dashboard"
                    )
                ),
                "repositories" => array(
                    "AJXP_MIME" => "workspaces_zone",
                    "LABEL" => "ajxp_conf.3",
                    "DESCRIPTION" => "ajxp_conf.138",
                    "ICON" => "hdd_external_unmount.png",
                    "LIST" => "listRepositories",
                    "METADATA" => array(
                        "icon_class" => "icon-hdd",
                        "component"  => "AdminWorkspaces.Dashboard"
                    )
                ),
                "roles" => array(
                    "LIST" => "listRoles",
                ),
            )
        ),
        "frontend" => array(
            "AJXP_MIME" => "plugins_zone",
            "LABEL" => "ajxp_admin.menu.20",
            "ICON" => "preferences_desktop.png",
            "DESCRIPTION" => "ajxp_admin.menu.21",
            "CHILDREN" => array(
                "gui.ajax"  	   => array(
                    "AJXP_MIME" => "plugins_zone",
                    "LABEL" => "ajxp_admin.menu.3",
                    "DESCRIPTION" => "ajxp_admin.menu.4",
                    "ICON" => "preferences_desktop.png",
                    "METADATA" => array(
                        "icon_class" => "icon-laptop",
                        "component"  => "AdminPlugins.PluginEditor"
                    )
                ),
                "action.share" 	   => array(
                    "AJXP_MIME" => "plugins_zone",
                    "LABEL" => "ajxp_admin.menu.5",
                    "DESCRIPTION" => "ajxp_admin.menu.6",
                    "ICON" => "preferences_desktop.png",
                    "METADATA" => array(
                        "icon_class" => "mdi mdi-share-variant",
                        "component"  => "AdminPlugins.PluginEditor"
                    )
                ),
                "editor"  	   => array(
                    "ALIAS" => "/config/plugins/editor",
                    "AJXP_MIME" => "plugins_zone",
                    "LABEL" => "ajxp_admin.menu.7",
                    "DESCRIPTION" => "ajxp_admin.menu.8",
                    "ICON" => "preferences_desktop.png",
                    "LIST" => "listPlugins",
                    "METADATA" => array(
                        "icon_class" => "icon-file-text-alt",
                        "component"  => "AdminPlugins.EditorsDashboard"
                    )
                ),
                "uploader"  	   => array(
                    "ALIAS" => "/config/plugins/uploader",
                    "AJXP_MIME" => "plugins_zone",
                    "LABEL" => "ajxp_admin.menu.9",
                    "DESCRIPTION" => "ajxp_admin.menu.10",
                    "ICON" => "preferences_desktop.png",
                    "LIST" => "listPlugins",
                    "METADATA" => array(
                        "icon_class" => "icon-upload-alt",
                        "component"  => "AdminPlugins.CoreAndPluginsDashboard"
                    )
                )
            )
        ),
        "parameters" => array(
            "AJXP_MIME" => "plugins_zone",
            "LABEL" => "ajxp_conf.109",
            "ICON" => "preferences_desktop.png",
            "DESCRIPTION" => "ajxp_conf.136",
            "CHILDREN" => array(
                "core.ajaxplorer"  	   => array(
                    "AJXP_MIME" => "plugins_zone",
                    "LABEL" => "ajxp_conf.98",
                    "DESCRIPTION" => "ajxp_conf.133",
                    "ICON" => "preferences_desktop.png",
                    "METADATA" => array(
                        "icon_class" => "icon-cog",
                        "component"  => "AdminPlugins.PluginEditor"
                    )
                ),
                "core.auth"  	   => array(
                    "AJXP_MIME" => "plugins_zone",
                    "LABEL" => "ajxp_admin.menu.11",
                    "DESCRIPTION" => "plugtype.desc.auth",
                    "ICON" => "preferences_desktop.png",
                    "METADATA" => array(
                        "icon_class" => "icon-lock",
                        "component"  => "AdminPlugins.AuthenticationPluginsDashboard"
                    )
                ),
                "core.conf"  	   => array(
                    "AJXP_MIME" => "plugins_zone",
                    "LABEL" => "ajxp_admin.menu.12",
                    "DESCRIPTION" => "plugtype.desc.conf",
                    "ICON" => "preferences_desktop.png",
                    "METADATA" => array(
                        "icon_class" => "icon-suitcase",
                        "component"  => "AdminPlugins.PluginEditor"
                    )
                ),
                "core.log"  	   => array(
                    "AJXP_MIME" => "plugins_zone",
                    "LABEL" => "ajxp_admin.menu.13",
                    "DESCRIPTION" => "plugtype.desc.log",
                    "ICON" => "preferences_desktop.png",
                    "METADATA" => array(
                        "icon_class" => "icon-list",
                        "component"  => "AdminPlugins.PluginEditor"
                    )
                ),
                "core.mailer"  	   => array(
                    "AJXP_MIME" => "plugins_zone",
                    "LABEL" => "plugtype.title.mailer",
                    "DESCRIPTION" => "plugtype.desc.mailer",
                    "ICON" => "preferences_desktop.png",
                    "METADATA" => array(
                        "icon_class" => "icon-envelope-alt",
                        "component"  => "AdminPlugins.PluginEditor"
                    )
                ),
                "core.notifications" => array(
                    "AJXP_MIME" => "plugins_zone",
                    "LABEL" => "ajxp_admin.menu.14",
                    "DESCRIPTION" => "ajxp_admin.menu.15",
                    "ICON" => "preferences_desktop.png",
                    "METADATA" => array(
                        "icon_class" => "icon-bell",
                        "component"  => "AdminPlugins.PluginEditor"
                    )
                ),
                "core.mq" => array(
                    "AJXP_MIME" => "plugins_zone",
                    "LABEL" => "ajxp_admin.menu.16",
                    "DESCRIPTION" => "ajxp_admin.menu.17",
                    "ICON" => "preferences_desktop.png",
                    "METADATA" => array(
                        "icon_class" => "icon-rss",
                        "component"  => "AdminPlugins.PluginEditor"
                    )
                ),
                "core.cache"  	   => array(
                    "AJXP_MIME" => "plugins_zone",
                    "LABEL" => "plugtype.title.cache",
                    "DESCRIPTION" => "plugtype.desc.cache",
                    "ICON" => "preferences_desktop.png",
                    "METADATA" => array(
                        "icon_class" => "icon-rocket",
                        "component"  => "AdminPlugins.CacheServerDashboard"
                    )
                ),
                "core.ocs"  	   => array(
                    "AJXP_MIME" => "plugins_zone",
                    "LABEL" => "Pydio Cloud",
                    "DESCRIPTION" => "Open Cloud Sharing",
                    "ICON" => "preferences_desktop.png",
                    "METADATA" => array(
                        "icon_class" => "icon-cloud",
                        "component"  => "AdminPlugins.PluginEditor"
                    )
                ),
            )
        ),
        "plugins" => array(
            "AJXP_MIME" => "plugins_zone",
            "LABEL" => "ajxp_admin.menu.18",
            "ICON" => "preferences_desktop.png",
            "DESCRIPTION" => "ajxp_admin.menu.18",
            "CHILDREN" => array(
                "manager"  	   => array(
                    "ALIAS" => "/config/all",
                    "AJXP_MIME" => "plugins_zone",
                    "LABEL" => "ajxp_admin.menu.19",
                    "DESCRIPTION" => "ajxp_admin.menu.19",
                    "ICON" => "preferences_desktop.png",
                    "LIST" => "listPlugins",
                    "METADATA" => array(
                        "icon_class" => "icon-puzzle-piece",
                        "component"  => "AdminPlugins.PluginsManager"
                    )
                )
            )
        )
    );

    protected function getMainTree(){
        $rootNodes = $this->rootNodes;
        $updater = AJXP_PluginsService::findPluginById("action.updater");
        if ($updater !== false && $updater->isEnabled()){
            $rootNodes["admin"]["CHILDREN"]["action.updater"] = array(
                "AJXP_MIME" => "plugins_zone",
                "LABEL" => "updater.1",
                "DESCRIPTION" => "updater.2",
                "ICON" => "preferences_desktop.png",
                "METADATA" => array(
                    "icon_class" => "icon-cloud-download",
                    "component"  => "AdminPlugins.UpdaterDashboard"
                )
            );
        }

        if (AuthService::getLoggedUser() != null && AuthService::getLoggedUser()->getGroupPath() != "/") {
            unset($rootNodes["config"]);
            unset($rootNodes["frontend"]);
            unset($rootNodes["admin"]);
            unset($rootNodes["plugins"]);
            unset($rootNodes["parameters"]);
        }
        AJXP_Controller::applyHook("admin.list_config_nodes", array(&$rootNodes));

        // If invalid license, block everything else.
        $coreLicence = AJXP_PluginsService::findPluginById("core.licence");
        if( !is_a($coreLicence, "LicenceManager") || !$coreLicence->cachedLicenceValidity()){
            if(isSet($rootNodes["admin"]) && isSet($rootNodes["admin"]["CHILDREN"]["core.licence"])){
                $uniqueNode = $rootNodes["admin"]["CHILDREN"]["core.licence"];
                $rootNodes = array(
                    "__metadata__" => array("dashboard_issue" => "There seems to be an issue with your license validity. Please check your license value and reload the interface."),
                    "admin" => array(
                        "LABEL" => "",
                        "ICON" => "",
                        "DESCRIPTION" => "",
                        "CHILDREN" => array(
                            "core.licence" => $uniqueNode,
                        )
                    ),
                    "data" => array(
                        "CHILDREN" => array(
                            "users" => array(
                                "AJXP_MIME" => "users_zone",
                                "LABEL" => "ajxp_conf.2",
                                "DESCRIPTION" => "ajxp_conf.139",
                                "ICON" => "users-folder.png",
                                "LIST" => "listUsers",
                                "METADATA" => array(
                                    "icon_class" => "icon-user",
                                    "component"  => "AdminPeople.Dashboard"
                                )
                            ),
                        )
                    )
                );
            }else{
                $rootNodes = array(
                    "__metadata__" => array("dashboard_issue" => "Could not find the core.licence plugin necessary to run this interface. Please check your setup and reload : did you correctly configure IonCube? Did you disable the core.licence plugin?"),
                );
            }
        }

        return $rootNodes;
    }

    /**
     * @param $action
     * @param $httpVars
     * @param $fileVars
     */
    public function systemStatus($action, &$httpVars, &$fileVars){
        session_write_close();
        if(in_array(PHP_OS, array("WIN32", "WINNT", "Windows"))){
            $load = array('?', '?', '?');
        }else{
            $load = sys_getloadavg();
        }
        $disk = array(
            "free" => disk_free_space(AJXP_INSTALL_PATH),
            "total" => disk_total_space(AJXP_INSTALL_PATH)
        );
        HTMLWriter::charsetHeader("application/json");
        print json_encode(array(
            "cpu"  => round($load[0], 2),
            "load" => $load,
            "disk" => $disk
        ));
    }

    /**
     * @param $action
     * @param $httpVars
     * @param $fileVars
     */
    public function mostActive($action, &$httpVars, &$fileVars)
    {
        session_write_close();

        HTMLWriter::charsetHeader("application/json");
        $wheres = array( array("[params] != %s", "context=API") );

        if($httpVars["type"] == "user"){
            $filter = "user";
        }else if($httpVars["type"] == "ip"){
            $filter = "remote_ip";
        }else if($httpVars["type"] == "action"){
            $filter = "params";
            $wheres[] = array("[message] = %s", ucfirst(AJXP_Utils::sanitize($httpVars["action"])));
        }
        if(!isSet($filter)) {
            echo json_encode(array("ERROR" => "filter type not supported, please use 'user''ip'"));
            return;
        }
        if(isSet($httpVars["ws_id"])){
            $wheres[] = array("[repository_id] = %s", AJXP_Utils::sanitize($httpVars["ws_id"], AJXP_SANITIZE_ALPHANUM));
        }
        if(isSet($httpVars["filename_filter"])){
            $wheres[] = array("[basename] LIKE %s", str_replace("*", "%", AJXP_Utils::sanitize($httpVars["filename_filter"], AJXP_SANITIZE_FILENAME)));
        }
        if(isSet($httpVars["dirname_filter"])){
            $wheres[] = array("[dirname] LIKE %s", str_replace("*", "%", AJXP_Utils::sanitize($httpVars["dirname_filter"], AJXP_SANITIZE_DIRNAME)));
        }

        $start_time = time() - 24*60*60;
        if($httpVars["date_range"] == "last_day"){
            $start_time = time() - 24*60*60;
        }else if($httpVars["date_range"] == "last_week"){
            $start_time = time() - 24*60*60 * 7;
        }else if($httpVars["date_range"] == "last_month"){
            $start_time = time() - 24*60*60 * 31;
        }
        $end_time = time();
        $wheres[] = array('[logdate] BETWEEN %t AND %t', $start_time, $end_time);
        $sql = "SELECT [$filter] as Object, COUNT(*) as Activity FROM [ajxp_log] WHERE %and GROUP BY [$filter] ORDER BY Activity DESC";
        $res = dibi::query($sql, $wheres);
        $all = $res->fetchAll();
        foreach($all as $row){
            if(property_exists($row, "object")){
                $row->Object = $row->object;
                $row->Activity = $row->activity;
                unset($row->object);
                unset($row->activity);
            }
        }

        if($filter == "user"){
            $ids = array();
            $roles = array();
            foreach($all as $row){
                $ids[] = "AJXP_USR_/" . $row->Object;
            }
            $uRoles = AuthService::getRolesList($ids);
            foreach($ids as $u){
                if(!isSet($uRoles[$u])) continue;
                $data = $uRoles[$u]->getDataArray(true);
                $roles[$u] = $data["PARAMETERS"];
            }
            echo json_encode(array("DATA" => $all, "USERS" => $roles));
        }else{
            echo json_encode(array("DATA" => $all));
        }

    }

    /**
     * @param $action
     * @param $httpVars
     * @param $fileVars
     */
    public function listQueryActions($action, $httpVars, $fileVars){
        $data = array();
        $data["New Share"] = "Shares";
        $data["Download"] = "Downloads";
        $data["Upload File"] = "Uploads";
        $data["Preview"] = "Previews";
        $data["Create File"] = "Files Creations";
        $data["Create Dir"] = "Folders Creations";
        $data["Online Edition"] = "Edits";
        HTMLWriter::charsetHeader("application/json");
        echo json_encode(array("LIST" => $data));
    }

    /**
     * @param $action
     * @param $httpVars
     * @param $fileVars
     */
    public function richLogsList($action, &$httpVars, &$fileVars)
    {
        session_write_close();

        $wheres = array();
        $messages = ConfService::getMessages();

        // Date
        $rangeSet = false;
        if(isSet($httpVars["date_range"])){
            if($httpVars["date_range"] == "last_day"){
                $start_time = time() - 24*60*60;
                $end_time = time();
                $wheres[] = array('[logdate] BETWEEN %t AND %t', $start_time, $end_time);
                $rangeSet = true;
            }
        }else if(isSet($httpVars["start_date"]) && isSet($httpVars["end_date"])){
            $start_time = time() - 24*60*60;
            if(isSet($httpVars["start_date"])){
                $start_date = AJXP_Utils::sanitize($httpVars["start_date"], AJXP_SANITIZE_ALPHANUM);
                $start_time = strtotime($start_date);
            }
            $end_time = mktime(0,0,0,date('m', $start_time), date('d', $start_time) + 1, date('Y', $start_time));
            if(isSet($httpVars["end_date"])){
                $end_date = AJXP_Utils::sanitize($httpVars["end_date"], AJXP_SANITIZE_ALPHANUM);
                $end_time = strtotime($end_date);
            }
            $wheres[] = array('[logdate] BETWEEN %t AND %t', $start_time, $end_time);
            $rangeSet = true;
        }

        // User Filter
        if(isSet($httpVars["user"])){
            $subWheres = array();
            $usersFilters = explode(",", $httpVars["user"]);
            foreach($usersFilters as $filter){
                if(strpos($filter, "*")) $subWheres[] = array("[user] LIKE %s", str_replace("*", "%", $filter));
                else $subWheres[] = array("[user] = %s", $filter);
            }
            if(count($subWheres)){
                $wheres[] = array('%or', $subWheres);
            }
        }

        // Workspaces Filter
        if(isSet($httpVars["workspace"])){
            $wheres[] = array("[repository_id]=%s", AJXP_Utils::sanitize($httpVars["workspace"], AJXP_SANITIZE_ALPHANUM));
        }

        if(!isSet($httpVars["show_api_logins"])){
            $wheres[] = array("NOT ([message] = 'Log In' AND params= 'context=API')");
        }

        if(isSet($httpVars["operations"])){
            if($httpVars["operations"] == "files"){
                $wheres[] = array("%or", array(
                    array("[source] LIKE 'access.%'"),
                    array("[source] LIKE 'editor.%'"),
                    array("[source] LIKE 'meta.%'"),
                    array("[source] LIKE 'metastore.%'"),
                    array("[source] LIKE 'index.%'"),
                    array("[source] LIKE 'uploader.%'"),
                    array("[source] LIKE 'action.%'")
                ));
            }else if($httpVars["operations"] == "auth"){
                $wheres[] = array("%or", array(
                    array("[source] LIKE 'auth.%'"),
                    array("[source] = 'AuthService'"),
                    array("[source] = 'ConfServie'"),
                    array("[source] LIKE 'conf.%'")
                ));
            }
        }

        if(isSet($httpVars["levels"])){
            $subWheres = array();
            $levels = explode(",", $httpVars["levels"]);
            foreach($levels as $l){
                $subWheres[] = array("[severity] = %s", AJXP_Utils::sanitize($l, AJXP_SANITIZE_ALPHANUM));
            }
            if(count($subWheres)){
                $wheres[] = array("%or", $subWheres);
            }
        }

        try {
            //$order = "";
            $order = " ORDER BY [logdate] DESC ";
            if(!$rangeSet){
                $limit = 40; $offset=0;
                if(isSet($httpVars["limit"])) $limit = AJXP_Utils::sanitize($httpVars["limit"], AJXP_SANITIZE_ALPHANUM);
                if(isSet($httpVars["offset"])) $offset = AJXP_Utils::sanitize($httpVars["offset"], AJXP_SANITIZE_ALPHANUM);
                $q = "SELECT * FROM [ajxp_log] WHERE %and $order %lmt %ofs";
                $result = dibi::query($q, $wheres, $limit, $offset);
            }else{
                $q = "SELECT * FROM [ajxp_log] WHERE %and $order";
                $result = dibi::query($q, $wheres);
            }
            $log_items = array();
            $currentCount = 1;
            $users = array();
            $workspaces = array();
            foreach ($result as $r) {

                if(isSet($buffer) && $buffer["user"] == $r["user"] && $buffer["message"] == $r["message"]){
                    $currentCount ++;
                    continue;
                }
                if(isSet($buffer)){
                    $buffer['message'] = $buffer['message'].($currentCount > 1?" (".$currentCount.")":"");
                    $log_items[] = $buffer;
                }
                $r['readable_date'] = AJXP_Utils::relativeDate(strtotime($r['logdate']), $messages);
                $log_items[] = $r;
                $currentCount = 1;
                $buffer = $r;
                $users[$buffer["user"]] = 'AJXP_USR_/' . $buffer["user"];
                $workspaces[$buffer["repository_id"]] = $buffer["repository_id"];
            }
            if($httpVars["format"] == "xml"){
                AJXP_XMLWriter::renderSimpleListAsNodes($log_items, "/", "logdate", "logdate");
            }else{
                $uRoles = AuthService::getRolesList(array_values($users));
                foreach($users as $k => $u){
                    if(!isSet($uRoles[$u])) continue;
                    $data = $uRoles[$u]->getDataArray(true);
                    $users[$k] = $data["PARAMETERS"];
                }
                foreach($workspaces as $repoId => $value){
                    $object = ConfService::getRepositoryById($repoId);
                    if(!empty($object)) $workspaces[$repoId] = $object->getDisplay();
                }
                HTMLWriter::charsetHeader("application/json");
                print(json_encode(array("LOGS" => $log_items, "USERS" => $users, "WORKSPACES" => $workspaces)));
            }

        } catch (DibiException $e) {
            echo get_class($e), ': ', $e->getMessage(), "\n";
            exit(1);
        }
    }

    /**
     * @param $actionName
     * @param $httpVars
     * @param $fileVars
     * @throws Exception
     */
    public function displayEnterprise($actionName, $httpVars, $fileVars){
        HTMLWriter::charsetHeader("application/json");
        echo json_encode(["display" => false]);
    }

}