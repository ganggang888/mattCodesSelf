<?php
/*
 * Copyright 2007-2015 Abstrium SAS <team (at) pyd.io>
 * This file is part of the Pydio Enterprise Distribution.
 * It is subject to the End User License Agreement that you should have
 * received and accepted along with this distribution.
 */
$mess=array(
"Admin Driver" => "Admin Driver",
"Access Pydio configuration data." => "Access Pydio configuration data.",
);
