<?php
/*
 * Copyright 2007-2015 Abstrium SAS <team (at) pyd.io>
 * This file is part of the Pydio Enterprise Distribution.
 * It is subject to the End User License Agreement that you should have
 * received and accepted along with this distribution.
 */
defined('AJXP_EXEC') or die( 'Access not allowed');
require_once('../classes/class.AbstractTest.php');

/**
 * Check current PHP Version
 * @package Pydio
 * @subpackage Tests
 */
class IonCubeExtension extends AbstractTest
{
    public function __construct() { parent::__construct("IonCube Extension", "Checking for IonCube Loader"); }
    public function doTest()
    {
        return extension_loaded("ionCube Loader");
    }
}