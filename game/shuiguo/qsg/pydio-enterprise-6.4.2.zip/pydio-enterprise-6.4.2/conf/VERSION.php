<?php
define("AJXP_VERSION", "6.4.2");
define("AJXP_VERSION_DATE", "2016-07-25");
define("AJXP_VERSION_REV", "c60dd4b");
define("AJXP_VERSION_DB", "62");
