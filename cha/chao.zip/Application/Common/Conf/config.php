<?php
return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'group',
    'DB_USER' => 'root',
    'DB_PWD' => '111111',
    'DB_PORT' => '3306',
    'DB_PREFIX' => 'm_',
);
