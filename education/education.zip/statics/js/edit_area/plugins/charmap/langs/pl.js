editArea.add_lang("pl",{
charmap_but: "Klawiatura ekranowa",
charmap_title: "Klawiatura ekranowa",
charmap_choose_block: "wybierz grupę znaków",
charmap_insert:"wstaw ten znak"
});
