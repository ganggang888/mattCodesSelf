<?php

/**
 * 配置文件
 */
return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'education',
    'DB_USER' => 'root',
    'DB_PWD' => '111111',
    'DB_PORT' => '3306',
    'DB_PREFIX' => 'matt_',
    //密钥
    "AUTHCODE" => '1cyPwcORhQkyfvFpzp',
    //cookies
    "COOKIE_PREFIX" => 'Wc71jD_',
);
?>