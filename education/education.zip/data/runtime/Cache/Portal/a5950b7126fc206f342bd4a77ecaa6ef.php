<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
<title><?php echo ($site_seo_title); ?> <?php echo ($site_name); ?></title>
<meta name="keywords" content="<?php echo ($site_seo_keywords); ?>" />
<meta name="description" content="<?php echo ($site_seo_description); ?>">
<link href="/tpl/simplebootx/Public/css/css.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="http://www.matteducation.com/favicon.ico" type="image/x-icon" />
<script language="javascript" src="/tpl/simplebootx/Public/js/js.js"></script>
<style type="text/css">
.style2 {
	color: #007F4A;
}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<body>
</head>


<div class="tu"></div>
<div class="top">
  <div class="logo"><a href="#"><img src="/tpl/simplebootx/Public/images/logo.jpg" width="336" height="58" 
        alt="上海月嫂培训,上海育婴师培训" /></a></div>
  <div class="nav">
    <table cellpadding="0" cellspacing="0" width="600" align="right">
      <tr>
        <td><div class="nav_t">
            <div class="nav_t1"><a href="/" target="_blank"><span style="color:#F67A00;font-size:12px;">公司首页</span></a>&nbsp;|&nbsp;<a href="<?php echo leuu('portal/page/index',array('id'=>12));?>">联系我们</a><!--&nbsp;|&nbsp;<!--<a href="#">英文</a>&nbsp;|&nbsp;<a href="#">中文</a> &nbsp;&nbsp;--><span><!--<a href="login.html">登录</a>--></span>&nbsp;&nbsp;|&nbsp;&nbsp;<span></span> </div>
            <div class="nav_t2"><a href="http://weibo.com/mattservice/" target="_blank"><img src="/tpl/simplebootx/Public/images/wb.jpg" width="42" height="15" /></a><a href="join.html"><img src="/tpl/simplebootx/Public/images/jiaru.jpg" width="94" height="15" border="0" /></a></div>
          </div></td>
      </tr>
      <tr>
        <td><div class="clear"></div>
          <div class="nav_b">
            <ul>
              <li><a href="/">首页</a></li>
              <li><a href="<?php echo leuu('Portal/page/index',array('id'=>2));?>" id="two1" onmouseover="setTab('two',1,7)">麦忒教育</a></li>
              <li><a href="<?php echo leuu('Portal/page/index',array('id'=>10));?>" id="two2" onmouseover="setTab('two',2,7)">入户早教</a></li>
              <li><a href="<?php echo leuu('Portal/page/index',array('id'=>1));?>" id="two3" onmouseover="setTab('two',3,7)">研究中心</a></li>
              <li><a href="<?php echo leuu('Portal/teacher/index');?>" id="two4" onmouseover="setTab('two',4,7)">早教专家</a></li>
              <li><a href="<?php echo leuu('Portal/page/index',array('id'=>11));?>" id="two5" onmouseover="setTab('two',5,7)">麦麦育儿机器人</a></li>
              <li><a href="<?php echo leuu('Portal/page/index',array('id'=>4));?>" id="two6" onmouseover="setTab('two',6,7)">专利教具</a></li>
              <li><a href="<?php echo leuu('Portal/list/index',array('id'=>3));?>" id="two7" onmouseover="setTab('two',7,7)">育儿直通车</a></li>
            </ul>
          </div></td>
      </tr>
      <tr>
        <td align="left" style="padding-left:100px; "><div id="con_two_1" style="display:none; "> </div>
          <!--<div id="con_two_2" style="display:none; "> <img src="/tpl/simplebootx/Public/images/lz.jpg" width="5" height="19" align="top"/> <a href="<?php echo leuu('Portal/list/index',array('id'=>3));?>">校园新闻</a> <a href="<?php echo leuu('Portal/list/index',array('id'=>4));?>">师生心得</a> <a href="<?php echo leuu('Portal/list/index',array('id'=>11));?>">育婴知识</a> <a href="<?php echo leuu('Portal/list/index',array('id'=>6));?>">最新活动</a> <img src="/tpl/simplebootx/Public/images/rz.jpg" width="5" height="19" align="top"/> </div>-->
          <div id="con_two_3" style="display:none; "></div>
          <!--<div id="con_two_4" style="display:none; "> <img src="/tpl/simplebootx/Public/images/lz.jpg" width="5" height="19" align="top"/> <a href="<?php echo leuu('Portal/page/index',array('id'=>1));?>">课程介绍</a> <a href="#">课程查询</a> <img src="/tpl/simplebootx/Public/images/rz.jpg" width="5" height="19" align="top"/> </div>-->
          <!--<div id="con_two_5" style="display:none; "> <img src="/tpl/simplebootx/Public/images/lz.jpg" width="5" height="19" align="top"/> <a href="<?php echo leuu('Portal/page/index',array('id'=>2));?>">学校介绍</a> <a href="<?php echo leuu('Portal/page/index',array('id'=>3));?>">校长寄语</a> <a href="<?php echo leuu('Portal/teacher/index');?>">教师介绍</a> <a href="<?php echo leuu('Portal/student/index');?>">学员风采</a> <a href="">教授证书的展示</a> <img src="/tpl/simplebootx/Public/images/rz.jpg" width="5" height="19" align="top"/> </div>-->
          <!--<div id="con_two_6" style="display:none; "> <img src="/tpl/simplebootx/Public/images/lz.jpg" width="5" height="19" align="top"/> <a href="">教师VCR推荐</a> <a href="">学员VCR推荐</a> <img src="/tpl/simplebootx/Public/images/rz.jpg" width="5" height="19" align="top"/> </div>-->
          <div id="con_two_7" style="display:none; "></div></td>
      </tr>
    </table>
  </div>
</div>

<div class="banner" style="background-image:url(/tpl/simplebootx/Public/images/flash.jpg); width:1149px; height:561px; ">
  <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="1149" height="561">
    <param name="movie" value="/tpl/simplebootx/Public/flash.swf" />
    <param name="quality" value="high" />
    <param name="wmode" value="transparent" />
    <embed src="/tpl/simplebootx/Public/flash.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="1149" height="561" wmode="transparent"></embed>
  </object>
</div>
<div class="zb">
  <!--<div class="zb1"><a href="join.aspx" class="joinmatt"></a></div>-->
</div>
<div class="main">
  <div class="m1">
    <div class="mmm"><a href="<?php echo leuu('Portal/list/index',array('id'=>11));?>"><img class="mmm123" src="/tpl/simplebootx/Public/images/teacher.jpg" height="15" /><span>客户分享<span class="mmmnews"> Customer</span></span></a> </div>
    <div class="m3"><a href="<?php echo leuu('Portal/list/index',array('id'=>11));?>"></a></div>
  </div>
  <div class="m1_1">
    <div class="mmm"><a href="<?php echo leuu('Portal/teacher/index');?>"><img class="mmm123" src="/tpl/simplebootx/Public/images/teacher.jpg" height="15" /><span>早教老师<span class="mmmnews"> Teacher</span></span></a></div>
    <div class="m3_3"><a href="<?php echo leuu('Portal/teacher/index');?>"></a></div>
  </div>
  <div class="m1_1_1">
    <div class="mmm"><a href="student.html"><img class="mmm123" src="/tpl/simplebootx/Public/images/teacher.jpg" height="15" /><span>VCR欣赏<span class="mmmnews"> Vcr</span></span></a></div>
    <div class="m3_3_3"><a href="student.html"></a></div>
  </div>
  <div class="news_s">
    <div class="ma1"> <a href="<?php echo leuu('Portal/list/index',array('id'=>3));?>"><img class="mmm123" src="/tpl/simplebootx/Public/images/teacher.jpg" height="15" /><span>麦忒家庭育儿直通车<span class="mmmnews"> News</span></span></a><a href="news.html"><img src="/tpl/simplebootx/Public/images/more.jpg" width="37" height="17" class="more" /></a></div>
    <div class="news_sb">
      <ul>
        <?php $lastnews=sp_sql_posts("cid:3;field:post_title,post_excerpt,tid,smeta;order:listorder desc;limit:3;"); ?>
        <?php if(is_array($lastnews)): foreach($lastnews as $key=>$vo): ?><li><span><?php echo mb_substr($vo[post_date],0,10,'utf-8');?></span><a href="<?php echo leuu('Portal/article/index',array('id'=>$vo['tid']));?>"><?php echo ($vo["post_title"]); ?></a></li><?php endforeach; endif; ?>
      </ul>
    </div>
  </div>
</div>
<div id="piao_img" style="position:absolute; display:; top: 147px; left: 5px;" onMouseOver="javascript:stop()" onMouseOut="javascript:start()">
  <table width='120' cellpadding='8' cellspacing='3'>
    <tr>
      <td align='center'  style='LETTER-SPACING: 0.2em;cursor:none;'><a href="about.html?id=29"><img src="/tpl/simplebootx/Public/images/triballoon.gif" border="0" width ="286px" height="552px"></a><br>
        <font color='green'> </font></td>
    </tr>
  </table>
</div>
<script type="text/javascript" >
    //飘动图片begin

    var xPos = 20;
    var yPos = document.body.clientHeight;
    var step = 1;
    var delay = 30;
    var height = 0;
    var Hoffset = 0;
    var Woffset = 0;
    var yon = 0;
    var xon = 0;
    var pause = true;
    var interval;
    piao_img.style.top = yPos;
    function changePos() {
        width = document.body.clientWidth;
        height = document.body.clientHeight;
        Hoffset = piao_img.offsetHeight;
        Woffset = piao_img.offsetWidth;
        piao_img.style.left = xPos + document.body.scrollLeft+"px";
        piao_img.style.top = yPos + document.body.scrollTop+"px";
        if (yon) {
            yPos = yPos + step;
        }
        else {
            yPos = yPos - step;
        }
        if (yPos < 0) {
            yon = 1;
            yPos = 0;
        }
        if (yPos >= (height - Hoffset)) {
            yon = 0;
            yPos = (height - Hoffset);
        }
        if (xon) {
            xPos = xPos + step;
        }
        else {
            xPos = xPos - step;
        }
        if (xPos < 0) {
            xon = 1;
            xPos = 0;
        }
        if (xPos >= (width - Woffset)) {
            xon = 0;
            xPos = (width - Woffset);
        }
    }
    function stop() {
        clearInterval(interval);
        //alert("stop")
    }
    function start() {
        piao_img.visibility = "visible";
        interval = setInterval('changePos()', delay);
    }
    start();
    //飘动图片end
</script>
  <div class="clear"></div>
  <div class="bottom_z">
  <div class="bottom">
    <div class="logo1"><img src="/tpl/simplebootx/Public/images/logo1.jpg" width="77" height="39" /></div>
    <div class="bottom_n"><a href="<?php echo leuu('portal/page/index',array('id'=>12));?>">联系我们</a> |<a href="#">官网微博</a> <span>上海麦忒育婴职业技术培训学校 保留所有权利&nbsp;沪ICP备09045106号-2</span> </div>
    <div class="bottom_tel">021-51022333</div>
    <br />
    <div class="youqing">项目导航：&nbsp;<a href="http://www.matteducation.com">上海月嫂培训</a>&nbsp;&nbsp;<a href="http://www.matteducation.com">上海月嫂培训班</a>&nbsp;&nbsp;<a href="http://www.matteducation.com" >上海育婴师培训</a>&nbsp;&nbsp;<a href="http://www.matteducation.com" >上海育婴师培训班</a>&nbsp;&nbsp;<a href="http://www.matteducation.com" >上海培训育婴师</a>&nbsp;&nbsp;<a href="http://www.matteducation.com" >上海培训月嫂</a></div>
    <?php $links=sp_getlinks(); ?>
    <div class="youqing ">友情链接： 
    <?php if(is_array($links)): foreach($links as $key=>$vo): ?><a href="<?php echo ($vo["link_url"]); ?>" target="<?php echo ($vo["link_target"]); ?>"><?php echo ($vo["link_name"]); ?></a>
    &nbsp;<?php endforeach; endif; ?>
    </div>
  </div>
  </div>
  <!--<table width='120' cellpadding='8' cellspacing='3' style="position:fixed; display:; top: 300px; left: 5px;">
    <tr>
      <td align='center'  style='LETTER-SPACING: 0.2em;'><a href="MattschoolQR.jpg"><img src="http://www.matteducation.com/MattschoolQR.jpg" border="0" width ="129px" height="129px"></a><br>
        <font color='green'> 微信扫一扫</font></td>
    </tr>
  </table>-->
  <?php echo ($site_tongji); ?>
</body>
</html>