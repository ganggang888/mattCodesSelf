<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
<title><?php echo ($name); ?> <?php echo ($seo_title); ?> <?php echo ($site_name); ?></title>
<meta name="keywords" content="<?php echo ($seo_keywords); ?>" />
<meta name="description" content="<?php echo ($seo_description); ?>">
<link href="/education/tpl/simplebootx/Public/css/css.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="http://www.matteducation.com/favicon.ico" type="image/x-icon" />
<script language="javascript" src="/education/tpl/simplebootx/Public/js/js.js"></script>
<style type="text/css">
.style2 {
	color: #007F4A;
}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<body>
</head>


<div class="tu"></div>
<div class="top">
  <div class="logo"><a href="#"><img src="/education/tpl/simplebootx/Public/images/logo.jpg" width="336" height="58" 
        alt="上海月嫂培训,上海育婴师培训" /></a></div>
  <div class="nav">
    <table cellpadding="0" cellspacing="0" width="600" align="right">
      <tr>
        <td><div class="nav_t">
            <div class="nav_t1"><a href="index.php" target="_blank"><span style="color:#F67A00;font-size:12px;">公司首页</span></a>&nbsp;|&nbsp;<a href="<?php echo leuu('portal/page/index',array('id'=>4));?>">联系我们</a>&nbsp;|&nbsp;<!--<a href="#">英文</a>&nbsp;|&nbsp;<a href="#">中文</a> &nbsp;&nbsp;--><span><a href="login.html">登录</a></span>&nbsp;&nbsp;|&nbsp;&nbsp;<span><a href="reg.html">注册</a></span> </div>
            <div class="nav_t2"><a href="http://weibo.com/mattservice/" target="_blank"><img src="/education/tpl/simplebootx/Public/images/wb.jpg" width="42" height="15" /></a><a href="join.html"><img src="/education/tpl/simplebootx/Public/images/jiaru.jpg" width="94" height="15" border="0" /></a></div>
          </div></td>
      </tr>
      <tr>
        <td><div class="clear"></div>
          <div class="nav_b">
            <ul>
              <li><a href="index.php">首页</a></li>
              <li><a href="<?php echo leuu('Portal/page/index',array('id'=>2));?>" id="two1" onmouseover="setTab('two',1,7)">麦忒教育</a></li>
              <li><a href="<?php echo leuu('Portal/page/index',array('id'=>10));?>" id="two2" onmouseover="setTab('two',2,7)">入户早教</a></li>
              <li><a href="<?php echo leuu('Portal/page/index',array('id'=>1));?>" id="two3" onmouseover="setTab('two',3,7)">研究中心</a></li>
              <li><a href="<?php echo leuu('Portal/teacher/index');?>" id="two4" onmouseover="setTab('two',4,7)">早教专家</a></li>
              <li><a href="<?php echo leuu('Portal/page/index',array('id'=>11));?>" id="two5" onmouseover="setTab('two',5,7)">麦麦育儿机器人</a></li>
              <li><a href="<?php echo leuu('Portal/page/index',array('id'=>4));?>" id="two6" onmouseover="setTab('two',6,7)">专利教具</a></li>
              <li><a href="<?php echo leuu('Portal/list/index',array('id'=>3));?>" id="two7" onmouseover="setTab('two',7,7)">育儿直通车</a></li>
            </ul>
          </div></td>
      </tr>
      <tr>
        <td align="left" style="padding-left:100px; "><div id="con_two_1" style="display:none; "> </div>
          <!--<div id="con_two_2" style="display:none; "> <img src="/education/tpl/simplebootx/Public/images/lz.jpg" width="5" height="19" align="top"/> <a href="<?php echo leuu('Portal/list/index',array('id'=>3));?>">校园新闻</a> <a href="<?php echo leuu('Portal/list/index',array('id'=>4));?>">师生心得</a> <a href="<?php echo leuu('Portal/list/index',array('id'=>11));?>">育婴知识</a> <a href="<?php echo leuu('Portal/list/index',array('id'=>6));?>">最新活动</a> <img src="/education/tpl/simplebootx/Public/images/rz.jpg" width="5" height="19" align="top"/> </div>-->
          <div id="con_two_3" style="display:none; "></div>
          <!--<div id="con_two_4" style="display:none; "> <img src="/education/tpl/simplebootx/Public/images/lz.jpg" width="5" height="19" align="top"/> <a href="<?php echo leuu('Portal/page/index',array('id'=>1));?>">课程介绍</a> <a href="#">课程查询</a> <img src="/education/tpl/simplebootx/Public/images/rz.jpg" width="5" height="19" align="top"/> </div>-->
          <!--<div id="con_two_5" style="display:none; "> <img src="/education/tpl/simplebootx/Public/images/lz.jpg" width="5" height="19" align="top"/> <a href="<?php echo leuu('Portal/page/index',array('id'=>2));?>">学校介绍</a> <a href="<?php echo leuu('Portal/page/index',array('id'=>3));?>">校长寄语</a> <a href="<?php echo leuu('Portal/teacher/index');?>">教师介绍</a> <a href="<?php echo leuu('Portal/student/index');?>">学员风采</a> <a href="">教授证书的展示</a> <img src="/education/tpl/simplebootx/Public/images/rz.jpg" width="5" height="19" align="top"/> </div>-->
          <!--<div id="con_two_6" style="display:none; "> <img src="/education/tpl/simplebootx/Public/images/lz.jpg" width="5" height="19" align="top"/> <a href="">教师VCR推荐</a> <a href="">学员VCR推荐</a> <img src="/education/tpl/simplebootx/Public/images/rz.jpg" width="5" height="19" align="top"/> </div>-->
          <div id="con_two_7" style="display:none; "></div></td>
      </tr>
    </table>
  </div>
</div>

<div class="banner1"><img src="/education/tpl/simplebootx/Public/images/banner1.jpg" width="1002" height="246" /></div>
<div class="main1">
  <div class="m_l">
    <div class="m_lt"><img src="/education/tpl/simplebootx/Public/images/left_t.jpg" width="213" height="32" /></div>
    <div class="m_lz">
      <div class="m_lz1"><a href="<?php echo leuu('Portal/teacher/index');?>"></a></div>
    </div>
    <div class="m_lz">
      <div class="m_lz2"><a href="<?php echo leuu('Portal/page/index',array('id'=>10));?>"></a></div>
    </div>
    <div class="m_lz">
      <div class="m_lz3"><a href="<?php echo leuu('Portal/page/index',array('id'=>4));?>"></a></div>
    </div>
    <!--<div class="m_lb"> <a href="join.html"></a></div>-->
    <!--<div class="tu1"><a href="about.html?id=37"><img src="/education/tpl/simplebootx/Public/images/tu1.jpg" width="213" height="142" border="0" /></a></div>-->
  </div>
  <div class="m_r">
    <div class="m_r1">
      <div class="m_rt"><img src="/education/tpl/simplebootx/Public/images/right_t.jpg" width="771" height="38" /></div>
      <div class="m_rz">
<div class="m_rz1">
<span><font color="#333">首页</font>&nbsp;>&nbsp;学员风采</span>学员风采</div>



<div class="xycx">
<div class="xycx1"><div class="xycx1_1"><input type="text" name="title" class="cd2" value="学号" /></div><div class="xycx1_2"><select name="dengji" class="cd3">
  <option>学历</option>
  <option value="1">初中</option>
  <option value="2">高中</option>
  <option value="3">大学本科</option>

</select></div></div>
<div class="clear"></div>

<div class="xycx2"><div class="xycx1_1"><input type="text" class="cd2" name="xuehao" value="学籍号" /></div><div class="xycx1_2"><select name="province" class="cd3">
<option value=>籍贯</option> 
<option value=广东>广东</option> 
<option value=北京>北京</option> 
<option value=湖南>湖南</option> 
<option value=福建>福建</option> 
<option value=上海>上海</option> 
<option value=安徽>安徽</option> 
<option value=广西>广西</option> 
<option value=贵州>贵州</option> 
<option value=海南>海南</option> 
<option value=河北>河北</option>
<option value=黑龙江>黑龙江</option> 
<option value=河南>河南</option> 
<option value=香港>香港</option> 
<option value=湖北>湖北</option> 
<option value=重庆>重庆</option> 
<option value=江苏>江苏</option> 
<option value=江西>江西</option> 
<option value=吉林>吉林</option> 
<option value=辽宁>辽宁</option> 
<option value=澳门>澳门</option>
<option value=内蒙古>内蒙古</option> 
<option value=宁夏>宁夏</option> 
<option value=青海>青海</option> 
<option value=山东>山东</option> 
 <option value=甘肃>甘肃</option> 
<option value=山西>山西</option> 
<option value=陕西>陕西</option> 
<option value=四川>四川</option> 
<option value=台湾>台湾</option> 
<option value=天津>天津</option>  
<option value=新疆>新疆</option> 
<option value=西藏>西藏</option> 
<option value=云南>云南</option> 
<option value=浙江>浙江</option>
</select></div></div>

<div class="clear"></div>
<div class="xycx2"><div class="xycx1_3"><select name="nianling" class="cd4" id="nianling">
  <option value="0">年龄段</option>
  <option>20及以下</option>
  <option>21-25</option>
  <option>26-30</option>
  <option>31-35</option>
  <option>36-40</option>
  <option>41-45</option>
  <option>46-50</option>
  <option>51及以上</option>
</select></div><div class="xycx1_2"><select name="zhengshu" class="cd3">
  <option>证书拥有情况</option>
  <option value="1">幼儿家庭成长导师证</option>
  <option value="2">母婴护理资格证</option>
  <option value="3">初级育婴师资格证</option>
  <option value="4">中级育婴师资格证</option>
</select></div></div>

<div class="clear"></div>
<div class="xycx2"><div class="xycx1_3"><select name="" class="cd4">
  <option>年龄段</option>
  <option>20及以下</option>
  <option>21-25</option>
  <option>26-30</option>
  <option>31-35</option>
  <option>36-40</option>
  <option>41-45</option>
  <option>46-50</option>
  <option>51及以上</option>
</select></div>

</div>
<div class="clear"></div>

<div class="xycz"><input type="image" name="ImgBtn" id="ImgBtn" src="/education/tpl/simplebootx/Public/images/xyca.jpg" style="border-width:0px;" /> </div>
</div>


<?php if(is_array($rows)): foreach($rows as $key=>$vo): ?><div class="m_rz2"> 
      <div class="m_rz3"><a href="<?php echo leuu('Portal/student/detail',array('id'=>$vo['id']));?>"><img src="<?php echo ($vo["img"]); ?>" width="152" height="184" border="0" /></a></div>
      
     <div class="xy">
     <div class="xy1">学号：<input name="" value="<?php echo ($vo["num"]); ?>" type="text" class="bd1" /></div>
     <div class="xy1">籍贯：<input name="" value="<?php echo ($vo["place"]); ?>" type="text" class="bd1" /></div>
     </div>
     
     <div class="xy">
     <div class="xy1">年龄：<input name="" value="<?php echo ($vo["age"]); ?>" type="text" class="bd1" /></div>
     <div class="xy1">学历：<input name="" value="<?php echo ($vo["education"]); ?>" type="text" class="bd1" /></div>
     </div>
     
     <div class="xy">
     <div class="xy2">证书：<input name="" value="<?php echo ($vo["book"]); ?>" type="text" class="bd2" /></div>
     </div>
     
     <div class="xy">
     <div class="xy3"><span>工作经历：</span><textarea name="" cols="" rows="" class="bd3"><?php echo ($vo["experience"]); ?></textarea></div>
     </div>
     
</div><?php endforeach; endif; ?>     
	     
	      
	     
    
	     
	     
	      
	     
    
	     
	     
	      
	     
    
	     
	     
	      
      


<div class="shu2">

<div class="ppage"><?php echo ($page); ?></div>


</div>





</div>
      <div class="m_rb"> <img src="/education/tpl/simplebootx/Public/images/right_b.jpg" width="771" height="38" /></div>
    </div>
  </div>
</div>
  <div class="clear"></div>
  <div class="bottom_z">
  <div class="bottom">
    <div class="logo1"><img src="/education/tpl/simplebootx/Public/images/logo1.jpg" width="77" height="39" /></div>
    <div class="bottom_n"> <a href="login.html">用户中心</a> | <a href="about.html?id=34">联系我们</a> | <a href="job.html">招贤纳士</a> | <a href="map.html">校园地图</a> | <a href="#">官网微博</a> <span>上海麦忒育婴职业技术培训学校 保留所有权利&nbsp;沪ICP备09045106号-2</span> </div>
    <div class="bottom_tel">021-51022333</div>
    <br />
    <div class="youqing">项目导航：&nbsp;<a href="http://www.matteducation.com">上海月嫂培训</a>&nbsp;&nbsp;<a href="http://www.matteducation.com">上海月嫂培训班</a>&nbsp;&nbsp;<a href="http://www.matteducation.com" >上海育婴师培训</a>&nbsp;&nbsp;<a href="http://www.matteducation.com" >上海育婴师培训班</a>&nbsp;&nbsp;<a href="http://www.matteducation.com" >上海培训育婴师</a>&nbsp;&nbsp;<a href="http://www.matteducation.com" >上海培训月嫂</a></div>
    <?php $links=sp_getlinks(); ?>
    <div class="youqing ">友情链接： 
    <?php if(is_array($links)): foreach($links as $key=>$vo): ?><a href="<?php echo ($vo["link_url"]); ?>" target="<?php echo ($vo["link_target"]); ?>"><?php echo ($vo["link_name"]); ?></a>
    &nbsp;<?php endforeach; endif; ?>
      </div>
  </div>
  </div>
  <table width='120' cellpadding='8' cellspacing='3' style="position:fixed; display:; top: 300px; left: 5px;">
    <tr>
      <td align='center'  style='LETTER-SPACING: 0.2em;'><a href="MattschoolQR.jpg"><img src="MattschoolQR.jpg" border="0" width ="129px" height="129px"></a><br>
        <font color='green'> 微信扫一扫</font></td>
    </tr>
  </table>
  <?php echo ($site_tongji); ?>
</body>
</html>