<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
<title><?php echo ($name); ?> <?php echo ($seo_title); ?> <?php echo ($site_name); ?></title>
<meta name="keywords" content="<?php echo ($seo_keywords); ?>" />
<meta name="description" content="<?php echo ($seo_description); ?>">
<link href="/education/tpl/simplebootx/Public/css/css.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="http://www.matteducation.com/favicon.ico" type="image/x-icon" />
<script language="javascript" src="/education/tpl/simplebootx/Public/js/js.js"></script>
<style type="text/css">
.style2 {
	color: #007F4A;
}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<body>
</head>


<div class="tu"></div>
<div class="top">
  <div class="logo"><a href="#"><img src="/education/tpl/simplebootx/Public/images/logo.jpg" width="336" height="58" 
        alt="上海月嫂培训,上海育婴师培训" /></a></div>
  <div class="nav">
    <table cellpadding="0" cellspacing="0" width="600" align="right">
      <tr>
        <td><div class="nav_t">
            <div class="nav_t1"><a href="index.php" target="_blank"><span style="color:#F67A00;font-size:12px;">公司首页</span></a>&nbsp;|&nbsp;<a href="<?php echo leuu('portal/page/index',array('id'=>12));?>">联系我们</a><!--&nbsp;|&nbsp;<!--<a href="#">英文</a>&nbsp;|&nbsp;<a href="#">中文</a> &nbsp;&nbsp;--><span><!--<a href="login.html">登录</a>--></span>&nbsp;&nbsp;|&nbsp;&nbsp;<span></span> </div>
            <div class="nav_t2"><a href="http://weibo.com/mattservice/" target="_blank"><img src="/education/tpl/simplebootx/Public/images/wb.jpg" width="42" height="15" /></a><a href="join.html"><img src="/education/tpl/simplebootx/Public/images/jiaru.jpg" width="94" height="15" border="0" /></a></div>
          </div></td>
      </tr>
      <tr>
        <td><div class="clear"></div>
          <div class="nav_b">
            <ul>
              <li><a href="index.php">首页</a></li>
              <li><a href="<?php echo leuu('Portal/page/index',array('id'=>2));?>" id="two1" onmouseover="setTab('two',1,7)">麦忒教育</a></li>
              <li><a href="<?php echo leuu('Portal/page/index',array('id'=>10));?>" id="two2" onmouseover="setTab('two',2,7)">入户早教</a></li>
              <li><a href="<?php echo leuu('Portal/page/index',array('id'=>1));?>" id="two3" onmouseover="setTab('two',3,7)">研究中心</a></li>
              <li><a href="<?php echo leuu('Portal/teacher/index');?>" id="two4" onmouseover="setTab('two',4,7)">早教专家</a></li>
              <li><a href="<?php echo leuu('Portal/page/index',array('id'=>11));?>" id="two5" onmouseover="setTab('two',5,7)">麦麦育儿机器人</a></li>
              <li><a href="<?php echo leuu('Portal/page/index',array('id'=>4));?>" id="two6" onmouseover="setTab('two',6,7)">专利教具</a></li>
              <li><a href="<?php echo leuu('Portal/list/index',array('id'=>3));?>" id="two7" onmouseover="setTab('two',7,7)">育儿直通车</a></li>
            </ul>
          </div></td>
      </tr>
      <tr>
        <td align="left" style="padding-left:100px; "><div id="con_two_1" style="display:none; "> </div>
          <!--<div id="con_two_2" style="display:none; "> <img src="/education/tpl/simplebootx/Public/images/lz.jpg" width="5" height="19" align="top"/> <a href="<?php echo leuu('Portal/list/index',array('id'=>3));?>">校园新闻</a> <a href="<?php echo leuu('Portal/list/index',array('id'=>4));?>">师生心得</a> <a href="<?php echo leuu('Portal/list/index',array('id'=>11));?>">育婴知识</a> <a href="<?php echo leuu('Portal/list/index',array('id'=>6));?>">最新活动</a> <img src="/education/tpl/simplebootx/Public/images/rz.jpg" width="5" height="19" align="top"/> </div>-->
          <div id="con_two_3" style="display:none; "></div>
          <!--<div id="con_two_4" style="display:none; "> <img src="/education/tpl/simplebootx/Public/images/lz.jpg" width="5" height="19" align="top"/> <a href="<?php echo leuu('Portal/page/index',array('id'=>1));?>">课程介绍</a> <a href="#">课程查询</a> <img src="/education/tpl/simplebootx/Public/images/rz.jpg" width="5" height="19" align="top"/> </div>-->
          <!--<div id="con_two_5" style="display:none; "> <img src="/education/tpl/simplebootx/Public/images/lz.jpg" width="5" height="19" align="top"/> <a href="<?php echo leuu('Portal/page/index',array('id'=>2));?>">学校介绍</a> <a href="<?php echo leuu('Portal/page/index',array('id'=>3));?>">校长寄语</a> <a href="<?php echo leuu('Portal/teacher/index');?>">教师介绍</a> <a href="<?php echo leuu('Portal/student/index');?>">学员风采</a> <a href="">教授证书的展示</a> <img src="/education/tpl/simplebootx/Public/images/rz.jpg" width="5" height="19" align="top"/> </div>-->
          <!--<div id="con_two_6" style="display:none; "> <img src="/education/tpl/simplebootx/Public/images/lz.jpg" width="5" height="19" align="top"/> <a href="">教师VCR推荐</a> <a href="">学员VCR推荐</a> <img src="/education/tpl/simplebootx/Public/images/rz.jpg" width="5" height="19" align="top"/> </div>-->
          <div id="con_two_7" style="display:none; "></div></td>
      </tr>
    </table>
  </div>
</div>

<div class="banner1"><img src="/education/tpl/simplebootx/Public/images/banner1.jpg" width="1002" height="246" /></div>
<div class="main1">
  <div class="m_l">
    <div class="m_lt"><img src="/education/tpl/simplebootx/Public/images/left_t.jpg" width="213" height="32" /></div>
    <div class="m_lz">
      <div class="m_lz1"><a href="<?php echo leuu('Portal/teacher/index');?>"></a></div>
    </div>
    <div class="m_lz">
      <div class="m_lz2"><a href="<?php echo leuu('Portal/page/index',array('id'=>10));?>"></a></div>
    </div>
    <div class="m_lz">
      <div class="m_lz3"><a href="<?php echo leuu('Portal/page/index',array('id'=>4));?>"></a></div>
    </div>
    <!--<div class="m_lb"> <a href="join.html"></a></div>-->
    <!--<div class="tu1"><a href="about.html?id=37"><img src="/education/tpl/simplebootx/Public/images/tu1.jpg" width="213" height="142" border="0" /></a></div>-->
  </div>
  <div class="m_r">
    <div class="m_r1">
      <div class="m_rt"><img src="/education/tpl/simplebootx/Public/images/right_t.jpg" width="771" height="38" /></div>
      <div class="m_rz">
        <div class="m_rz1"> <span><font color="#333">首页</font>&nbsp;>&nbsp;<?php echo ($post_title); ?></span><?php echo ($post_title); ?></div>
        <div class="xymap" style="min-height:300px; ">
        <style type="text/css">
.createUser td {
	padding-left: 2%;
	height: 30px;
}
.createUser td.label {
	width: 15%;
}
.createUser td.input {
	width: 81%;
}
/*!
 * Bootstrap v2.2.2
 *
 * Copyright 2012 Twitter, Inc
 * Licensed under the Apache License v2.0
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Designed and built with all the love in the world @twitter by @mdo and @fat.
 */


textarea, input[type="text"], input[type="password"], input[type="datetime"], input[type="datetime-local"], input[type="date"], input[type="month"], input[type="time"], input[type="week"], input[type="number"], input[type="email"], input[type="url"], input[type="search"], input[type="tel"], input[type="color"], .uneditable-input {
	background-color: #ffffff;
	border: 1px solid #cccccc;
	-webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
	-moz-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
	box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
	-webkit-transition: border linear 0.2s, box-shadow linear 0.2s;
	-moz-transition: border linear 0.2s, box-shadow linear 0.2s;
	-o-transition: border linear 0.2s, box-shadow linear 0.2s;
	transition: border linear 0.2s, box-shadow linear 0.2s;
}
textarea:focus, input[type="text"]:focus, input[type="password"]:focus, input[type="datetime"]:focus, input[type="datetime-local"]:focus, input[type="date"]:focus, input[type="month"]:focus, input[type="time"]:focus, input[type="week"]:focus, input[type="number"]:focus, input[type="email"]:focus, input[type="url"]:focus, input[type="search"]:focus, input[type="tel"]:focus, input[type="color"]:focus, .uneditable-input:focus {
	border-color: rgba(82, 168, 236, 0.8);
	outline: 0;
	outline: thin dotted \9;
	/* IE6-9 */

	-webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(82, 168, 236, 0.6);
	-moz-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(82, 168, 236, 0.6);
	box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(82, 168, 236, 0.6);
}
input[type="radio"], input[type="checkbox"] {
	margin: 4px 0 0;
	margin-top: 1px \9;
 *margin-top: 0;
	line-height: normal;
}
input[type="file"], input[type="image"], input[type="submit"], input[type="reset"], input[type="button"], input[type="radio"], input[type="checkbox"] {
	width: auto;
}
select, input[type="file"] {
	height: 30px;
  /* In IE7, the height of the select element cannot be changed by height, only font-size */

  *margin-top: 4px;
	/* For IE7, add top margin to align select with labels */

	line-height: 30px;
}
select {
	width: 220px;
	background-color: #ffffff;
	border: 1px solid #cccccc;
}
select[multiple], select[size] {
	height: auto;
}
select:focus, input[type="file"]:focus, input[type="radio"]:focus, input[type="checkbox"]:focus {
	outline: thin dotted #333;
	outline: 5px auto -webkit-focus-ring-color;
	outline-offset: -2px;
}
.uneditable-input, .uneditable-textarea {
	color: #999999;
	cursor: not-allowed;
	background-color: #fcfcfc;
	border-color: #cccccc;
	-webkit-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.025);
	-moz-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.025);
	box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.025);
}
.uneditable-input {
	overflow: hidden;
	white-space: nowrap;
}
.uneditable-textarea {
	width: auto;
	height: auto;
}
 input:-moz-placeholder, textarea:-moz-placeholder {
 color: #999999;
}
 input:-ms-input-placeholder, textarea:-ms-input-placeholder {
 color: #999999;
}
 input::-webkit-input-placeholder, textarea::-webkit-input-placeholder {
 color: #999999;
}
.radio, .checkbox {
	min-height: 20px;
	padding-left: 20px;
}
.radio input[type="radio"], .checkbox input[type="checkbox"] {
	float: left;
	margin-left: -20px;
}
.controls > .radio:first-child, .controls > .checkbox:first-child {
	padding-top: 5px;
}
.radio.inline, .checkbox.inline {
	display: inline-block;
	padding-top: 5px;
	margin-bottom: 0;
	vertical-align: middle;
}
.radio.inline + .radio.inline, .checkbox.inline + .checkbox.inline {
	margin-left: 10px;
}
.input-mini {
	width: 60px;
}
.input-small {
	width: 90px;
}
.input-medium {
	width: 150px;
}
.input-large {
	width: 210px;
}
.input-xlarge {
	width: 270px;
}
.input-xxlarge {
	width: 530px;
}
input[class*="span"], select[class*="span"], textarea[class*="span"], .uneditable-input[class*="span"], .row-fluid input[class*="span"], .row-fluid select[class*="span"], .row-fluid textarea[class*="span"], .row-fluid .uneditable-input[class*="span"] {
	float: none;
	margin-left: 0;
}
.input-append input[class*="span"], .input-append .uneditable-input[class*="span"], .input-prepend input[class*="span"], .input-prepend .uneditable-input[class*="span"], .row-fluid input[class*="span"], .row-fluid select[class*="span"], .row-fluid textarea[class*="span"], .row-fluid .uneditable-input[class*="span"], .row-fluid .input-prepend [class*="span"], .row-fluid .input-append [class*="span"] {
	display: inline-block;
}
input, textarea, .uneditable-input {
	margin-left: 0;
}
 .controls-row [class*="span"] + [class*="span"] {
 margin-left: 20px;
}
input.span12, textarea.span12, .uneditable-input.span12 {
	width: 926px;
}
input.span11, textarea.span11, .uneditable-input.span11 {
	width: 846px;
}
input.span10, textarea.span10, .uneditable-input.span10 {
	width: 766px;
}
input.span9, textarea.span9, .uneditable-input.span9 {
	width: 686px;
}
input.span8, textarea.span8, .uneditable-input.span8 {
	width: 606px;
}
input.span7, textarea.span7, .uneditable-input.span7 {
	width: 526px;
}
input.span6, textarea.span6, .uneditable-input.span6 {
	width: 446px;
}
input.span5, textarea.span5, .uneditable-input.span5 {
	width: 366px;
}
input.span4, textarea.span4, .uneditable-input.span4 {
	width: 286px;
}
input.span3, textarea.span3, .uneditable-input.span3 {
	width: 206px;
}
input.span2, textarea.span2, .uneditable-input.span2 {
	width: 126px;
}
input.span1, textarea.span1, .uneditable-input.span1 {
	width: 46px;
}
.controls-row {
 *zoom: 1;
}
.controls-row:before, .controls-row:after {
	display: table;
	line-height: 0;
	content: "";
}
.controls-row:after {
	clear: both;
}
.controls-row [class*="span"], .row-fluid .controls-row [class*="span"] {
	float: left;
}
.controls-row .checkbox[class*="span"], .controls-row .radio[class*="span"] {
	padding-top: 5px;
}
input[disabled], select[disabled], textarea[disabled], input[readonly], select[readonly], textarea[readonly] {
	cursor: not-allowed;
	background-color: #eeeeee;
}
input[type="radio"][disabled], input[type="checkbox"][disabled], input[type="radio"][readonly], input[type="checkbox"][readonly] {
	background-color: transparent;
}
.control-group.warning .control-label, .control-group.warning .help-block, .control-group.warning .help-inline {
	color: #c09853;
}
.control-group.warning .checkbox, .control-group.warning .radio, .control-group.warning input, .control-group.warning select, .control-group.warning textarea {
	color: #c09853;
}
.control-group.warning input, .control-group.warning select, .control-group.warning textarea {
	border-color: #c09853;
	-webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
	-moz-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
	box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
}
.control-group.warning input:focus, .control-group.warning select:focus, .control-group.warning textarea:focus {
	border-color: #a47e3c;
	-webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #dbc59e;
	-moz-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #dbc59e;
	box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #dbc59e;
}
.control-group.warning .input-prepend .add-on, .control-group.warning .input-append .add-on {
	color: #c09853;
	background-color: #fcf8e3;
	border-color: #c09853;
}
.control-group.error .control-label, .control-group.error .help-block, .control-group.error .help-inline {
	color: #b94a48;
}
.control-group.error .checkbox, .control-group.error .radio, .control-group.error input, .control-group.error select, .control-group.error textarea {
	color: #b94a48;
}
.control-group.error input, .control-group.error select, .control-group.error textarea {
	border-color: #b94a48;
	-webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
	-moz-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
	box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
}
.control-group.error input:focus, .control-group.error select:focus, .control-group.error textarea:focus {
	border-color: #953b39;
	-webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #d59392;
	-moz-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #d59392;
	box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #d59392;
}
.control-group.error .input-prepend .add-on, .control-group.error .input-append .add-on {
	color: #b94a48;
	background-color: #f2dede;
	border-color: #b94a48;
}
.control-group.success .control-label, .control-group.success .help-block, .control-group.success .help-inline {
	color: #468847;
}
.control-group.success .checkbox, .control-group.success .radio, .control-group.success input, .control-group.success select, .control-group.success textarea {
	color: #468847;
}
.control-group.success input, .control-group.success select, .control-group.success textarea {
	border-color: #468847;
	-webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
	-moz-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
	box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
}
.control-group.success input:focus, .control-group.success select:focus, .control-group.success textarea:focus {
	border-color: #356635;
	-webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #7aba7b;
	-moz-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #7aba7b;
	box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #7aba7b;
}
.control-group.success .input-prepend .add-on, .control-group.success .input-append .add-on {
	color: #468847;
	background-color: #dff0d8;
	border-color: #468847;
}
.control-group.info .control-label, .control-group.info .help-block, .control-group.info .help-inline {
	color: #3a87ad;
}
.control-group.info .checkbox, .control-group.info .radio, .control-group.info input, .control-group.info select, .control-group.info textarea {
	color: #3a87ad;
}
.control-group.info input, .control-group.info select, .control-group.info textarea {
	border-color: #3a87ad;
	-webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
	-moz-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
	box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
}
.control-group.info input:focus, .control-group.info select:focus, .control-group.info textarea:focus {
	border-color: #2d6987;
	-webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #7ab5d3;
	-moz-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #7ab5d3;
	box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #7ab5d3;
}
.control-group.info .input-prepend .add-on, .control-group.info .input-append .add-on {
	color: #3a87ad;
	background-color: #d9edf7;
	border-color: #3a87ad;
}
 input:focus:invalid, textarea:focus:invalid, select:focus:invalid {
 color: #b94a48;
 border-color: #ee5f5b;
}
 input:focus:invalid:focus, textarea:focus:invalid:focus, select:focus:invalid:focus {
 border-color: #e9322d;
 -webkit-box-shadow: 0 0 6px #f8b9b7;
 -moz-box-shadow: 0 0 6px #f8b9b7;
 box-shadow: 0 0 6px #f8b9b7;
}
.form-actions {
	padding: 19px 20px 20px;
	margin-top: 20px;
	margin-bottom: 20px;
	background-color: #f5f5f5;
	border-top: 1px solid #e5e5e5;
 *zoom: 1;
}
.form-actions:before, .form-actions:after {
	display: table;
	line-height: 0;
	content: "";
}
.form-actions:after {
	clear: both;
}
.help-block, .help-inline {
	color: #595959;
}
.help-block {
	display: block;
	margin-bottom: 10px;
}
.help-inline {
	display: inline-block;
 *display: inline;
	padding-left: 5px;
	vertical-align: middle;
 *zoom: 1;
}
.input-append, .input-prepend {
	margin-bottom: 5px;
	font-size: 0;
	white-space: nowrap;
}
.input-append input, .input-prepend input, .input-append select, .input-prepend select, .input-append .uneditable-input, .input-prepend .uneditable-input, .input-append .dropdown-menu, .input-prepend .dropdown-menu {
	font-size: 14px;
}
.input-append input, .input-prepend input, .input-append select, .input-prepend select, .input-append .uneditable-input, .input-prepend .uneditable-input {
	position: relative;
	margin-bottom: 0;
 *margin-left: 0;
	vertical-align: top;
	-webkit-border-radius: 0 4px 4px 0;
	-moz-border-radius: 0 4px 4px 0;
	border-radius: 0 4px 4px 0;
}
.input-append input:focus, .input-prepend input:focus, .input-append select:focus, .input-prepend select:focus, .input-append .uneditable-input:focus, .input-prepend .uneditable-input:focus {
	z-index: 2;
}
.input-append .add-on, .input-prepend .add-on {
	display: inline-block;
	width: auto;
	height: 20px;
	min-width: 16px;
	padding: 4px 5px;
	font-size: 14px;
	font-weight: normal;
	line-height: 20px;
	text-align: center;
	text-shadow: 0 1px 0 #ffffff;
	background-color: #eeeeee;
	border: 1px solid #ccc;
}
.input-append .add-on, .input-prepend .add-on, .input-append .btn, .input-prepend .btn, .input-append .btn-group > .dropdown-toggle, .input-prepend .btn-group > .dropdown-toggle {
	vertical-align: top;
	-webkit-border-radius: 0;
	-moz-border-radius: 0;
	border-radius: 0;
}
.input-append .active, .input-prepend .active {
	background-color: #a9dba9;
	border-color: #46a546;
}
.input-prepend .add-on, .input-prepend .btn {
	margin-right: -1px;
}
.input-prepend .add-on:first-child, .input-prepend .btn:first-child {
	-webkit-border-radius: 4px 0 0 4px;
	-moz-border-radius: 4px 0 0 4px;
	border-radius: 4px 0 0 4px;
}
.input-append input, .input-append select, .input-append .uneditable-input {
	-webkit-border-radius: 4px 0 0 4px;
	-moz-border-radius: 4px 0 0 4px;
	border-radius: 4px 0 0 4px;
}
.input-append input + .btn-group .btn:last-child, .input-append select + .btn-group .btn:last-child, .input-append .uneditable-input + .btn-group .btn:last-child {
	-webkit-border-radius: 0 4px 4px 0;
	-moz-border-radius: 0 4px 4px 0;
	border-radius: 0 4px 4px 0;
}
.input-append .add-on, .input-append .btn, .input-append .btn-group {
	margin-left: -1px;
}
.input-append .add-on:last-child, .input-append .btn:last-child, .input-append .btn-group:last-child > .dropdown-toggle {
	-webkit-border-radius: 0 4px 4px 0;
	-moz-border-radius: 0 4px 4px 0;
	border-radius: 0 4px 4px 0;
}
.input-prepend.input-append input, .input-prepend.input-append select, .input-prepend.input-append .uneditable-input {
	-webkit-border-radius: 0;
	-moz-border-radius: 0;
	border-radius: 0;
}
.input-prepend.input-append input + .btn-group .btn, .input-prepend.input-append select + .btn-group .btn, .input-prepend.input-append .uneditable-input + .btn-group .btn {
	-webkit-border-radius: 0 4px 4px 0;
	-moz-border-radius: 0 4px 4px 0;
	border-radius: 0 4px 4px 0;
}
.input-prepend.input-append .add-on:first-child, .input-prepend.input-append .btn:first-child {
	margin-right: -1px;
	-webkit-border-radius: 4px 0 0 4px;
	-moz-border-radius: 4px 0 0 4px;
	border-radius: 4px 0 0 4px;
}
.input-prepend.input-append .add-on:last-child, .input-prepend.input-append .btn:last-child {
	margin-left: -1px;
	-webkit-border-radius: 0 4px 4px 0;
	-moz-border-radius: 0 4px 4px 0;
	border-radius: 0 4px 4px 0;
}
.input-prepend.input-append .btn-group:first-child {
	margin-left: 0;
}
input.search-query {
	padding-right: 14px;
	padding-right: 4px \9;
	padding-left: 14px;
	padding-left: 4px \9;
	/* IE7-8 doesn't have border-radius, so don't indent the padding */

	margin-bottom: 0;
	-webkit-border-radius: 15px;
	-moz-border-radius: 15px;
	border-radius: 15px;
}
/* Allow for input prepend/append in search forms */

.form-search .input-append .search-query, .form-search .input-prepend .search-query {
	-webkit-border-radius: 0;
	-moz-border-radius: 0;
	border-radius: 0;
}
.form-search .input-append .search-query {
	-webkit-border-radius: 14px 0 0 14px;
	-moz-border-radius: 14px 0 0 14px;
	border-radius: 14px 0 0 14px;
}
.form-search .input-append .btn {
	-webkit-border-radius: 0 14px 14px 0;
	-moz-border-radius: 0 14px 14px 0;
	border-radius: 0 14px 14px 0;
}
.form-search .input-prepend .search-query {
	-webkit-border-radius: 0 14px 14px 0;
	-moz-border-radius: 0 14px 14px 0;
	border-radius: 0 14px 14px 0;
}
.form-search .input-prepend .btn {
	-webkit-border-radius: 14px 0 0 14px;
	-moz-border-radius: 14px 0 0 14px;
	border-radius: 14px 0 0 14px;
}
.form-search input, .form-inline input, .form-horizontal input, .form-search textarea, .form-inline textarea, .form-horizontal textarea, .form-search select, .form-inline select, .form-horizontal select, .form-search .help-inline, .form-inline .help-inline, .form-horizontal .help-inline, .form-search .uneditable-input, .form-inline .uneditable-input, .form-horizontal .uneditable-input, .form-search .input-prepend, .form-inline .input-prepend, .form-horizontal .input-prepend, .form-search .input-append, .form-inline .input-append, .form-horizontal .input-append {
	display: inline-block;
 *display: inline;
	margin-bottom: 0;
	vertical-align: middle;
 *zoom: 1;
}
.form-search .hide, .form-inline .hide, .form-horizontal .hide {
	display: none;
}
.form-search label, .form-inline label, .form-search .btn-group, .form-inline .btn-group {
	display: inline-block;
}
.form-search .input-append, .form-inline .input-append, .form-search .input-prepend, .form-inline .input-prepend {
	margin-bottom: 0;
}
.form-search .radio, .form-search .checkbox, .form-inline .radio, .form-inline .checkbox {
	padding-left: 0;
	margin-bottom: 0;
	vertical-align: middle;
}
.form-search .radio input[type="radio"], .form-search .checkbox input[type="checkbox"], .form-inline .radio input[type="radio"], .form-inline .checkbox input[type="checkbox"] {
	float: left;
	margin-right: 3px;
	margin-left: 0;
}
.control-group {
	margin-bottom: 10px;
}
legend + .control-group {
	margin-top: 20px;
	-webkit-margin-top-collapse: separate;
}
.form-horizontal .control-group {
	margin-bottom: 20px;
 *zoom: 1;
}
.form-horizontal .control-group:before, .form-horizontal .control-group:after {
	display: table;
	line-height: 0;
	content: "";
}
.form-horizontal .control-group:after {
	clear: both;
}
.form-horizontal .control-label {
	float: left;
	width: 160px;
	padding-top: 5px;
	text-align: right;
}
.form-horizontal .controls {
 *display: inline-block;
 *padding-left: 20px;
	margin-left: 180px;
 *margin-left: 0;
}
.form-horizontal .controls:first-child {
 *padding-left: 180px;
}
.form-horizontal .help-block {
	margin-bottom: 0;
}
.form-horizontal input + .help-block, .form-horizontal select + .help-block, .form-horizontal textarea + .help-block, .form-horizontal .uneditable-input + .help-block, .form-horizontal .input-prepend + .help-block, .form-horizontal .input-append + .help-block {
	margin-top: 10px;
}
.form-horizontal .form-actions {
	padding-left: 180px;
}
table {
	max-width: 100%;
	background-color: transparent;
	border-collapse: collapse;
	border-spacing: 0;
}
.table {
	width: 100%;
	margin-bottom: 20px;
}
.table th, .table td {
	padding: 8px;
	line-height: 20px;
	text-align: left;
	vertical-align: top;
	border-top: 1px solid #dddddd;
}
.table th {
	font-weight: bold;
}
.table thead th {
	vertical-align: bottom;
}
.table caption + thead tr:first-child th, .table caption + thead tr:first-child td, .table colgroup + thead tr:first-child th, .table colgroup + thead tr:first-child td, .table thead:first-child tr:first-child th, .table thead:first-child tr:first-child td {
	border-top: 0;
}
.table tbody + tbody {
	border-top: 2px solid #dddddd;
}
.table .table {
	background-color: #ffffff;
}
.table-condensed th, .table-condensed td {
	padding: 4px 5px;
}
.table-bordered {
	border: 1px solid #dddddd;
	border-collapse: separate;
 *border-collapse: collapse;
	border-left: 0;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border-radius: 4px;
}
.table-bordered th, .table-bordered td {
	border-left: 1px solid #dddddd;
}
.table-bordered caption + thead tr:first-child th, .table-bordered caption + tbody tr:first-child th, .table-bordered caption + tbody tr:first-child td, .table-bordered colgroup + thead tr:first-child th, .table-bordered colgroup + tbody tr:first-child th, .table-bordered colgroup + tbody tr:first-child td, .table-bordered thead:first-child tr:first-child th, .table-bordered tbody:first-child tr:first-child th, .table-bordered tbody:first-child tr:first-child td {
	border-top: 0;
}
.table-bordered thead:first-child tr:first-child > th:first-child, .table-bordered tbody:first-child tr:first-child > td:first-child {
	-webkit-border-top-left-radius: 4px;
	border-top-left-radius: 4px;
	-moz-border-radius-topleft: 4px;
}
.table-bordered thead:first-child tr:first-child > th:last-child, .table-bordered tbody:first-child tr:first-child > td:last-child {
	-webkit-border-top-right-radius: 4px;
	border-top-right-radius: 4px;
	-moz-border-radius-topright: 4px;
}
.table-bordered thead:last-child tr:last-child > th:first-child, .table-bordered tbody:last-child tr:last-child > td:first-child, .table-bordered tfoot:last-child tr:last-child > td:first-child {
	-webkit-border-bottom-left-radius: 4px;
	border-bottom-left-radius: 4px;
	-moz-border-radius-bottomleft: 4px;
}
.table-bordered thead:last-child tr:last-child > th:last-child, .table-bordered tbody:last-child tr:last-child > td:last-child, .table-bordered tfoot:last-child tr:last-child > td:last-child {
	-webkit-border-bottom-right-radius: 4px;
	border-bottom-right-radius: 4px;
	-moz-border-radius-bottomright: 4px;
}
.table-bordered tfoot + tbody:last-child tr:last-child td:first-child {
	-webkit-border-bottom-left-radius: 0;
	border-bottom-left-radius: 0;
	-moz-border-radius-bottomleft: 0;
}
.table-bordered tfoot + tbody:last-child tr:last-child td:last-child {
	-webkit-border-bottom-right-radius: 0;
	border-bottom-right-radius: 0;
	-moz-border-radius-bottomright: 0;
}
.table-bordered caption + thead tr:first-child th:first-child, .table-bordered caption + tbody tr:first-child td:first-child, .table-bordered colgroup + thead tr:first-child th:first-child, .table-bordered colgroup + tbody tr:first-child td:first-child {
	-webkit-border-top-left-radius: 4px;
	border-top-left-radius: 4px;
	-moz-border-radius-topleft: 4px;
}
.table-bordered caption + thead tr:first-child th:last-child, .table-bordered caption + tbody tr:first-child td:last-child, .table-bordered colgroup + thead tr:first-child th:last-child, .table-bordered colgroup + tbody tr:first-child td:last-child {
	-webkit-border-top-right-radius: 4px;
	border-top-right-radius: 4px;
	-moz-border-radius-topright: 4px;
}
.table-striped tbody > tr:nth-child(odd) > td, .table-striped tbody > tr:nth-child(odd) > th {
	background-color: #f9f9f9;
}
.table-hover tbody tr:hover td, .table-hover tbody tr:hover th {
	background-color: #f5f5f5;
}
table td[class*="span"], table th[class*="span"], .row-fluid table td[class*="span"], .row-fluid table th[class*="span"] {
	display: table-cell;
	float: none;
	margin-left: 0;
}
.table td.span1, .table th.span1 {
	float: none;
	width: 44px;
	margin-left: 0;
}
.table td.span2, .table th.span2 {
	float: none;
	width: 124px;
	margin-left: 0;
}
.table td.span3, .table th.span3 {
	float: none;
	width: 204px;
	margin-left: 0;
}
.table td.span4, .table th.span4 {
	float: none;
	width: 284px;
	margin-left: 0;
}
.table td.span5, .table th.span5 {
	float: none;
	width: 364px;
	margin-left: 0;
}
.table td.span6, .table th.span6 {
	float: none;
	width: 444px;
	margin-left: 0;
}
.table td.span7, .table th.span7 {
	float: none;
	width: 524px;
	margin-left: 0;
}
.table td.span8, .table th.span8 {
	float: none;
	width: 604px;
	margin-left: 0;
}
.table td.span9, .table th.span9 {
	float: none;
	width: 684px;
	margin-left: 0;
}
.table td.span10, .table th.span10 {
	float: none;
	width: 764px;
	margin-left: 0;
}
.table td.span11, .table th.span11 {
	float: none;
	width: 844px;
	margin-left: 0;
}
.table td.span12, .table th.span12 {
	float: none;
	width: 924px;
	margin-left: 0;
}
.table tbody tr.success td {
	background-color: #dff0d8;
}
.table tbody tr.error td {
	background-color: #f2dede;
}
.table tbody tr.warning td {
	background-color: #fcf8e3;
}
.table tbody tr.info td {
	background-color: #d9edf7;
}
.table-hover tbody tr.success:hover td {
	background-color: #d0e9c6;
}
.table-hover tbody tr.error:hover td {
	background-color: #ebcccc;
}
.table-hover tbody tr.warning:hover td {
	background-color: #faf2cc;
}
.table-hover tbody tr.info:hover td {
	background-color: #c4e3f3;
}
 [class^="icon-"], [class*=" icon-"] {
 display: inline-block;
 width: 14px;
 height: 14px;
 margin-top: 1px;
 *margin-right: .3em;
 line-height: 14px;
 vertical-align: text-top;
 background-image: url("../img/glyphicons-halflings.png");
 background-position: 14px 14px;
 background-repeat: no-repeat;
}

/* White icons with optional class, or on hover/active states of certain elements */

.icon-white, .nav-pills > .active > a > [class^="icon-"], .nav-pills > .active > a > [class*=" icon-"], .nav-list > .active > a > [class^="icon-"], .nav-list > .active > a > [class*=" icon-"], .navbar-inverse .nav > .active > a > [class^="icon-"], .navbar-inverse .nav > .active > a > [class*=" icon-"], .dropdown-menu > li > a:hover > [class^="icon-"], .dropdown-menu > li > a:hover > [class*=" icon-"], .dropdown-menu > .active > a > [class^="icon-"], .dropdown-menu > .active > a > [class*=" icon-"], .dropdown-submenu:hover > a > [class^="icon-"], .dropdown-submenu:hover > a > [class*=" icon-"] {
 background-image: url("../img/glyphicons-halflings-white.png");
}
.icon-glass {
	background-position: 0 0;
}
.icon-music {
	background-position: -24px 0;
}
.icon-search {
	background-position: -48px 0;
}
.icon-envelope {
	background-position: -72px 0;
}
.icon-heart {
	background-position: -96px 0;
}
.icon-star {
	background-position: -120px 0;
}
.icon-star-empty {
	background-position: -144px 0;
}
.icon-user {
	background-position: -168px 0;
}
.icon-film {
	background-position: -192px 0;
}
.icon-th-large {
	background-position: -216px 0;
}
.icon-th {
	background-position: -240px 0;
}
.icon-th-list {
	background-position: -264px 0;
}
.icon-ok {
	background-position: -288px 0;
}
.icon-remove {
	background-position: -312px 0;
}
.icon-zoom-in {
	background-position: -336px 0;
}
.icon-zoom-out {
	background-position: -360px 0;
}
.icon-off {
	background-position: -384px 0;
}
.icon-signal {
	background-position: -408px 0;
}
.icon-cog {
	background-position: -432px 0;
}
.icon-trash {
	background-position: -456px 0;
}
.icon-home {
	background-position: 0 -24px;
}
.icon-file {
	background-position: -24px -24px;
}
.icon-time {
	background-position: -48px -24px;
}
.icon-road {
	background-position: -72px -24px;
}
.icon-download-alt {
	background-position: -96px -24px;
}
.icon-download {
	background-position: -120px -24px;
}
.icon-upload {
	background-position: -144px -24px;
}
.icon-inbox {
	background-position: -168px -24px;
}
.icon-play-circle {
	background-position: -192px -24px;
}
.icon-repeat {
	background-position: -216px -24px;
}
.icon-refresh {
	background-position: -240px -24px;
}
.icon-list-alt {
	background-position: -264px -24px;
}
.icon-lock {
	background-position: -287px -24px;
}
.icon-flag {
	background-position: -312px -24px;
}
.icon-headphones {
	background-position: -336px -24px;
}
.icon-volume-off {
	background-position: -360px -24px;
}
.icon-volume-down {
	background-position: -384px -24px;
}
.icon-volume-up {
	background-position: -408px -24px;
}
.icon-qrcode {
	background-position: -432px -24px;
}
.icon-barcode {
	background-position: -456px -24px;
}
.icon-tag {
	background-position: 0 -48px;
}
.icon-tags {
	background-position: -25px -48px;
}
.icon-book {
	background-position: -48px -48px;
}
.icon-bookmark {
	background-position: -72px -48px;
}
.icon-print {
	background-position: -96px -48px;
}
.icon-camera {
	background-position: -120px -48px;
}
.icon-font {
	background-position: -144px -48px;
}
.icon-bold {
	background-position: -167px -48px;
}
.icon-italic {
	background-position: -192px -48px;
}
.icon-text-height {
	background-position: -216px -48px;
}
.icon-text-width {
	background-position: -240px -48px;
}
.icon-align-left {
	background-position: -264px -48px;
}
.icon-align-center {
	background-position: -288px -48px;
}
.icon-align-right {
	background-position: -312px -48px;
}
.icon-align-justify {
	background-position: -336px -48px;
}
.icon-list {
	background-position: -360px -48px;
}
.icon-indent-left {
	background-position: -384px -48px;
}
.icon-indent-right {
	background-position: -408px -48px;
}
.icon-facetime-video {
	background-position: -432px -48px;
}
.icon-picture {
	background-position: -456px -48px;
}
.icon-pencil {
	background-position: 0 -72px;
}
.icon-map-marker {
	background-position: -24px -72px;
}
.icon-adjust {
	background-position: -48px -72px;
}
.icon-tint {
	background-position: -72px -72px;
}
.icon-edit {
	background-position: -96px -72px;
}
.icon-share {
	background-position: -120px -72px;
}
.icon-check {
	background-position: -144px -72px;
}
.icon-move {
	background-position: -168px -72px;
}
.icon-step-backward {
	background-position: -192px -72px;
}
.icon-fast-backward {
	background-position: -216px -72px;
}
.icon-backward {
	background-position: -240px -72px;
}
.icon-play {
	background-position: -264px -72px;
}
.icon-pause {
	background-position: -288px -72px;
}
.icon-stop {
	background-position: -312px -72px;
}
.icon-forward {
	background-position: -336px -72px;
}
.icon-fast-forward {
	background-position: -360px -72px;
}
.icon-step-forward {
	background-position: -384px -72px;
}
.icon-eject {
	background-position: -408px -72px;
}
.icon-chevron-left {
	background-position: -432px -72px;
}
.icon-chevron-right {
	background-position: -456px -72px;
}
.icon-plus-sign {
	background-position: 0 -96px;
}
.icon-minus-sign {
	background-position: -24px -96px;
}
.icon-remove-sign {
	background-position: -48px -96px;
}
.icon-ok-sign {
	background-position: -72px -96px;
}
.icon-question-sign {
	background-position: -96px -96px;
}
.icon-info-sign {
	background-position: -120px -96px;
}
.icon-screenshot {
	background-position: -144px -96px;
}
.icon-remove-circle {
	background-position: -168px -96px;
}
.icon-ok-circle {
	background-position: -192px -96px;
}
.icon-ban-circle {
	background-position: -216px -96px;
}
.icon-arrow-left {
	background-position: -240px -96px;
}
.icon-arrow-right {
	background-position: -264px -96px;
}
.icon-arrow-up {
	background-position: -289px -96px;
}
.icon-arrow-down {
	background-position: -312px -96px;
}
.icon-share-alt {
	background-position: -336px -96px;
}
.icon-resize-full {
	background-position: -360px -96px;
}
.icon-resize-small {
	background-position: -384px -96px;
}
.icon-plus {
	background-position: -408px -96px;
}
.icon-minus {
	background-position: -433px -96px;
}
.icon-asterisk {
	background-position: -456px -96px;
}
.icon-exclamation-sign {
	background-position: 0 -120px;
}
.icon-gift {
	background-position: -24px -120px;
}
.icon-leaf {
	background-position: -48px -120px;
}
.icon-fire {
	background-position: -72px -120px;
}
.icon-eye-open {
	background-position: -96px -120px;
}
.icon-eye-close {
	background-position: -120px -120px;
}
.icon-warning-sign {
	background-position: -144px -120px;
}
.icon-plane {
	background-position: -168px -120px;
}
.icon-calendar {
	background-position: -192px -120px;
}
.icon-random {
	width: 16px;
	background-position: -216px -120px;
}
.icon-comment {
	background-position: -240px -120px;
}
.icon-magnet {
	background-position: -264px -120px;
}
.icon-chevron-up {
	background-position: -288px -120px;
}
.icon-chevron-down {
	background-position: -313px -119px;
}
.icon-retweet {
	background-position: -336px -120px;
}
.icon-shopping-cart {
	background-position: -360px -120px;
}
.icon-folder-close {
	background-position: -384px -120px;
}
.icon-folder-open {
	width: 16px;
	background-position: -408px -120px;
}
.icon-resize-vertical {
	background-position: -432px -119px;
}
.icon-resize-horizontal {
	background-position: -456px -118px;
}
.icon-hdd {
	background-position: 0 -144px;
}
.icon-bullhorn {
	background-position: -24px -144px;
}
.icon-bell {
	background-position: -48px -144px;
}
.icon-certificate {
	background-position: -72px -144px;
}
.icon-thumbs-up {
	background-position: -96px -144px;
}
.icon-thumbs-down {
	background-position: -120px -144px;
}
.icon-hand-right {
	background-position: -144px -144px;
}
.icon-hand-left {
	background-position: -168px -144px;
}
.icon-hand-up {
	background-position: -192px -144px;
}
.icon-hand-down {
	background-position: -216px -144px;
}
.icon-circle-arrow-right {
	background-position: -240px -144px;
}
.icon-circle-arrow-left {
	background-position: -264px -144px;
}
.icon-circle-arrow-up {
	background-position: -288px -144px;
}
.icon-circle-arrow-down {
	background-position: -312px -144px;
}
.icon-globe {
	background-position: -336px -144px;
}
.icon-wrench {
	background-position: -360px -144px;
}
.icon-tasks {
	background-position: -384px -144px;
}
.icon-filter {
	background-position: -408px -144px;
}
.icon-briefcase {
	background-position: -432px -144px;
}
.icon-fullscreen {
	background-position: -456px -144px;
}
.dropup, .dropdown {
	position: relative;
}
.dropdown-toggle {
 *margin-bottom: -3px;
}
.dropdown-toggle:active, .open .dropdown-toggle {
	outline: 0;
}
.caret {
	display: inline-block;
	width: 0;
	height: 0;
	vertical-align: top;
	border-top: 4px solid #000000;
	border-right: 4px solid transparent;
	border-left: 4px solid transparent;
	content: "";
}
.dropdown .caret {
	margin-top: 8px;
	margin-left: 2px;
}
.dropdown-menu {
	position: absolute;
	top: 100%;
	left: 0;
	z-index: 1000;
	display: none;
	float: left;
	min-width: 160px;
	padding: 5px 0;
	margin: 2px 0 0;
	list-style: none;
	background-color: #ffffff;
	border: 1px solid #ccc;
	border: 1px solid rgba(0, 0, 0, 0.2);
 *border-right-width: 2px;
 *border-bottom-width: 2px;
	-webkit-border-radius: 6px;
	-moz-border-radius: 6px;
	border-radius: 6px;
	-webkit-box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
	-moz-box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
	box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
	-webkit-background-clip: padding-box;
	-moz-background-clip: padding;
	background-clip: padding-box;
}
.dropdown-menu.pull-right {
	right: 0;
	left: auto;
}
.dropdown-menu .divider {
 *width: 100%;
	height: 1px;
	margin: 9px 1px;
 *margin: -5px 0 5px;
	overflow: hidden;
	background-color: #e5e5e5;
	border-bottom: 1px solid #ffffff;
}
.dropdown-menu li > a {
	display: block;
	padding: 3px 20px;
	clear: both;
	font-weight: normal;
	line-height: 20px;
	color: #333333;
	white-space: nowrap;
}
.dropdown-menu li > a:hover, .dropdown-menu li > a:focus, .dropdown-submenu:hover > a {
	color: #ffffff;
	text-decoration: none;
	background-color: #0081c2;
	background-image: -moz-linear-gradient(top, #0088cc, #0077b3);
	background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#0088cc), to(#0077b3));
	background-image: -webkit-linear-gradient(top, #0088cc, #0077b3);
	background-image: -o-linear-gradient(top, #0088cc, #0077b3);
	background-image: linear-gradient(to bottom, #0088cc, #0077b3);
	background-repeat: repeat-x;
 filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff0088cc', endColorstr='#ff0077b3', GradientType=0);
}
.dropdown-menu .active > a, .dropdown-menu .active > a:hover {
	color: #ffffff;
	text-decoration: none;
	background-color: #0081c2;
	background-image: -moz-linear-gradient(top, #0088cc, #0077b3);
	background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#0088cc), to(#0077b3));
	background-image: -webkit-linear-gradient(top, #0088cc, #0077b3);
	background-image: -o-linear-gradient(top, #0088cc, #0077b3);
	background-image: linear-gradient(to bottom, #0088cc, #0077b3);
	background-repeat: repeat-x;
	outline: 0;
 filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff0088cc', endColorstr='#ff0077b3', GradientType=0);
}
.dropdown-menu .disabled > a, .dropdown-menu .disabled > a:hover {
	color: #999999;
}
.dropdown-menu .disabled > a:hover {
	text-decoration: none;
	cursor: default;
	background-color: transparent;
	background-image: none;
 filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
}
.open {
 *z-index: 1000;
}
.open > .dropdown-menu {
	display: block;
}
.pull-right > .dropdown-menu {
	right: 0;
	left: auto;
}
.dropup .caret, .navbar-fixed-bottom .dropdown .caret {
	border-top: 0;
	border-bottom: 4px solid #000000;
	content: "";
}
.dropup .dropdown-menu, .navbar-fixed-bottom .dropdown .dropdown-menu {
	top: auto;
	bottom: 100%;
	margin-bottom: 1px;
}
.dropdown-submenu {
	position: relative;
}
.dropdown-submenu > .dropdown-menu {
	top: 0;
	left: 100%;
	margin-top: -6px;
	margin-left: -1px;
	-webkit-border-radius: 0 6px 6px 6px;
	-moz-border-radius: 0 6px 6px 6px;
	border-radius: 0 6px 6px 6px;
}
.dropdown-submenu:hover > .dropdown-menu {
	display: block;
}
.dropup .dropdown-submenu > .dropdown-menu {
	top: auto;
	bottom: 0;
	margin-top: 0;
	margin-bottom: -2px;
	-webkit-border-radius: 5px 5px 5px 0;
	-moz-border-radius: 5px 5px 5px 0;
	border-radius: 5px 5px 5px 0;
}
.dropdown-submenu > a:after {
	display: block;
	float: right;
	width: 0;
	height: 0;
	margin-top: 5px;
	margin-right: -10px;
	border-color: transparent;
	border-left-color: #cccccc;
	border-style: solid;
	border-width: 5px 0 5px 5px;
	content: " ";
}
.dropdown-submenu:hover > a:after {
	border-left-color: #ffffff;
}
.dropdown-submenu.pull-left {
	float: none;
}
.dropdown-submenu.pull-left > .dropdown-menu {
	left: -100%;
	margin-left: 10px;
	-webkit-border-radius: 6px 0 6px 6px;
	-moz-border-radius: 6px 0 6px 6px;
	border-radius: 6px 0 6px 6px;
}
.dropdown .dropdown-menu .nav-header {
	padding-right: 20px;
	padding-left: 20px;
}
.typeahead {
	z-index: 1051;
	margin-top: 2px;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border-radius: 4px;
}
.well {
	min-height: 20px;
	padding: 19px;
	margin-bottom: 20px;
	background-color: #f5f5f5;
	border: 1px solid #e3e3e3;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border-radius: 4px;
	-webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.05);
	-moz-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.05);
	box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.05);
}
.well blockquote {
	border-color: #ddd;
	border-color: rgba(0, 0, 0, 0.15);
}
.well-large {
	padding: 24px;
	-webkit-border-radius: 6px;
	-moz-border-radius: 6px;
	border-radius: 6px;
}
.well-small {
	padding: 9px;
	-webkit-border-radius: 3px;
	-moz-border-radius: 3px;
	border-radius: 3px;
}
.fade {
	opacity: 0;
	-webkit-transition: opacity 0.15s linear;
	-moz-transition: opacity 0.15s linear;
	-o-transition: opacity 0.15s linear;
	transition: opacity 0.15s linear;
}
.fade.in {
	opacity: 1;
}
.collapse {
	position: relative;
	height: 0;
	overflow: hidden;
	-webkit-transition: height 0.35s ease;
	-moz-transition: height 0.35s ease;
	-o-transition: height 0.35s ease;
	transition: height 0.35s ease;
}
.collapse.in {
	height: auto;
}
.close {
	float: right;
	font-size: 20px;
	font-weight: bold;
	line-height: 20px;
	color: #000000;
	text-shadow: 0 1px 0 #ffffff;
	opacity: 0.2;
	filter: alpha(opacity=20);
}
.close:hover {
	color: #000000;
	text-decoration: none;
	cursor: pointer;
	opacity: 0.4;
	filter: alpha(opacity=40);
}
button.close {
	padding: 0;
	cursor: pointer;
	background: transparent;
	border: 0;
	-webkit-appearance: none;
}
.btn {
	display: inline-block;
 *display: inline;
	padding: 4px 12px;
	margin-bottom: 0;
 *margin-left: .3em;
	font-size: 14px;
	line-height: 20px;
	color: #333333;
	text-align: center;
	text-shadow: 0 1px 1px rgba(255, 255, 255, 0.75);
	vertical-align: middle;
	cursor: pointer;
	background-color: #f5f5f5;
 *background-color: #e6e6e6;
	background-image: -moz-linear-gradient(top, #ffffff, #e6e6e6);
	background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#ffffff), to(#e6e6e6));
	background-image: -webkit-linear-gradient(top, #ffffff, #e6e6e6);
	background-image: -o-linear-gradient(top, #ffffff, #e6e6e6);
	background-image: linear-gradient(to bottom, #ffffff, #e6e6e6);
	background-repeat: repeat-x;
	border: 1px solid #bbbbbb;
 *border: 0;
	border-color: #e6e6e6 #e6e6e6 #bfbfbf;
	border-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25);
	border-bottom-color: #a2a2a2;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border-radius: 4px;
 filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff', endColorstr='#ffe6e6e6', GradientType=0);
 filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
 *zoom: 1;
	-webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.05);
	-moz-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.05);
	box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.05);
}
.btn:hover, .btn:active, .btn.active, .btn.disabled, .btn[disabled] {
	color: #333333;
	background-color: #e6e6e6;
 *background-color: #d9d9d9;
}
.btn:active, .btn.active {
	background-color: #cccccc \9;
}
.btn:first-child {
 *margin-left: 0;
}
.btn:hover {
	color: #333333;
	text-decoration: none;
	background-position: 0 -15px;
	-webkit-transition: background-position 0.1s linear;
	-moz-transition: background-position 0.1s linear;
	-o-transition: background-position 0.1s linear;
	transition: background-position 0.1s linear;
}
.btn:focus {
	outline: thin dotted #333;
	outline: 5px auto -webkit-focus-ring-color;
	outline-offset: -2px;
}
.btn.active, .btn:active {
	background-image: none;
	outline: 0;
	-webkit-box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.15), 0 1px 2px rgba(0, 0, 0, 0.05);
	-moz-box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.15), 0 1px 2px rgba(0, 0, 0, 0.05);
	box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.15), 0 1px 2px rgba(0, 0, 0, 0.05);
}
.btn.disabled, .btn[disabled] {
	cursor: default;
	background-image: none;
	opacity: 0.65;
	filter: alpha(opacity=65);
	-webkit-box-shadow: none;
	-moz-box-shadow: none;
	box-shadow: none;
}
.btn-large {
	padding: 11px 19px;
	font-size: 17.5px;
	-webkit-border-radius: 6px;
	-moz-border-radius: 6px;
	border-radius: 6px;
}
.btn-large [class^="icon-"], .btn-large [class*=" icon-"] {
	margin-top: 4px;
}
.btn-small {
	padding: 2px 10px;
	font-size: 11.9px;
	-webkit-border-radius: 3px;
	-moz-border-radius: 3px;
	border-radius: 3px;
}
.btn-small [class^="icon-"], .btn-small [class*=" icon-"] {
	margin-top: 0;
}
.btn-mini [class^="icon-"], .btn-mini [class*=" icon-"] {
	margin-top: -1px;
}
.btn-mini {
	padding: 0 6px;
	font-size: 10.5px;
	-webkit-border-radius: 3px;
	-moz-border-radius: 3px;
	border-radius: 3px;
}
.btn-block {
	display: block;
	width: 100%;
	padding-right: 0;
	padding-left: 0;
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	box-sizing: border-box;
}
.btn-block + .btn-block {
	margin-top: 5px;
}
input[type="submit"].btn-block, input[type="reset"].btn-block, input[type="button"].btn-block {
	width: 100%;
}
.btn-primary.active, .btn-warning.active, .btn-danger.active, .btn-success.active, .btn-info.active, .btn-inverse.active {
	color: rgba(255, 255, 255, 0.75);
}
.btn {
	border-color: #c5c5c5;
	border-color: rgba(0, 0, 0, 0.15) rgba(0, 0, 0, 0.15) rgba(0, 0, 0, 0.25);
}
.btn-primary {
	color: #ffffff;
	text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
	background-color: #006dcc;
 *background-color: #0044cc;
	background-image: -moz-linear-gradient(top, #0088cc, #0044cc);
	background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#0088cc), to(#0044cc));
	background-image: -webkit-linear-gradient(top, #0088cc, #0044cc);
	background-image: -o-linear-gradient(top, #0088cc, #0044cc);
	background-image: linear-gradient(to bottom, #0088cc, #0044cc);
	background-repeat: repeat-x;
	border-color: #0044cc #0044cc #002a80;
	border-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25);
 filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff0088cc', endColorstr='#ff0044cc', GradientType=0);
 filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
}
.btn-primary:hover, .btn-primary:active, .btn-primary.active, .btn-primary.disabled, .btn-primary[disabled] {
	color: #ffffff;
	background-color: #0044cc;
 *background-color: #003bb3;
}
.btn-primary:active, .btn-primary.active {
	background-color: #003399 \9;
}
.btn-warning {
	color: #ffffff;
	text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
	background-color: #faa732;
 *background-color: #f89406;
	background-image: -moz-linear-gradient(top, #fbb450, #f89406);
	background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#fbb450), to(#f89406));
	background-image: -webkit-linear-gradient(top, #fbb450, #f89406);
	background-image: -o-linear-gradient(top, #fbb450, #f89406);
	background-image: linear-gradient(to bottom, #fbb450, #f89406);
	background-repeat: repeat-x;
	border-color: #f89406 #f89406 #ad6704;
	border-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25);
 filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#fffbb450', endColorstr='#fff89406', GradientType=0);
 filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
}
.btn-warning:hover, .btn-warning:active, .btn-warning.active, .btn-warning.disabled, .btn-warning[disabled] {
	color: #ffffff;
	background-color: #f89406;
 *background-color: #df8505;
}
.btn-warning:active, .btn-warning.active {
	background-color: #c67605 \9;
}
.btn-danger {
	color: #ffffff;
	text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
	background-color: #da4f49;
 *background-color: #bd362f;
	background-image: -moz-linear-gradient(top, #ee5f5b, #bd362f);
	background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#ee5f5b), to(#bd362f));
	background-image: -webkit-linear-gradient(top, #ee5f5b, #bd362f);
	background-image: -o-linear-gradient(top, #ee5f5b, #bd362f);
	background-image: linear-gradient(to bottom, #ee5f5b, #bd362f);
	background-repeat: repeat-x;
	border-color: #bd362f #bd362f #802420;
	border-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25);
 filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffee5f5b', endColorstr='#ffbd362f', GradientType=0);
 filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
}
.btn-danger:hover, .btn-danger:active, .btn-danger.active, .btn-danger.disabled, .btn-danger[disabled] {
	color: #ffffff;
	background-color: #bd362f;
 *background-color: #a9302a;
}
.btn-danger:active, .btn-danger.active {
	background-color: #942a25 \9;
}
.btn-success {
	color: #ffffff;
	text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
	background-color: #5bb75b;
 *background-color: #51a351;
	background-image: -moz-linear-gradient(top, #62c462, #51a351);
	background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#62c462), to(#51a351));
	background-image: -webkit-linear-gradient(top, #62c462, #51a351);
	background-image: -o-linear-gradient(top, #62c462, #51a351);
	background-image: linear-gradient(to bottom, #62c462, #51a351);
	background-repeat: repeat-x;
	border-color: #51a351 #51a351 #387038;
	border-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25);
 filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff62c462', endColorstr='#ff51a351', GradientType=0);
 filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
}
.btn-success:hover, .btn-success:active, .btn-success.active, .btn-success.disabled, .btn-success[disabled] {
	color: #ffffff;
	background-color: #51a351;
 *background-color: #499249;
}
.btn-success:active, .btn-success.active {
	background-color: #408140 \9;
}
.btn-info {
	color: #ffffff;
	text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
	background-color: #49afcd;
 *background-color: #2f96b4;
	background-image: -moz-linear-gradient(top, #5bc0de, #2f96b4);
	background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#5bc0de), to(#2f96b4));
	background-image: -webkit-linear-gradient(top, #5bc0de, #2f96b4);
	background-image: -o-linear-gradient(top, #5bc0de, #2f96b4);
	background-image: linear-gradient(to bottom, #5bc0de, #2f96b4);
	background-repeat: repeat-x;
	border-color: #2f96b4 #2f96b4 #1f6377;
	border-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25);
 filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff5bc0de', endColorstr='#ff2f96b4', GradientType=0);
 filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
}
.btn-info:hover, .btn-info:active, .btn-info.active, .btn-info.disabled, .btn-info[disabled] {
	color: #ffffff;
	background-color: #2f96b4;
 *background-color: #2a85a0;
}
.btn-info:active, .btn-info.active {
	background-color: #24748c \9;
}
.btn-inverse {
	color: #ffffff;
	text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
	background-color: #363636;
 *background-color: #222222;
	background-image: -moz-linear-gradient(top, #444444, #222222);
	background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#444444), to(#222222));
	background-image: -webkit-linear-gradient(top, #444444, #222222);
	background-image: -o-linear-gradient(top, #444444, #222222);
	background-image: linear-gradient(to bottom, #444444, #222222);
	background-repeat: repeat-x;
	border-color: #222222 #222222 #000000;
	border-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25);
 filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff444444', endColorstr='#ff222222', GradientType=0);
 filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
}
.btn-inverse:hover, .btn-inverse:active, .btn-inverse.active, .btn-inverse.disabled, .btn-inverse[disabled] {
	color: #ffffff;
	background-color: #222222;
 *background-color: #151515;
}
.btn-inverse:active, .btn-inverse.active {
	background-color: #080808 \9;
}
button.btn, input[type="submit"].btn {
 *padding-top: 3px;
 *padding-bottom: 3px;
}
 button.btn::-moz-focus-inner, input[type="submit"].btn::-moz-focus-inner {
 padding: 0;
 border: 0;
}
button.btn.btn-large, input[type="submit"].btn.btn-large {
 *padding-top: 7px;
 *padding-bottom: 7px;
}
button.btn.btn-small, input[type="submit"].btn.btn-small {
 *padding-top: 3px;
 *padding-bottom: 3px;
}
button.btn.btn-mini, input[type="submit"].btn.btn-mini {
 *padding-top: 1px;
 *padding-bottom: 1px;
}
.btn-link, .btn-link:active, .btn-link[disabled] {
	background-color: transparent;
	background-image: none;
	-webkit-box-shadow: none;
	-moz-box-shadow: none;
	box-shadow: none;
}
.btn-link {
	color: #0088cc;
	cursor: pointer;
	border-color: transparent;
	-webkit-border-radius: 0;
	-moz-border-radius: 0;
	border-radius: 0;
}
.btn-link:hover {
	color: #005580;
	text-decoration: underline;
	background-color: transparent;
}
.btn-link[disabled]:hover {
	color: #333333;
	text-decoration: none;
}
.btn-group {
	position: relative;
	display: inline-block;
 *display: inline;
 *margin-left: .3em;
	font-size: 0;
	white-space: nowrap;
	vertical-align: middle;
 *zoom: 1;
}
.btn-group:first-child {
 *margin-left: 0;
}
.btn-group + .btn-group {
	margin-left: 5px;
}
.btn-toolbar {
	margin-top: 10px;
	margin-bottom: 10px;
	font-size: 0;
}
.btn-toolbar > .btn + .btn, .btn-toolbar > .btn-group + .btn, .btn-toolbar > .btn + .btn-group {
	margin-left: 5px;
}
.btn-group > .btn {
	position: relative;
	-webkit-border-radius: 0;
	-moz-border-radius: 0;
	border-radius: 0;
}
.btn-group > .btn + .btn {
	margin-left: -1px;
}
.btn-group > .btn, .btn-group > .dropdown-menu, .btn-group > .popover {
	font-size: 14px;
}
.btn-group > .btn-mini {
	font-size: 10.5px;
}
.btn-group > .btn-small {
	font-size: 11.9px;
}
.btn-group > .btn-large {
	font-size: 17.5px;
}
.btn-group > .btn:first-child {
	margin-left: 0;
	-webkit-border-bottom-left-radius: 4px;
	border-bottom-left-radius: 4px;
	-webkit-border-top-left-radius: 4px;
	border-top-left-radius: 4px;
	-moz-border-radius-bottomleft: 4px;
	-moz-border-radius-topleft: 4px;
}
.btn-group > .btn:last-child, .btn-group > .dropdown-toggle {
	-webkit-border-top-right-radius: 4px;
	border-top-right-radius: 4px;
	-webkit-border-bottom-right-radius: 4px;
	border-bottom-right-radius: 4px;
	-moz-border-radius-topright: 4px;
	-moz-border-radius-bottomright: 4px;
}
.btn-group > .btn.large:first-child {
	margin-left: 0;
	-webkit-border-bottom-left-radius: 6px;
	border-bottom-left-radius: 6px;
	-webkit-border-top-left-radius: 6px;
	border-top-left-radius: 6px;
	-moz-border-radius-bottomleft: 6px;
	-moz-border-radius-topleft: 6px;
}
.btn-group > .btn.large:last-child, .btn-group > .large.dropdown-toggle {
	-webkit-border-top-right-radius: 6px;
	border-top-right-radius: 6px;
	-webkit-border-bottom-right-radius: 6px;
	border-bottom-right-radius: 6px;
	-moz-border-radius-topright: 6px;
	-moz-border-radius-bottomright: 6px;
}
.btn-group > .btn:hover, .btn-group > .btn:focus, .btn-group > .btn:active, .btn-group > .btn.active {
	z-index: 2;
}
.btn-group .dropdown-toggle:active, .btn-group.open .dropdown-toggle {
	outline: 0;
}
.btn-group > .btn + .dropdown-toggle {
 *padding-top: 5px;
	padding-right: 8px;
 *padding-bottom: 5px;
	padding-left: 8px;
	-webkit-box-shadow: inset 1px 0 0 rgba(255, 255, 255, 0.125), inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.05);
	-moz-box-shadow: inset 1px 0 0 rgba(255, 255, 255, 0.125), inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.05);
	box-shadow: inset 1px 0 0 rgba(255, 255, 255, 0.125), inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.05);
}
.btn-group > .btn-mini + .dropdown-toggle {
 *padding-top: 2px;
	padding-right: 5px;
 *padding-bottom: 2px;
	padding-left: 5px;
}
.btn-group > .btn-small + .dropdown-toggle {
 *padding-top: 5px;
 *padding-bottom: 4px;
}
.btn-group > .btn-large + .dropdown-toggle {
 *padding-top: 7px;
	padding-right: 12px;
 *padding-bottom: 7px;
	padding-left: 12px;
}
.btn-group.open .dropdown-toggle {
	background-image: none;
	-webkit-box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.15), 0 1px 2px rgba(0, 0, 0, 0.05);
	-moz-box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.15), 0 1px 2px rgba(0, 0, 0, 0.05);
	box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.15), 0 1px 2px rgba(0, 0, 0, 0.05);
}
.btn-group.open .btn.dropdown-toggle {
	background-color: #e6e6e6;
}
.btn-group.open .btn-primary.dropdown-toggle {
	background-color: #0044cc;
}
.btn-group.open .btn-warning.dropdown-toggle {
	background-color: #f89406;
}
.btn-group.open .btn-danger.dropdown-toggle {
	background-color: #bd362f;
}
.btn-group.open .btn-success.dropdown-toggle {
	background-color: #51a351;
}
.btn-group.open .btn-info.dropdown-toggle {
	background-color: #2f96b4;
}
.btn-group.open .btn-inverse.dropdown-toggle {
	background-color: #222222;
}
.btn .caret {
	margin-top: 8px;
	margin-left: 0;
}
.btn-mini .caret, .btn-small .caret, .btn-large .caret {
	margin-top: 6px;
}
.btn-large .caret {
	border-top-width: 5px;
	border-right-width: 5px;
	border-left-width: 5px;
}
.dropup .btn-large .caret {
	border-bottom-width: 5px;
}
.btn-primary .caret, .btn-warning .caret, .btn-danger .caret, .btn-info .caret, .btn-success .caret, .btn-inverse .caret {
	border-top-color: #ffffff;
	border-bottom-color: #ffffff;
}
.btn-group-vertical {
	display: inline-block;
 *display: inline;
  /* IE7 inline-block hack */

  *zoom: 1;
}
.btn-group-vertical > .btn {
	display: block;
	float: none;
	max-width: 100%;
	-webkit-border-radius: 0;
	-moz-border-radius: 0;
	border-radius: 0;
}
.btn-group-vertical > .btn + .btn {
	margin-top: -1px;
	margin-left: 0;
}
.btn-group-vertical > .btn:first-child {
	-webkit-border-radius: 4px 4px 0 0;
	-moz-border-radius: 4px 4px 0 0;
	border-radius: 4px 4px 0 0;
}
.btn-group-vertical > .btn:last-child {
	-webkit-border-radius: 0 0 4px 4px;
	-moz-border-radius: 0 0 4px 4px;
	border-radius: 0 0 4px 4px;
}
.btn-group-vertical > .btn-large:first-child {
	-webkit-border-radius: 6px 6px 0 0;
	-moz-border-radius: 6px 6px 0 0;
	border-radius: 6px 6px 0 0;
}
.btn-group-vertical > .btn-large:last-child {
	-webkit-border-radius: 0 0 6px 6px;
	-moz-border-radius: 0 0 6px 6px;
	border-radius: 0 0 6px 6px;
}
.alert {
	padding: 8px 35px 8px 14px;
	margin-bottom: 20px;
	text-shadow: 0 1px 0 rgba(255, 255, 255, 0.5);
	background-color: #fcf8e3;
	border: 1px solid #fbeed5;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border-radius: 4px;
}
.alert, .alert h4 {
	color: #c09853;
}
.alert h4 {
	margin: 0;
}
.alert .close {
	position: relative;
	top: -2px;
	right: -21px;
	line-height: 20px;
}
.alert-success {
	color: #468847;
	background-color: #dff0d8;
	border-color: #d6e9c6;
}
.alert-success h4 {
	color: #468847;
}
.alert-danger, .alert-error {
	color: #b94a48;
	background-color: #f2dede;
	border-color: #eed3d7;
}
.alert-danger h4, .alert-error h4 {
	color: #b94a48;
}
.alert-info {
	color: #3a87ad;
	background-color: #d9edf7;
	border-color: #bce8f1;
}
.alert-info h4 {
	color: #3a87ad;
}
.alert-block {
	padding-top: 14px;
	padding-bottom: 14px;
}
.alert-block > p, .alert-block > ul {
	margin-bottom: 0;
}
.alert-block p + p {
	margin-top: 5px;
}
.nav {
	margin-bottom: 20px;
	margin-left: 0;
	list-style: none;
}
.nav > li > a {
	display: block;
}
.nav > li > a:hover {
	text-decoration: none;
	background-color: #eeeeee;
}
.nav > li > a > img {
	max-width: none;
}
.nav > .pull-right {
	float: right;
}
.nav-header {
	display: block;
	padding: 3px 15px;
	font-size: 11px;
	font-weight: bold;
	line-height: 20px;
	color: #999999;
	text-shadow: 0 1px 0 rgba(255, 255, 255, 0.5);
	text-transform: uppercase;
}
.nav li + .nav-header {
	margin-top: 9px;
}
.nav-list {
	padding-right: 15px;
	padding-left: 15px;
	margin-bottom: 0;
}
.nav-list > li > a, .nav-list .nav-header {
	margin-right: -15px;
	margin-left: -15px;
	text-shadow: 0 1px 0 rgba(255, 255, 255, 0.5);
}
.nav-list > li > a {
	padding: 3px 15px;
}
.nav-list > .active > a, .nav-list > .active > a:hover {
	color: #ffffff;
	text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.2);
	background-color: #0088cc;
}
.nav-list [class^="icon-"], .nav-list [class*=" icon-"] {
	margin-right: 2px;
}
.nav-list .divider {
 *width: 100%;
	height: 1px;
	margin: 9px 1px;
 *margin: -5px 0 5px;
	overflow: hidden;
	background-color: #e5e5e5;
	border-bottom: 1px solid #ffffff;
}
.nav-tabs, .nav-pills {
 *zoom: 1;
}
.nav-tabs:before, .nav-pills:before, .nav-tabs:after, .nav-pills:after {
	display: table;
	line-height: 0;
	content: "";
}
.nav-tabs:after, .nav-pills:after {
	clear: both;
}
.nav-tabs > li, .nav-pills > li {
	float: left;
}
.nav-tabs > li > a, .nav-pills > li > a {
	padding-right: 12px;
	padding-left: 12px;
	margin-right: 2px;
	line-height: 14px;
}
.nav-tabs {
	border-bottom: 1px solid #ddd;
}
.nav-tabs > li {
	margin-bottom: -1px;
}
.nav-tabs > li > a {
	padding-top: 8px;
	padding-bottom: 8px;
	line-height: 20px;
	border: 1px solid transparent;
	-webkit-border-radius: 4px 4px 0 0;
	-moz-border-radius: 4px 4px 0 0;
	border-radius: 4px 4px 0 0;
}
.nav-tabs > li > a:hover {
	border-color: #eeeeee #eeeeee #dddddd;
}
.nav-tabs > .active > a, .nav-tabs > .active > a:hover {
	color: #555555;
	cursor: default;
	background-color: #ffffff;
	border: 1px solid #ddd;
	border-bottom-color: transparent;
}
.nav-pills > li > a {
	padding-top: 8px;
	padding-bottom: 8px;
	margin-top: 2px;
	margin-bottom: 2px;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	border-radius: 5px;
}
.nav-pills > .active > a, .nav-pills > .active > a:hover {
	color: #ffffff;
	background-color: #0088cc;
}
.nav-stacked > li {
	float: none;
}
.nav-stacked > li > a {
	margin-right: 0;
}
.nav-tabs.nav-stacked {
	border-bottom: 0;
}
.nav-tabs.nav-stacked > li > a {
	border: 1px solid #ddd;
	-webkit-border-radius: 0;
	-moz-border-radius: 0;
	border-radius: 0;
}
.nav-tabs.nav-stacked > li:first-child > a {
	-webkit-border-top-right-radius: 4px;
	border-top-right-radius: 4px;
	-webkit-border-top-left-radius: 4px;
	border-top-left-radius: 4px;
	-moz-border-radius-topright: 4px;
	-moz-border-radius-topleft: 4px;
}
.nav-tabs.nav-stacked > li:last-child > a {
	-webkit-border-bottom-right-radius: 4px;
	border-bottom-right-radius: 4px;
	-webkit-border-bottom-left-radius: 4px;
	border-bottom-left-radius: 4px;
	-moz-border-radius-bottomright: 4px;
	-moz-border-radius-bottomleft: 4px;
}
.nav-tabs.nav-stacked > li > a:hover {
	z-index: 2;
	border-color: #ddd;
}
.nav-pills.nav-stacked > li > a {
	margin-bottom: 3px;
}
.nav-pills.nav-stacked > li:last-child > a {
	margin-bottom: 1px;
}
.nav-tabs .dropdown-menu {
	-webkit-border-radius: 0 0 6px 6px;
	-moz-border-radius: 0 0 6px 6px;
	border-radius: 0 0 6px 6px;
}
.nav-pills .dropdown-menu {
	-webkit-border-radius: 6px;
	-moz-border-radius: 6px;
	border-radius: 6px;
}
.nav .dropdown-toggle .caret {
	margin-top: 6px;
	border-top-color: #0088cc;
	border-bottom-color: #0088cc;
}
.nav .dropdown-toggle:hover .caret {
	border-top-color: #005580;
	border-bottom-color: #005580;
}
/* move down carets for tabs */

.nav-tabs .dropdown-toggle .caret {
	margin-top: 8px;
}
.nav .active .dropdown-toggle .caret {
	border-top-color: #fff;
	border-bottom-color: #fff;
}
.nav-tabs .active .dropdown-toggle .caret {
	border-top-color: #555555;
	border-bottom-color: #555555;
}
.nav > .dropdown.active > a:hover {
	cursor: pointer;
}
.nav-tabs .open .dropdown-toggle, .nav-pills .open .dropdown-toggle, .nav > li.dropdown.open.active > a:hover {
	color: #ffffff;
	background-color: #999999;
	border-color: #999999;
}
.nav li.dropdown.open .caret, .nav li.dropdown.open.active .caret, .nav li.dropdown.open a:hover .caret {
	border-top-color: #ffffff;
	border-bottom-color: #ffffff;
	opacity: 1;
	filter: alpha(opacity=100);
}
.tabs-stacked .open > a:hover {
	border-color: #999999;
}
.tabbable {
 *zoom: 1;
}
.tabbable:before, .tabbable:after {
	display: table;
	line-height: 0;
	content: "";
}
.tabbable:after {
	clear: both;
}
.tab-content {
	overflow: auto;
}
.tabs-below > .nav-tabs, .tabs-right > .nav-tabs, .tabs-left > .nav-tabs {
	border-bottom: 0;
}
.tab-content > .tab-pane, .pill-content > .pill-pane {
	display: none;
}
.tab-content > .active, .pill-content > .active {
	display: block;
}
.tabs-below > .nav-tabs {
	border-top: 1px solid #ddd;
}
.tabs-below > .nav-tabs > li {
	margin-top: -1px;
	margin-bottom: 0;
}
.tabs-below > .nav-tabs > li > a {
	-webkit-border-radius: 0 0 4px 4px;
	-moz-border-radius: 0 0 4px 4px;
	border-radius: 0 0 4px 4px;
}
.tabs-below > .nav-tabs > li > a:hover {
	border-top-color: #ddd;
	border-bottom-color: transparent;
}
.tabs-below > .nav-tabs > .active > a, .tabs-below > .nav-tabs > .active > a:hover {
	border-color: transparent #ddd #ddd #ddd;
}
.tabs-left > .nav-tabs > li, .tabs-right > .nav-tabs > li {
	float: none;
}
.tabs-left > .nav-tabs > li > a, .tabs-right > .nav-tabs > li > a {
	min-width: 74px;
	margin-right: 0;
	margin-bottom: 3px;
}
.tabs-left > .nav-tabs {
	float: left;
	margin-right: 19px;
	border-right: 1px solid #ddd;
}
.tabs-left > .nav-tabs > li > a {
	margin-right: -1px;
	-webkit-border-radius: 4px 0 0 4px;
	-moz-border-radius: 4px 0 0 4px;
	border-radius: 4px 0 0 4px;
}
.tabs-left > .nav-tabs > li > a:hover {
	border-color: #eeeeee #dddddd #eeeeee #eeeeee;
}
.tabs-left > .nav-tabs .active > a, .tabs-left > .nav-tabs .active > a:hover {
	border-color: #ddd transparent #ddd #ddd;
 *border-right-color: #ffffff;
}
.tabs-right > .nav-tabs {
	float: right;
	margin-left: 19px;
	border-left: 1px solid #ddd;
}
.tabs-right > .nav-tabs > li > a {
	margin-left: -1px;
	-webkit-border-radius: 0 4px 4px 0;
	-moz-border-radius: 0 4px 4px 0;
	border-radius: 0 4px 4px 0;
}
.tabs-right > .nav-tabs > li > a:hover {
	border-color: #eeeeee #eeeeee #eeeeee #dddddd;
}
.tabs-right > .nav-tabs .active > a, .tabs-right > .nav-tabs .active > a:hover {
	border-color: #ddd #ddd #ddd transparent;
 *border-left-color: #ffffff;
}
.nav > .disabled > a {
	color: #999999;
}
.nav > .disabled > a:hover {
	text-decoration: none;
	cursor: default;
	background-color: transparent;
}
.navbar {
 *position: relative;
 *z-index: 2;
	margin-bottom: 20px;
	overflow: visible;
}
.navbar-inner {
	min-height: 40px;
	padding-right: 20px;
	padding-left: 20px;
	background-color: #fafafa;
	background-image: -moz-linear-gradient(top, #ffffff, #f2f2f2);
	background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#ffffff), to(#f2f2f2));
	background-image: -webkit-linear-gradient(top, #ffffff, #f2f2f2);
	background-image: -o-linear-gradient(top, #ffffff, #f2f2f2);
	background-image: linear-gradient(to bottom, #ffffff, #f2f2f2);
	background-repeat: repeat-x;
	border: 1px solid #d4d4d4;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border-radius: 4px;
 filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff', endColorstr='#fff2f2f2', GradientType=0);
 *zoom: 1;
	-webkit-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.065);
	-moz-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.065);
	box-shadow: 0 1px 4px rgba(0, 0, 0, 0.065);
}
.navbar-inner:before, .navbar-inner:after {
	display: table;
	line-height: 0;
	content: "";
}
.navbar-inner:after {
	clear: both;
}
.navbar .container {
	width: auto;
}
.nav-collapse.collapse {
	height: auto;
	overflow: visible;
}
.navbar .brand {
	display: block;
	float: left;
	padding: 10px 20px 10px;
	margin-left: -20px;
	font-size: 20px;
	font-weight: 200;
	color: #777777;
	text-shadow: 0 1px 0 #ffffff;
}
.navbar .brand:hover {
	text-decoration: none;
}
.navbar-text {
	margin-bottom: 0;
	line-height: 40px;
	color: #777777;
}
.navbar-link {
	color: #777777;
}
.navbar-link:hover {
	color: #333333;
}
.navbar .divider-vertical {
	height: 40px;
	margin: 0 9px;
	border-right: 1px solid #ffffff;
	border-left: 1px solid #f2f2f2;
}
.navbar .btn, .navbar .btn-group {
	margin-top: 5px;
}
.navbar .btn-group .btn, .navbar .input-prepend .btn, .navbar .input-append .btn {
	margin-top: 0;
}
.navbar-form {
	margin-bottom: 0;
 *zoom: 1;
}
.navbar-form:before, .navbar-form:after {
	display: table;
	line-height: 0;
	content: "";
}
.navbar-form:after {
	clear: both;
}
.navbar-form input, .navbar-form select, .navbar-form .radio, .navbar-form .checkbox {
	margin-top: 5px;
}
.navbar-form input, .navbar-form select, .navbar-form .btn {
	display: inline-block;
	margin-bottom: 0;
}
.navbar-form input[type="image"], .navbar-form input[type="checkbox"], .navbar-form input[type="radio"] {
	margin-top: 3px;
}
.navbar-form .input-append, .navbar-form .input-prepend {
	margin-top: 5px;
	white-space: nowrap;
}
.navbar-form .input-append input, .navbar-form .input-prepend input {
	margin-top: 0;
}
.navbar-search {
	position: relative;
	float: left;
	margin-top: 5px;
	margin-bottom: 0;
}
.navbar-search .search-query {
	padding: 4px 14px;
	margin-bottom: 0;
	font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
	font-size: 13px;
	font-weight: normal;
	line-height: 1;
	-webkit-border-radius: 15px;
	-moz-border-radius: 15px;
	border-radius: 15px;
}
.navbar-static-top {
	position: static;
	margin-bottom: 0;
}
.navbar-static-top .navbar-inner {
	-webkit-border-radius: 0;
	-moz-border-radius: 0;
	border-radius: 0;
}
.navbar-fixed-top, .navbar-fixed-bottom {
	position: fixed;
	right: 0;
	left: 0;
	z-index: 1030;
	margin-bottom: 0;
}
.navbar-fixed-top .navbar-inner, .navbar-static-top .navbar-inner {
	border-width: 0 0 1px;
}
.navbar-fixed-bottom .navbar-inner {
	border-width: 1px 0 0;
}
.navbar-fixed-top .navbar-inner, .navbar-fixed-bottom .navbar-inner {
	padding-right: 0;
	padding-left: 0;
	-webkit-border-radius: 0;
	-moz-border-radius: 0;
	border-radius: 0;
}
.navbar-static-top .container, .navbar-fixed-top .container, .navbar-fixed-bottom .container {
	width: 940px;
}
.navbar-fixed-top {
	top: 0;
}
.navbar-fixed-top .navbar-inner, .navbar-static-top .navbar-inner {
	-webkit-box-shadow: 0 1px 10px rgba(0, 0, 0, 0.1);
	-moz-box-shadow: 0 1px 10px rgba(0, 0, 0, 0.1);
	box-shadow: 0 1px 10px rgba(0, 0, 0, 0.1);
}
.navbar-fixed-bottom {
	bottom: 0;
}
.navbar-fixed-bottom .navbar-inner {
	-webkit-box-shadow: 0 -1px 10px rgba(0, 0, 0, 0.1);
	-moz-box-shadow: 0 -1px 10px rgba(0, 0, 0, 0.1);
	box-shadow: 0 -1px 10px rgba(0, 0, 0, 0.1);
}
.navbar .nav {
	position: relative;
	left: 0;
	display: block;
	float: left;
	margin: 0 10px 0 0;
}
.navbar .nav.pull-right {
	float: right;
	margin-right: 0;
}
.navbar .nav > li {
	float: left;
}
.navbar .nav > li > a {
	float: none;
	padding: 10px 15px 10px;
	color: #777777;
	text-decoration: none;
	text-shadow: 0 1px 0 #ffffff;
}
.navbar .nav .dropdown-toggle .caret {
	margin-top: 8px;
}
.navbar .nav > li > a:focus, .navbar .nav > li > a:hover {
	color: #333333;
	text-decoration: none;
	background-color: transparent;
}
.navbar .nav > .active > a, .navbar .nav > .active > a:hover, .navbar .nav > .active > a:focus {
	color: #555555;
	text-decoration: none;
	background-color: #e5e5e5;
	-webkit-box-shadow: inset 0 3px 8px rgba(0, 0, 0, 0.125);
	-moz-box-shadow: inset 0 3px 8px rgba(0, 0, 0, 0.125);
	box-shadow: inset 0 3px 8px rgba(0, 0, 0, 0.125);
}
.navbar .btn-navbar {
	display: none;
	float: right;
	padding: 7px 10px;
	margin-right: 5px;
	margin-left: 5px;
	color: #ffffff;
	text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
	background-color: #ededed;
 *background-color: #e5e5e5;
	background-image: -moz-linear-gradient(top, #f2f2f2, #e5e5e5);
	background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#f2f2f2), to(#e5e5e5));
	background-image: -webkit-linear-gradient(top, #f2f2f2, #e5e5e5);
	background-image: -o-linear-gradient(top, #f2f2f2, #e5e5e5);
	background-image: linear-gradient(to bottom, #f2f2f2, #e5e5e5);
	background-repeat: repeat-x;
	border-color: #e5e5e5 #e5e5e5 #bfbfbf;
	border-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25);
 filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff2f2f2', endColorstr='#ffe5e5e5', GradientType=0);
 filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
	-webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1), 0 1px 0 rgba(255, 255, 255, 0.075);
	-moz-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1), 0 1px 0 rgba(255, 255, 255, 0.075);
	box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1), 0 1px 0 rgba(255, 255, 255, 0.075);
}
.navbar .btn-navbar:hover, .navbar .btn-navbar:active, .navbar .btn-navbar.active, .navbar .btn-navbar.disabled, .navbar .btn-navbar[disabled] {
	color: #ffffff;
	background-color: #e5e5e5;
 *background-color: #d9d9d9;
}
.navbar .btn-navbar:active, .navbar .btn-navbar.active {
	background-color: #cccccc \9;
}
.navbar .btn-navbar .icon-bar {
	display: block;
	width: 18px;
	height: 2px;
	background-color: #f5f5f5;
	-webkit-border-radius: 1px;
	-moz-border-radius: 1px;
	border-radius: 1px;
	-webkit-box-shadow: 0 1px 0 rgba(0, 0, 0, 0.25);
	-moz-box-shadow: 0 1px 0 rgba(0, 0, 0, 0.25);
	box-shadow: 0 1px 0 rgba(0, 0, 0, 0.25);
}
.btn-navbar .icon-bar + .icon-bar {
	margin-top: 3px;
}
.navbar .nav > li > .dropdown-menu:before {
	position: absolute;
	top: -7px;
	left: 9px;
	display: inline-block;
	border-right: 7px solid transparent;
	border-bottom: 7px solid #ccc;
	border-left: 7px solid transparent;
	border-bottom-color: rgba(0, 0, 0, 0.2);
	content: '';
}
.navbar .nav > li > .dropdown-menu:after {
	position: absolute;
	top: -6px;
	left: 10px;
	display: inline-block;
	border-right: 6px solid transparent;
	border-bottom: 6px solid #ffffff;
	border-left: 6px solid transparent;
	content: '';
}
.navbar-fixed-bottom .nav > li > .dropdown-menu:before {
	top: auto;
	bottom: -7px;
	border-top: 7px solid #ccc;
	border-bottom: 0;
	border-top-color: rgba(0, 0, 0, 0.2);
}
.navbar-fixed-bottom .nav > li > .dropdown-menu:after {
	top: auto;
	bottom: -6px;
	border-top: 6px solid #ffffff;
	border-bottom: 0;
}
.navbar .nav li.dropdown > a:hover .caret {
	border-top-color: #555555;
	border-bottom-color: #555555;
}
.navbar .nav li.dropdown.open > .dropdown-toggle, .navbar .nav li.dropdown.active > .dropdown-toggle, .navbar .nav li.dropdown.open.active > .dropdown-toggle {
	color: #555555;
	background-color: #e5e5e5;
}
.navbar .nav li.dropdown > .dropdown-toggle .caret {
	border-top-color: #777777;
	border-bottom-color: #777777;
}
.navbar .nav li.dropdown.open > .dropdown-toggle .caret, .navbar .nav li.dropdown.active > .dropdown-toggle .caret, .navbar .nav li.dropdown.open.active > .dropdown-toggle .caret {
	border-top-color: #555555;
	border-bottom-color: #555555;
}
.navbar .pull-right > li > .dropdown-menu, .navbar .nav > li > .dropdown-menu.pull-right {
	right: 0;
	left: auto;
}
.navbar .pull-right > li > .dropdown-menu:before, .navbar .nav > li > .dropdown-menu.pull-right:before {
	right: 12px;
	left: auto;
}
.navbar .pull-right > li > .dropdown-menu:after, .navbar .nav > li > .dropdown-menu.pull-right:after {
	right: 13px;
	left: auto;
}
.navbar .pull-right > li > .dropdown-menu .dropdown-menu, .navbar .nav > li > .dropdown-menu.pull-right .dropdown-menu {
	right: 100%;
	left: auto;
	margin-right: -1px;
	margin-left: 0;
	-webkit-border-radius: 6px 0 6px 6px;
	-moz-border-radius: 6px 0 6px 6px;
	border-radius: 6px 0 6px 6px;
}
.navbar-inverse .navbar-inner {
	background-color: #1b1b1b;
	background-image: -moz-linear-gradient(top, #222222, #111111);
	background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#222222), to(#111111));
	background-image: -webkit-linear-gradient(top, #222222, #111111);
	background-image: -o-linear-gradient(top, #222222, #111111);
	background-image: linear-gradient(to bottom, #222222, #111111);
	background-repeat: repeat-x;
	border-color: #252525;
 filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff222222', endColorstr='#ff111111', GradientType=0);
}
.navbar-inverse .brand, .navbar-inverse .nav > li > a {
	color: #999999;
	text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
}
.navbar-inverse .brand:hover, .navbar-inverse .nav > li > a:hover {
	color: #ffffff;
}
.navbar-inverse .brand {
	color: #999999;
}
.navbar-inverse .navbar-text {
	color: #999999;
}
.navbar-inverse .nav > li > a:focus, .navbar-inverse .nav > li > a:hover {
	color: #ffffff;
	background-color: transparent;
}
.navbar-inverse .nav .active > a, .navbar-inverse .nav .active > a:hover, .navbar-inverse .nav .active > a:focus {
	color: #ffffff;
	background-color: #111111;
}
.navbar-inverse .navbar-link {
	color: #999999;
}
.navbar-inverse .navbar-link:hover {
	color: #ffffff;
}
.navbar-inverse .divider-vertical {
	border-right-color: #222222;
	border-left-color: #111111;
}
.navbar-inverse .nav li.dropdown.open > .dropdown-toggle, .navbar-inverse .nav li.dropdown.active > .dropdown-toggle, .navbar-inverse .nav li.dropdown.open.active > .dropdown-toggle {
	color: #ffffff;
	background-color: #111111;
}
.navbar-inverse .nav li.dropdown > a:hover .caret {
	border-top-color: #ffffff;
	border-bottom-color: #ffffff;
}
.navbar-inverse .nav li.dropdown > .dropdown-toggle .caret {
	border-top-color: #999999;
	border-bottom-color: #999999;
}
.navbar-inverse .nav li.dropdown.open > .dropdown-toggle .caret, .navbar-inverse .nav li.dropdown.active > .dropdown-toggle .caret, .navbar-inverse .nav li.dropdown.open.active > .dropdown-toggle .caret {
	border-top-color: #ffffff;
	border-bottom-color: #ffffff;
}
.navbar-inverse .navbar-search .search-query {
	color: #ffffff;
	background-color: #515151;
	border-color: #111111;
	-webkit-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1), 0 1px 0 rgba(255, 255, 255, 0.15);
	-moz-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1), 0 1px 0 rgba(255, 255, 255, 0.15);
	box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1), 0 1px 0 rgba(255, 255, 255, 0.15);
	-webkit-transition: none;
	-moz-transition: none;
	-o-transition: none;
	transition: none;
}
 .navbar-inverse .navbar-search .search-query:-moz-placeholder {
 color: #cccccc;
}
 .navbar-inverse .navbar-search .search-query:-ms-input-placeholder {
 color: #cccccc;
}
 .navbar-inverse .navbar-search .search-query::-webkit-input-placeholder {
 color: #cccccc;
}
.navbar-inverse .navbar-search .search-query:focus, .navbar-inverse .navbar-search .search-query.focused {
	padding: 5px 15px;
	color: #333333;
	text-shadow: 0 1px 0 #ffffff;
	background-color: #ffffff;
	border: 0;
	outline: 0;
	-webkit-box-shadow: 0 0 3px rgba(0, 0, 0, 0.15);
	-moz-box-shadow: 0 0 3px rgba(0, 0, 0, 0.15);
	box-shadow: 0 0 3px rgba(0, 0, 0, 0.15);
}
.navbar-inverse .btn-navbar {
	color: #ffffff;
	text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
	background-color: #0e0e0e;
 *background-color: #040404;
	background-image: -moz-linear-gradient(top, #151515, #040404);
	background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#151515), to(#040404));
	background-image: -webkit-linear-gradient(top, #151515, #040404);
	background-image: -o-linear-gradient(top, #151515, #040404);
	background-image: linear-gradient(to bottom, #151515, #040404);
	background-repeat: repeat-x;
	border-color: #040404 #040404 #000000;
	border-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25);
 filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff151515', endColorstr='#ff040404', GradientType=0);
 filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
}
.navbar-inverse .btn-navbar:hover, .navbar-inverse .btn-navbar:active, .navbar-inverse .btn-navbar.active, .navbar-inverse .btn-navbar.disabled, .navbar-inverse .btn-navbar[disabled] {
	color: #ffffff;
	background-color: #040404;
 *background-color: #000000;
}
.navbar-inverse .btn-navbar:active, .navbar-inverse .btn-navbar.active {
	background-color: #000000 \9;
}
.breadcrumb {
	padding: 8px 15px;
	margin: 0 0 20px;
	list-style: none;
	background-color: #f5f5f5;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border-radius: 4px;
}
.breadcrumb > li {
	display: inline-block;
 *display: inline;
	text-shadow: 0 1px 0 #ffffff;
 *zoom: 1;
}
.breadcrumb > li > .divider {
	padding: 0 5px;
	color: #ccc;
}
.breadcrumb > .active {
	color: #999999;
}
.pagination {
	margin: 20px 0;
}
.pagination ul {
	display: inline-block;
 *display: inline;
	margin-bottom: 0;
	margin-left: 0;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border-radius: 4px;
 *zoom: 1;
	-webkit-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
	-moz-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
	box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
}
.pagination ul > li {
	display: inline;
}
.pagination ul > li > a, .pagination ul > li > span {
	float: left;
	padding: 4px 12px;
	line-height: 20px;
	text-decoration: none;
	background-color: #ffffff;
	border: 1px solid #dddddd;
	border-left-width: 0;
}
.pagination ul > li > a:hover, .pagination ul > .active > a, .pagination ul > .active > span {
	background-color: #f5f5f5;
}
.pagination ul > .active > a, .pagination ul > .active > span {
	color: #999999;
	cursor: default;
}
.pagination ul > .disabled > span, .pagination ul > .disabled > a, .pagination ul > .disabled > a:hover {
	color: #999999;
	cursor: default;
	background-color: transparent;
}
.pagination ul > li:first-child > a, .pagination ul > li:first-child > span {
	border-left-width: 1px;
	-webkit-border-bottom-left-radius: 4px;
	border-bottom-left-radius: 4px;
	-webkit-border-top-left-radius: 4px;
	border-top-left-radius: 4px;
	-moz-border-radius-bottomleft: 4px;
	-moz-border-radius-topleft: 4px;
}
.pagination ul > li:last-child > a, .pagination ul > li:last-child > span {
	-webkit-border-top-right-radius: 4px;
	border-top-right-radius: 4px;
	-webkit-border-bottom-right-radius: 4px;
	border-bottom-right-radius: 4px;
	-moz-border-radius-topright: 4px;
	-moz-border-radius-bottomright: 4px;
}
.pagination-centered {
	text-align: center;
}
.pagination-right {
	text-align: right;
}
.pagination-large ul > li > a, .pagination-large ul > li > span {
	padding: 11px 19px;
	font-size: 17.5px;
}
.pagination-large ul > li:first-child > a, .pagination-large ul > li:first-child > span {
	-webkit-border-bottom-left-radius: 6px;
	border-bottom-left-radius: 6px;
	-webkit-border-top-left-radius: 6px;
	border-top-left-radius: 6px;
	-moz-border-radius-bottomleft: 6px;
	-moz-border-radius-topleft: 6px;
}
.pagination-large ul > li:last-child > a, .pagination-large ul > li:last-child > span {
	-webkit-border-top-right-radius: 6px;
	border-top-right-radius: 6px;
	-webkit-border-bottom-right-radius: 6px;
	border-bottom-right-radius: 6px;
	-moz-border-radius-topright: 6px;
	-moz-border-radius-bottomright: 6px;
}
.pagination-mini ul > li:first-child > a, .pagination-small ul > li:first-child > a, .pagination-mini ul > li:first-child > span, .pagination-small ul > li:first-child > span {
	-webkit-border-bottom-left-radius: 3px;
	border-bottom-left-radius: 3px;
	-webkit-border-top-left-radius: 3px;
	border-top-left-radius: 3px;
	-moz-border-radius-bottomleft: 3px;
	-moz-border-radius-topleft: 3px;
}
.pagination-mini ul > li:last-child > a, .pagination-small ul > li:last-child > a, .pagination-mini ul > li:last-child > span, .pagination-small ul > li:last-child > span {
	-webkit-border-top-right-radius: 3px;
	border-top-right-radius: 3px;
	-webkit-border-bottom-right-radius: 3px;
	border-bottom-right-radius: 3px;
	-moz-border-radius-topright: 3px;
	-moz-border-radius-bottomright: 3px;
}
.pagination-small ul > li > a, .pagination-small ul > li > span {
	padding: 2px 10px;
	font-size: 11.9px;
}
.pagination-mini ul > li > a, .pagination-mini ul > li > span {
	padding: 0 6px;
	font-size: 10.5px;
}
.pager {
	margin: 20px 0;
	text-align: center;
	list-style: none;
 *zoom: 1;
}
.pager:before, .pager:after {
	display: table;
	line-height: 0;
	content: "";
}
.pager:after {
	clear: both;
}
.pager li {
	display: inline;
}
.pager li > a, .pager li > span {
	display: inline-block;
	padding: 5px 14px;
	background-color: #fff;
	border: 1px solid #ddd;
	-webkit-border-radius: 15px;
	-moz-border-radius: 15px;
	border-radius: 15px;
}
.pager li > a:hover {
	text-decoration: none;
	background-color: #f5f5f5;
}
.pager .next > a, .pager .next > span {
	float: right;
}
.pager .previous > a, .pager .previous > span {
	float: left;
}
.pager .disabled > a, .pager .disabled > a:hover, .pager .disabled > span {
	color: #999999;
	cursor: default;
	background-color: #fff;
}
.modal-backdrop {
	position: fixed;
	top: 0;
	right: 0;
	bottom: 0;
	left: 0;
	z-index: 1040;
	background-color: #000000;
}
.modal-backdrop.fade {
	opacity: 0;
}
.modal-backdrop, .modal-backdrop.fade.in {
	opacity: 0.8;
	filter: alpha(opacity=80);
}
.modal {
	position: fixed;
	top: 10%;
	left: 50%;
	z-index: 1050;
	width: 560px;
	margin-left: -280px;
	background-color: #ffffff;
	border: 1px solid #999;
	border: 1px solid rgba(0, 0, 0, 0.3);
 *border: 1px solid #999;
	-webkit-border-radius: 6px;
	-moz-border-radius: 6px;
	border-radius: 6px;
	outline: none;
	-webkit-box-shadow: 0 3px 7px rgba(0, 0, 0, 0.3);
	-moz-box-shadow: 0 3px 7px rgba(0, 0, 0, 0.3);
	box-shadow: 0 3px 7px rgba(0, 0, 0, 0.3);
	-webkit-background-clip: padding-box;
	-moz-background-clip: padding-box;
	background-clip: padding-box;
}
.modal.fade {
	top: -25%;
	-webkit-transition: opacity 0.3s linear, top 0.3s ease-out;
	-moz-transition: opacity 0.3s linear, top 0.3s ease-out;
	-o-transition: opacity 0.3s linear, top 0.3s ease-out;
	transition: opacity 0.3s linear, top 0.3s ease-out;
}
.modal.fade.in {
	top: 10%;
}
.modal-header {
	padding: 9px 15px;
	border-bottom: 1px solid #eee;
}
.modal-header .close {
	margin-top: 2px;
}
.modal-header h3 {
	margin: 0;
	line-height: 30px;
}
.modal-body {
	position: relative;
	max-height: 400px;
	padding: 15px;
	overflow-y: auto;
}
.modal-form {
	margin-bottom: 0;
}
.modal-footer {
	padding: 14px 15px 15px;
	margin-bottom: 0;
	text-align: right;
	background-color: #f5f5f5;
	border-top: 1px solid #ddd;
	-webkit-border-radius: 0 0 6px 6px;
	-moz-border-radius: 0 0 6px 6px;
	border-radius: 0 0 6px 6px;
 *zoom: 1;
	-webkit-box-shadow: inset 0 1px 0 #ffffff;
	-moz-box-shadow: inset 0 1px 0 #ffffff;
	box-shadow: inset 0 1px 0 #ffffff;
}
.modal-footer:before, .modal-footer:after {
	display: table;
	line-height: 0;
	content: "";
}
.modal-footer:after {
	clear: both;
}
.modal-footer .btn + .btn {
	margin-bottom: 0;
	margin-left: 5px;
}
.modal-footer .btn-group .btn + .btn {
	margin-left: -1px;
}
.modal-footer .btn-block + .btn-block {
	margin-left: 0;
}
.tooltip {
	position: absolute;
	z-index: 1030;
	display: block;
	padding: 5px;
	font-size: 11px;
	opacity: 0;
	filter: alpha(opacity=0);
	visibility: visible;
}
.tooltip.in {
	opacity: 0.8;
	filter: alpha(opacity=80);
}
.tooltip.top {
	margin-top: -3px;
}
.tooltip.right {
	margin-left: 3px;
}
.tooltip.bottom {
	margin-top: 3px;
}
.tooltip.left {
	margin-left: -3px;
}
.tooltip-inner {
	max-width: 200px;
	padding: 3px 8px;
	color: #ffffff;
	text-align: center;
	text-decoration: none;
	background-color: #000000;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border-radius: 4px;
}
.tooltip-arrow {
	position: absolute;
	width: 0;
	height: 0;
	border-color: transparent;
	border-style: solid;
}
.tooltip.top .tooltip-arrow {
	bottom: 0;
	left: 50%;
	margin-left: -5px;
	border-top-color: #000000;
	border-width: 5px 5px 0;
}
.tooltip.right .tooltip-arrow {
	top: 50%;
	left: 0;
	margin-top: -5px;
	border-right-color: #000000;
	border-width: 5px 5px 5px 0;
}
.tooltip.left .tooltip-arrow {
	top: 50%;
	right: 0;
	margin-top: -5px;
	border-left-color: #000000;
	border-width: 5px 0 5px 5px;
}
.tooltip.bottom .tooltip-arrow {
	top: 0;
	left: 50%;
	margin-left: -5px;
	border-bottom-color: #000000;
	border-width: 0 5px 5px;
}
.popover {
	position: absolute;
	top: 0;
	left: 0;
	z-index: 1010;
	display: none;
	width: 236px;
	padding: 1px;
	text-align: left;
	white-space: normal;
	background-color: #ffffff;
	border: 1px solid #ccc;
	border: 1px solid rgba(0, 0, 0, 0.2);
	-webkit-border-radius: 6px;
	-moz-border-radius: 6px;
	border-radius: 6px;
	-webkit-box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
	-moz-box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
	box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
	-webkit-background-clip: padding-box;
	-moz-background-clip: padding;
	background-clip: padding-box;
}
.popover.top {
	margin-top: -10px;
}
.popover.right {
	margin-left: 10px;
}
.popover.bottom {
	margin-top: 10px;
}
.popover.left {
	margin-left: -10px;
}
.popover-title {
	padding: 8px 14px;
	margin: 0;
	font-size: 14px;
	font-weight: normal;
	line-height: 18px;
	background-color: #f7f7f7;
	border-bottom: 1px solid #ebebeb;
	-webkit-border-radius: 5px 5px 0 0;
	-moz-border-radius: 5px 5px 0 0;
	border-radius: 5px 5px 0 0;
}
.popover-content {
	padding: 9px 14px;
}
.popover .arrow, .popover .arrow:after {
	position: absolute;
	display: block;
	width: 0;
	height: 0;
	border-color: transparent;
	border-style: solid;
}
.popover .arrow {
	border-width: 11px;
}
.popover .arrow:after {
	border-width: 10px;
	content: "";
}
.popover.top .arrow {
	bottom: -11px;
	left: 50%;
	margin-left: -11px;
	border-top-color: #999;
	border-top-color: rgba(0, 0, 0, 0.25);
	border-bottom-width: 0;
}
.popover.top .arrow:after {
	bottom: 1px;
	margin-left: -10px;
	border-top-color: #ffffff;
	border-bottom-width: 0;
}
.popover.right .arrow {
	top: 50%;
	left: -11px;
	margin-top: -11px;
	border-right-color: #999;
	border-right-color: rgba(0, 0, 0, 0.25);
	border-left-width: 0;
}
.popover.right .arrow:after {
	bottom: -10px;
	left: 1px;
	border-right-color: #ffffff;
	border-left-width: 0;
}
.popover.bottom .arrow {
	top: -11px;
	left: 50%;
	margin-left: -11px;
	border-bottom-color: #999;
	border-bottom-color: rgba(0, 0, 0, 0.25);
	border-top-width: 0;
}
.popover.bottom .arrow:after {
	top: 1px;
	margin-left: -10px;
	border-bottom-color: #ffffff;
	border-top-width: 0;
}
.popover.left .arrow {
	top: 50%;
	right: -11px;
	margin-top: -11px;
	border-left-color: #999;
	border-left-color: rgba(0, 0, 0, 0.25);
	border-right-width: 0;
}
.popover.left .arrow:after {
	right: 1px;
	bottom: -10px;
	border-left-color: #ffffff;
	border-right-width: 0;
}
.thumbnails {
	margin-left: -20px;
	list-style: none;
 *zoom: 1;
}
.thumbnails:before, .thumbnails:after {
	display: table;
	line-height: 0;
	content: "";
}
.thumbnails:after {
	clear: both;
}
.row-fluid .thumbnails {
	margin-left: 0;
}
.thumbnails > li {
	float: left;
	margin-bottom: 20px;
	margin-left: 20px;
}
.thumbnail {
	display: block;
	padding: 4px;
	line-height: 20px;
	border: 1px solid #ddd;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border-radius: 4px;
	-webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.055);
	-moz-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.055);
	box-shadow: 0 1px 3px rgba(0, 0, 0, 0.055);
	-webkit-transition: all 0.2s ease-in-out;
	-moz-transition: all 0.2s ease-in-out;
	-o-transition: all 0.2s ease-in-out;
	transition: all 0.2s ease-in-out;
}
a.thumbnail:hover {
	border-color: #0088cc;
	-webkit-box-shadow: 0 1px 4px rgba(0, 105, 214, 0.25);
	-moz-box-shadow: 0 1px 4px rgba(0, 105, 214, 0.25);
	box-shadow: 0 1px 4px rgba(0, 105, 214, 0.25);
}
.thumbnail > img {
	display: block;
	max-width: 100%;
	margin-right: auto;
	margin-left: auto;
}
.thumbnail .caption {
	padding: 9px;
	color: #555555;
}
.media, .media-body {
	overflow: hidden;
 *overflow: visible;
	zoom: 1;
}
.media, .media .media {
	margin-top: 15px;
}
.media:first-child {
	margin-top: 0;
}
.media-object {
	display: block;
}
.media-heading {
	margin: 0 0 5px;
}
.media .pull-left {
	margin-right: 10px;
}
.media .pull-right {
	margin-left: 10px;
}
.media-list {
	margin-left: 0;
	list-style: none;
}


</style>  
        <script src="http://files.cnblogs.com/rubylouvre/jquery1.83.js" > </script>  
        <script src="http://files.cnblogs.com/rubylouvre/bootstrap-transition.js"></script>  
        <script src="http://files.cnblogs.com/rubylouvre/bootstrap-modal.js"></script>  
        <div style="width:674px">
<img src="/education/tpl/simplebootx/Public/images/do_01.jpg"/>
<img src="/education/tpl/simplebootx/Public/images/do_02.jpg"/>
<img src="/education/tpl/simplebootx/Public/images/do_03.jpg" usemap="#Map" border="0"/>
<map name="Map" id="Map">
  <area shape="rect" coords="428,42,648,281" href="#myModal" role="button"  data-toggle="modal"/>
</map>
<img src="/education/tpl/simplebootx/Public/images/do_04.jpg"/>
<img src="/education/tpl/simplebootx/Public/images/do_05.jpg" usemap="#Map2" border="0"/>
<map name="Map2" id="Map2">
  <area shape="rect" coords="422,93,650,324" href="#myModal2" role="button"  data-toggle="modal"/>
</map>
<img src="/education/tpl/simplebootx/Public/images/do_06.jpg"/>
<img src="/education/tpl/simplebootx/Public/images/do_07.jpg" usemap="#Map3" border="0"/>
<map name="Map3" id="Map3">
  <area shape="rect" coords="424,96,654,327" href="#myModal3" role="button"  data-toggle="modal"/>
</map>
</div>

 <!-- Modal -->  
        <div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display:none">  
            <div class="modal-header">  
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>  
                <h3 id="myModalLabel">0-4个月教具秘籍</h3>  
            </div>  
          <div class="modal-body" style="height:500px!important;max-height:none; overflow:visible">  
               <iframe align="center" width="510" height="530" id="win1" name="win" frameborder="0" scrolling="no" src="http://app.mattservice.com/error/aid?type=1" style="width:530px"></iframe>
            </div>  
            <div class="modal-footer">  
                <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>  
            </div>  
        </div>  
        
        
        <div id="myModal2" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display:none">  
            <div class="modal-header">  
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>  
                <h3 id="myModalLabel">5-8个月教具</h3>  
            </div>  
          <div class="modal-body" style="height:500px!important;max-height:none; overflow:visible">  
               <iframe align="center" width="510" height="530" id="win1" name="win" frameborder="0" scrolling="no" src="http://app.mattservice.com/error/aid?type=2" style="width:530px"></iframe>
            </div>  
            <div class="modal-footer">  
                <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>  
            </div>  
        </div>
        
        <div id="myModal3" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display:none">  
            <div class="modal-header">  
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>  
                <h3 id="myModalLabel">9-12个月教具</h3>  
            </div>  
          <div class="modal-body" style="height:500px!important;max-height:none; overflow:visible">  
               <iframe align="center" width="510" height="530" id="win1" name="win" frameborder="0" scrolling="no" src="http://app.mattservice.com/error/aid?type=3" style="width:530px"></iframe>
            </div>  
            <div class="modal-footer">  
                <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>  
            </div>  
        </div>
        </div>
      </div>
      <div class="m_rb"> <img src="/education/tpl/simplebootx/Public/images/right_b.jpg" width="771" height="38" /></div>
    </div>
  </div>
</div>
  <div class="clear"></div>
  <div class="bottom_z">
  <div class="bottom">
    <div class="logo1"><img src="/education/tpl/simplebootx/Public/images/logo1.jpg" width="77" height="39" /></div>
    <div class="bottom_n"><a href="<?php echo leuu('portal/page/index',array('id'=>12));?>">联系我们</a> |<a href="#">官网微博</a> <span>上海麦忒育婴职业技术培训学校 保留所有权利&nbsp;沪ICP备09045106号-2</span> </div>
    <div class="bottom_tel">021-51022333</div>
    <br />
    <div class="youqing">项目导航：&nbsp;<a href="http://www.matteducation.com">上海月嫂培训</a>&nbsp;&nbsp;<a href="http://www.matteducation.com">上海月嫂培训班</a>&nbsp;&nbsp;<a href="http://www.matteducation.com" >上海育婴师培训</a>&nbsp;&nbsp;<a href="http://www.matteducation.com" >上海育婴师培训班</a>&nbsp;&nbsp;<a href="http://www.matteducation.com" >上海培训育婴师</a>&nbsp;&nbsp;<a href="http://www.matteducation.com" >上海培训月嫂</a></div>
    <?php $links=sp_getlinks(); ?>
    <div class="youqing ">友情链接： 
    <?php if(is_array($links)): foreach($links as $key=>$vo): ?><a href="<?php echo ($vo["link_url"]); ?>" target="<?php echo ($vo["link_target"]); ?>"><?php echo ($vo["link_name"]); ?></a>
    &nbsp;<?php endforeach; endif; ?>
    </div>
  </div>
  </div>
  <!--<table width='120' cellpadding='8' cellspacing='3' style="position:fixed; display:; top: 300px; left: 5px;">
    <tr>
      <td align='center'  style='LETTER-SPACING: 0.2em;'><a href="MattschoolQR.jpg"><img src="http://www.matteducation.com/MattschoolQR.jpg" border="0" width ="129px" height="129px"></a><br>
        <font color='green'> 微信扫一扫</font></td>
    </tr>
  </table>-->
  <?php echo ($site_tongji); ?>
</body>
</html>