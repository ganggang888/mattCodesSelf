<?php

/**
 * 配置文件
 */
return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'school',
    'DB_USER' => 'root',
    'DB_PWD' => '111111',
    'DB_PORT' => '3306',
    'DB_PREFIX' => 'sp_',
    //密钥
    "AUTHCODE" => 'swgCS4jHu7Bf2ZgZvY',
    //cookies
    "COOKIE_PREFIX" => 'mbEjy7_',
);
?>