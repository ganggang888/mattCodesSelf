<?php	return array (
  'return_url' => 'portal/index/return_url',
  'notify_url' => 'portal/index/notify_url',
);