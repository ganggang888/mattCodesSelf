<?php	return array (
  'chat' => 'api/wchat/index',
);