<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>礼物</title>
</head>
<link href="/tpl/simplebootx/Public/css/base.css" rel="stylesheet">
<style>
body{ margin:0px; padding:0px}
</style>
<body>
<img src="http://m.matteducation.com/tpl/simplebootx/Public/images/active.jpg" style="width:100%" />
</body>
</html>