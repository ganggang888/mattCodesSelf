define([
	"./deletedIds"
], function( deletedIds ) {
	return deletedIds.push;
});
